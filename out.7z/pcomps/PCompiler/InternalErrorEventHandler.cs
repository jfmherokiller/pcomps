﻿using System;

namespace PCompiler
{
	// Token: 0x020001C3 RID: 451
	// (Invoke) Token: 0x06000D6B RID: 3435
	internal delegate void InternalErrorEventHandler(object akSender, InternalErrorEventArgs akArgs);
}
