﻿using System;

namespace PCompiler
{
	// Token: 0x020001BC RID: 444
	public class CompilerNotifyEventArgs
	{
		// Token: 0x06000D28 RID: 3368 RVA: 0x0005CB9C File Offset: 0x0005AD9C
		public CompilerNotifyEventArgs(string asMessage)
		{
			this.sMessage = asMessage;
		}

		// Token: 0x040009C2 RID: 2498
		public readonly string sMessage;
	}
}
