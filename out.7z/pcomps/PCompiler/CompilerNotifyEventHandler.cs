﻿using System;

namespace PCompiler
{
	// Token: 0x020001BD RID: 445
	// (Invoke) Token: 0x06000D2A RID: 3370
	public delegate void CompilerNotifyEventHandler(object kSender, CompilerNotifyEventArgs kArgs);
}
