﻿using System;

namespace PCompiler
{
	// Token: 0x0200020E RID: 526
	// (Invoke) Token: 0x06000EF2 RID: 3826
	public delegate void CompilerErrorEventHandler(object kSender, CompilerErrorEventArgs kArgs);
}
