﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ZeniMax Media")]
[assembly: AssemblyProduct("PapyrusCompiler")]
[assembly: AssemblyTitle("PapyrusCompiler")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCopyright("Copyright © ZeniMax Media 2009")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("40bbdf74-3978-4753-94bc-41d505a54fbe")]
