﻿using System;

namespace antlr
{
	// Token: 0x02000019 RID: 25
	[Serializable]
	public class CharStreamException : ANTLRException
	{
		// Token: 0x06000149 RID: 329 RVA: 0x000057CC File Offset: 0x000039CC
		public CharStreamException(string s) : base(s)
		{
		}
	}
}
