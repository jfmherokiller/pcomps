﻿using System;
using System.Collections;
using antlr.collections.impl;

namespace antlr.debug
{
	// Token: 0x0200006D RID: 109
	public class ParserEventSupport
	{
		// Token: 0x060003D2 RID: 978 RVA: 0x0000B6A8 File Offset: 0x000098A8
		public ParserEventSupport(object source)
		{
			this.matchEvent = new MatchEventArgs();
			this.messageEvent = new MessageEventArgs();
			this.tokenEvent = new TokenEventArgs();
			this.traceEvent = new TraceEventArgs();
			this.semPredEvent = new SemanticPredicateEventArgs();
			this.synPredEvent = new SyntacticPredicateEventArgs();
			this.newLineEvent = new NewLineEventArgs();
			this.listeners = new Hashtable();
			this.source = source;
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x0000B724 File Offset: 0x00009924
		public virtual void checkController()
		{
			if (this.controller != null)
			{
				this.controller.checkBreak();
			}
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x0000B744 File Offset: 0x00009944
		public virtual void addDoneListener(Listener l)
		{
			((Parser)this.source).Done += l.doneParsing;
			this.listeners[l] = l;
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x0000B77C File Offset: 0x0000997C
		public virtual void addMessageListener(MessageListener l)
		{
			((Parser)this.source).ErrorReported += l.reportError;
			((Parser)this.source).WarningReported += l.reportWarning;
			this.addDoneListener(l);
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x0000B7CC File Offset: 0x000099CC
		public virtual void addParserListener(ParserListener l)
		{
			if (l is ParserController)
			{
				((ParserController)l).ParserEventSupport = this;
				this.controller = (ParserController)l;
			}
			this.addParserMatchListener(l);
			this.addParserTokenListener(l);
			this.addMessageListener(l);
			this.addTraceListener(l);
			this.addSemanticPredicateListener(l);
			this.addSyntacticPredicateListener(l);
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x0000B824 File Offset: 0x00009A24
		public virtual void addParserMatchListener(ParserMatchListener l)
		{
			((Parser)this.source).MatchedToken += l.parserMatch;
			((Parser)this.source).MatchedNotToken += l.parserMatchNot;
			((Parser)this.source).MisMatchedToken += l.parserMismatch;
			((Parser)this.source).MisMatchedNotToken += l.parserMismatchNot;
			this.addDoneListener(l);
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x0000B8AC File Offset: 0x00009AAC
		public virtual void addParserTokenListener(ParserTokenListener l)
		{
			((Parser)this.source).ConsumedToken += l.parserConsume;
			((Parser)this.source).TokenLA += l.parserLA;
			this.addDoneListener(l);
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x0000B8FC File Offset: 0x00009AFC
		public virtual void addSemanticPredicateListener(SemanticPredicateListener l)
		{
			((Parser)this.source).SemPredEvaluated += l.semanticPredicateEvaluated;
			this.addDoneListener(l);
		}

		// Token: 0x060003DA RID: 986 RVA: 0x0000B930 File Offset: 0x00009B30
		public virtual void addSyntacticPredicateListener(SyntacticPredicateListener l)
		{
			((Parser)this.source).SynPredStarted += l.syntacticPredicateStarted;
			((Parser)this.source).SynPredFailed += l.syntacticPredicateFailed;
			((Parser)this.source).SynPredSucceeded += l.syntacticPredicateSucceeded;
			this.addDoneListener(l);
		}

		// Token: 0x060003DB RID: 987 RVA: 0x0000B99C File Offset: 0x00009B9C
		public virtual void addTraceListener(TraceListener l)
		{
			((Parser)this.source).EnterRule += l.enterRule;
			((Parser)this.source).ExitRule += l.exitRule;
			this.addDoneListener(l);
		}

		// Token: 0x060003DC RID: 988 RVA: 0x0000B9EC File Offset: 0x00009BEC
		public virtual void fireConsume(int c)
		{
			TokenEventHandler tokenEventHandler = (TokenEventHandler)((Parser)this.source).Events[Parser.LAEventKey];
			if (tokenEventHandler != null)
			{
				this.tokenEvent.setValues(TokenEventArgs.CONSUME, 1, c);
				tokenEventHandler(this.source, this.tokenEvent);
			}
			this.checkController();
		}

		// Token: 0x060003DD RID: 989 RVA: 0x0000BA48 File Offset: 0x00009C48
		public virtual void fireDoneParsing()
		{
			TraceEventHandler traceEventHandler = (TraceEventHandler)((Parser)this.source).Events[Parser.DoneEventKey];
			if (traceEventHandler != null)
			{
				this.traceEvent.setValues(TraceEventArgs.DONE_PARSING, 0, 0, 0);
				traceEventHandler(this.source, this.traceEvent);
			}
			this.checkController();
		}

		// Token: 0x060003DE RID: 990 RVA: 0x0000BAA4 File Offset: 0x00009CA4
		public virtual void fireEnterRule(int ruleNum, int guessing, int data)
		{
			this.ruleDepth++;
			TraceEventHandler traceEventHandler = (TraceEventHandler)((Parser)this.source).Events[Parser.EnterRuleEventKey];
			if (traceEventHandler != null)
			{
				this.traceEvent.setValues(TraceEventArgs.ENTER, ruleNum, guessing, data);
				traceEventHandler(this.source, this.traceEvent);
			}
			this.checkController();
		}

		// Token: 0x060003DF RID: 991 RVA: 0x0000BB10 File Offset: 0x00009D10
		public virtual void fireExitRule(int ruleNum, int guessing, int data)
		{
			TraceEventHandler traceEventHandler = (TraceEventHandler)((Parser)this.source).Events[Parser.ExitRuleEventKey];
			if (traceEventHandler != null)
			{
				this.traceEvent.setValues(TraceEventArgs.EXIT, ruleNum, guessing, data);
				traceEventHandler(this.source, this.traceEvent);
			}
			this.checkController();
			this.ruleDepth--;
			if (this.ruleDepth == 0)
			{
				this.fireDoneParsing();
			}
		}

		// Token: 0x060003E0 RID: 992 RVA: 0x0000BB88 File Offset: 0x00009D88
		public virtual void fireLA(int k, int la)
		{
			TokenEventHandler tokenEventHandler = (TokenEventHandler)((Parser)this.source).Events[Parser.LAEventKey];
			if (tokenEventHandler != null)
			{
				this.tokenEvent.setValues(TokenEventArgs.LA, k, la);
				tokenEventHandler(this.source, this.tokenEvent);
			}
			this.checkController();
		}

		// Token: 0x060003E1 RID: 993 RVA: 0x0000BBE4 File Offset: 0x00009DE4
		public virtual void fireMatch(char c, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR, (int)c, c, null, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003E2 RID: 994 RVA: 0x0000BC48 File Offset: 0x00009E48
		public virtual void fireMatch(char c, BitSet b, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR_BITSET, (int)c, b, null, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003E3 RID: 995 RVA: 0x0000BCA8 File Offset: 0x00009EA8
		public virtual void fireMatch(char c, string target, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR_RANGE, (int)c, target, null, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003E4 RID: 996 RVA: 0x0000BD08 File Offset: 0x00009F08
		public virtual void fireMatch(int c, BitSet b, string text, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.BITSET, c, b, text, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003E5 RID: 997 RVA: 0x0000BD68 File Offset: 0x00009F68
		public virtual void fireMatch(int n, string text, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.TOKEN, n, n, text, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003E6 RID: 998 RVA: 0x0000BDCC File Offset: 0x00009FCC
		public virtual void fireMatch(string s, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.STRING, 0, s, null, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x0000BE2C File Offset: 0x0000A02C
		public virtual void fireMatchNot(char c, char n, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MatchNotEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR, (int)c, n, null, guessing, true, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003E8 RID: 1000 RVA: 0x0000BE90 File Offset: 0x0000A090
		public virtual void fireMatchNot(int c, int n, string text, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MatchNotEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.TOKEN, c, n, text, guessing, true, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003E9 RID: 1001 RVA: 0x0000BEF4 File Offset: 0x0000A0F4
		public virtual void fireMismatch(char c, char n, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MisMatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR, (int)c, n, null, guessing, false, false);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003EA RID: 1002 RVA: 0x0000BF58 File Offset: 0x0000A158
		public virtual void fireMismatch(char c, BitSet b, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MisMatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR_BITSET, (int)c, b, null, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003EB RID: 1003 RVA: 0x0000BFB8 File Offset: 0x0000A1B8
		public virtual void fireMismatch(char c, string target, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MisMatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR_RANGE, (int)c, target, null, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003EC RID: 1004 RVA: 0x0000C018 File Offset: 0x0000A218
		public virtual void fireMismatch(int i, int n, string text, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MisMatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.TOKEN, i, n, text, guessing, false, false);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003ED RID: 1005 RVA: 0x0000C07C File Offset: 0x0000A27C
		public virtual void fireMismatch(int i, BitSet b, string text, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MisMatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.BITSET, i, b, text, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003EE RID: 1006 RVA: 0x0000C0DC File Offset: 0x0000A2DC
		public virtual void fireMismatch(string s, string text, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MisMatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.STRING, 0, text, s, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003EF RID: 1007 RVA: 0x0000C13C File Offset: 0x0000A33C
		public virtual void fireMismatchNot(char v, char c, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MisMatchNotEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR, (int)v, c, null, guessing, true, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003F0 RID: 1008 RVA: 0x0000C1A0 File Offset: 0x0000A3A0
		public virtual void fireMismatchNot(int i, int n, string text, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((Parser)this.source).Events[Parser.MisMatchNotEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.TOKEN, i, n, text, guessing, true, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x060003F1 RID: 1009 RVA: 0x0000C204 File Offset: 0x0000A404
		public virtual void fireReportError(Exception e)
		{
			MessageEventHandler messageEventHandler = (MessageEventHandler)((Parser)this.source).Events[Parser.ReportErrorEventKey];
			if (messageEventHandler != null)
			{
				this.messageEvent.setValues(MessageEventArgs.ERROR, e.ToString());
				messageEventHandler(this.source, this.messageEvent);
			}
			this.checkController();
		}

		// Token: 0x060003F2 RID: 1010 RVA: 0x0000C264 File Offset: 0x0000A464
		public virtual void fireReportError(string s)
		{
			MessageEventHandler messageEventHandler = (MessageEventHandler)((Parser)this.source).Events[Parser.ReportErrorEventKey];
			if (messageEventHandler != null)
			{
				this.messageEvent.setValues(MessageEventArgs.ERROR, s);
				messageEventHandler(this.source, this.messageEvent);
			}
			this.checkController();
		}

		// Token: 0x060003F3 RID: 1011 RVA: 0x0000C2C0 File Offset: 0x0000A4C0
		public virtual void fireReportWarning(string s)
		{
			MessageEventHandler messageEventHandler = (MessageEventHandler)((Parser)this.source).Events[Parser.ReportWarningEventKey];
			if (messageEventHandler != null)
			{
				this.messageEvent.setValues(MessageEventArgs.WARNING, s);
				messageEventHandler(this.source, this.messageEvent);
			}
			this.checkController();
		}

		// Token: 0x060003F4 RID: 1012 RVA: 0x0000C31C File Offset: 0x0000A51C
		public virtual bool fireSemanticPredicateEvaluated(int type, int condition, bool result, int guessing)
		{
			SemanticPredicateEventHandler semanticPredicateEventHandler = (SemanticPredicateEventHandler)((Parser)this.source).Events[Parser.SemPredEvaluatedEventKey];
			if (semanticPredicateEventHandler != null)
			{
				this.semPredEvent.setValues(type, condition, result, guessing);
				semanticPredicateEventHandler(this.source, this.semPredEvent);
			}
			this.checkController();
			return result;
		}

		// Token: 0x060003F5 RID: 1013 RVA: 0x0000C378 File Offset: 0x0000A578
		public virtual void fireSyntacticPredicateFailed(int guessing)
		{
			SyntacticPredicateEventHandler syntacticPredicateEventHandler = (SyntacticPredicateEventHandler)((Parser)this.source).Events[Parser.SynPredFailedEventKey];
			if (syntacticPredicateEventHandler != null)
			{
				this.synPredEvent.setValues(0, guessing);
				syntacticPredicateEventHandler(this.source, this.synPredEvent);
			}
			this.checkController();
		}

		// Token: 0x060003F6 RID: 1014 RVA: 0x0000C3D0 File Offset: 0x0000A5D0
		public virtual void fireSyntacticPredicateStarted(int guessing)
		{
			SyntacticPredicateEventHandler syntacticPredicateEventHandler = (SyntacticPredicateEventHandler)((Parser)this.source).Events[Parser.SynPredStartedEventKey];
			if (syntacticPredicateEventHandler != null)
			{
				this.synPredEvent.setValues(0, guessing);
				syntacticPredicateEventHandler(this.source, this.synPredEvent);
			}
			this.checkController();
		}

		// Token: 0x060003F7 RID: 1015 RVA: 0x0000C428 File Offset: 0x0000A628
		public virtual void fireSyntacticPredicateSucceeded(int guessing)
		{
			SyntacticPredicateEventHandler syntacticPredicateEventHandler = (SyntacticPredicateEventHandler)((Parser)this.source).Events[Parser.SynPredSucceededEventKey];
			if (syntacticPredicateEventHandler != null)
			{
				this.synPredEvent.setValues(0, guessing);
				syntacticPredicateEventHandler(this.source, this.synPredEvent);
			}
			this.checkController();
		}

		// Token: 0x060003F8 RID: 1016 RVA: 0x0000C480 File Offset: 0x0000A680
		public virtual void refreshListeners()
		{
			Hashtable hashtable;
			lock (this.listeners.SyncRoot)
			{
				hashtable = (Hashtable)this.listeners.Clone();
			}
			foreach (object obj in hashtable)
			{
				DictionaryEntry dictionaryEntry = (DictionaryEntry)obj;
				if (dictionaryEntry.Value != null)
				{
					((Listener)dictionaryEntry.Value).refresh();
				}
			}
		}

		// Token: 0x060003F9 RID: 1017 RVA: 0x0000C528 File Offset: 0x0000A728
		public virtual void removeDoneListener(Listener l)
		{
			((Parser)this.source).Done -= l.doneParsing;
			this.listeners.Remove(l);
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x0000C560 File Offset: 0x0000A760
		public virtual void removeMessageListener(MessageListener l)
		{
			((Parser)this.source).ErrorReported -= l.reportError;
			((Parser)this.source).WarningReported -= l.reportWarning;
			this.removeDoneListener(l);
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x0000C5B0 File Offset: 0x0000A7B0
		public virtual void removeParserListener(ParserListener l)
		{
			this.removeParserMatchListener(l);
			this.removeMessageListener(l);
			this.removeParserTokenListener(l);
			this.removeTraceListener(l);
			this.removeSemanticPredicateListener(l);
			this.removeSyntacticPredicateListener(l);
		}

		// Token: 0x060003FC RID: 1020 RVA: 0x0000C5E8 File Offset: 0x0000A7E8
		public virtual void removeParserMatchListener(ParserMatchListener l)
		{
			((Parser)this.source).MatchedToken -= l.parserMatch;
			((Parser)this.source).MatchedNotToken -= l.parserMatchNot;
			((Parser)this.source).MisMatchedToken -= l.parserMismatch;
			((Parser)this.source).MisMatchedNotToken -= l.parserMismatchNot;
			this.removeDoneListener(l);
		}

		// Token: 0x060003FD RID: 1021 RVA: 0x0000C670 File Offset: 0x0000A870
		public virtual void removeParserTokenListener(ParserTokenListener l)
		{
			((Parser)this.source).ConsumedToken -= l.parserConsume;
			((Parser)this.source).TokenLA -= l.parserLA;
			this.removeDoneListener(l);
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x0000C6C0 File Offset: 0x0000A8C0
		public virtual void removeSemanticPredicateListener(SemanticPredicateListener l)
		{
			((Parser)this.source).SemPredEvaluated -= l.semanticPredicateEvaluated;
			this.removeDoneListener(l);
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x0000C6F4 File Offset: 0x0000A8F4
		public virtual void removeSyntacticPredicateListener(SyntacticPredicateListener l)
		{
			((Parser)this.source).SynPredStarted -= l.syntacticPredicateStarted;
			((Parser)this.source).SynPredFailed -= l.syntacticPredicateFailed;
			((Parser)this.source).SynPredSucceeded -= l.syntacticPredicateSucceeded;
			this.removeDoneListener(l);
		}

		// Token: 0x06000400 RID: 1024 RVA: 0x0000C760 File Offset: 0x0000A960
		public virtual void removeTraceListener(TraceListener l)
		{
			((Parser)this.source).EnterRule -= l.enterRule;
			((Parser)this.source).ExitRule -= l.exitRule;
			this.removeDoneListener(l);
		}

		// Token: 0x04000103 RID: 259
		private object source;

		// Token: 0x04000104 RID: 260
		private Hashtable listeners;

		// Token: 0x04000105 RID: 261
		private MatchEventArgs matchEvent;

		// Token: 0x04000106 RID: 262
		private MessageEventArgs messageEvent;

		// Token: 0x04000107 RID: 263
		private TokenEventArgs tokenEvent;

		// Token: 0x04000108 RID: 264
		private SemanticPredicateEventArgs semPredEvent;

		// Token: 0x04000109 RID: 265
		private SyntacticPredicateEventArgs synPredEvent;

		// Token: 0x0400010A RID: 266
		private TraceEventArgs traceEvent;

		// Token: 0x0400010B RID: 267
		private NewLineEventArgs newLineEvent;

		// Token: 0x0400010C RID: 268
		private ParserController controller;

		// Token: 0x0400010D RID: 269
		private int ruleDepth = 0;
	}
}
