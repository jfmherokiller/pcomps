﻿using System;

namespace antlr.debug
{
	// Token: 0x02000071 RID: 113
	public abstract class ParserMatchListenerBase : ParserMatchListener, Listener
	{
		// Token: 0x06000421 RID: 1057 RVA: 0x0000CAE0 File Offset: 0x0000ACE0
		public virtual void doneParsing(object source, TraceEventArgs e)
		{
		}

		// Token: 0x06000422 RID: 1058 RVA: 0x0000CAF0 File Offset: 0x0000ACF0
		public virtual void parserMatch(object source, MatchEventArgs e)
		{
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x0000CB00 File Offset: 0x0000AD00
		public virtual void parserMatchNot(object source, MatchEventArgs e)
		{
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x0000CB10 File Offset: 0x0000AD10
		public virtual void parserMismatch(object source, MatchEventArgs e)
		{
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x0000CB20 File Offset: 0x0000AD20
		public virtual void parserMismatchNot(object source, MatchEventArgs e)
		{
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x0000CB30 File Offset: 0x0000AD30
		public virtual void refresh()
		{
		}
	}
}
