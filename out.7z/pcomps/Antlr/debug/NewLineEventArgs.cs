﻿using System;

namespace antlr.debug
{
	// Token: 0x0200005D RID: 93
	public class NewLineEventArgs : ANTLREventArgs
	{
		// Token: 0x060003A2 RID: 930 RVA: 0x0000B628 File Offset: 0x00009828
		public NewLineEventArgs()
		{
		}

		// Token: 0x060003A3 RID: 931 RVA: 0x0000B63C File Offset: 0x0000983C
		public NewLineEventArgs(int line)
		{
			this.Line = line;
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x060003A4 RID: 932 RVA: 0x0000B658 File Offset: 0x00009858
		// (set) Token: 0x060003A5 RID: 933 RVA: 0x0000B66C File Offset: 0x0000986C
		public virtual int Line
		{
			get
			{
				return this.line_;
			}
			set
			{
				this.line_ = value;
			}
		}

		// Token: 0x060003A6 RID: 934 RVA: 0x0000B680 File Offset: 0x00009880
		public override string ToString()
		{
			return "NewLineEvent [" + this.line_ + "]";
		}

		// Token: 0x04000102 RID: 258
		private int line_;
	}
}
