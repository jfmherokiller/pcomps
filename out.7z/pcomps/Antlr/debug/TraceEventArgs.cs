﻿using System;

namespace antlr.debug
{
	// Token: 0x0200007D RID: 125
	public class TraceEventArgs : GuessingEventArgs
	{
		// Token: 0x060004A0 RID: 1184 RVA: 0x0000E580 File Offset: 0x0000C780
		public TraceEventArgs()
		{
		}

		// Token: 0x060004A1 RID: 1185 RVA: 0x0000E594 File Offset: 0x0000C794
		public TraceEventArgs(int type, int ruleNum, int guessing, int data)
		{
			this.setValues(type, ruleNum, guessing, data);
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x060004A2 RID: 1186 RVA: 0x0000E5B4 File Offset: 0x0000C7B4
		// (set) Token: 0x060004A3 RID: 1187 RVA: 0x0000E5C8 File Offset: 0x0000C7C8
		public virtual int Data
		{
			get
			{
				return this.data_;
			}
			set
			{
				this.data_ = value;
			}
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x060004A4 RID: 1188 RVA: 0x0000E5DC File Offset: 0x0000C7DC
		// (set) Token: 0x060004A5 RID: 1189 RVA: 0x0000E5F0 File Offset: 0x0000C7F0
		public virtual int RuleNum
		{
			get
			{
				return this.ruleNum_;
			}
			set
			{
				this.ruleNum_ = value;
			}
		}

		// Token: 0x060004A6 RID: 1190 RVA: 0x0000E604 File Offset: 0x0000C804
		internal void setValues(int type, int ruleNum, int guessing, int data)
		{
			base.setValues(type, guessing);
			this.RuleNum = ruleNum;
			this.Data = data;
		}

		// Token: 0x060004A7 RID: 1191 RVA: 0x0000E628 File Offset: 0x0000C828
		public override string ToString()
		{
			return string.Concat(new object[]
			{
				"ParserTraceEvent [",
				(this.Type == TraceEventArgs.ENTER) ? "enter," : "exit,",
				this.RuleNum,
				",",
				this.Guessing,
				"]"
			});
		}

		// Token: 0x04000136 RID: 310
		private int ruleNum_;

		// Token: 0x04000137 RID: 311
		private int data_;

		// Token: 0x04000138 RID: 312
		public static int ENTER = 0;

		// Token: 0x04000139 RID: 313
		public static int EXIT = 1;

		// Token: 0x0400013A RID: 314
		public static int DONE_PARSING = 2;
	}
}
