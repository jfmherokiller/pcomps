﻿using System;

namespace antlr.debug
{
	// Token: 0x0200005B RID: 91
	public interface MessageListener : Listener
	{
		// Token: 0x0600039B RID: 923
		void reportError(object source, MessageEventArgs e);

		// Token: 0x0600039C RID: 924
		void reportWarning(object source, MessageEventArgs e);
	}
}
