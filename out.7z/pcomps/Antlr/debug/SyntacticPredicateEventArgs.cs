﻿using System;

namespace antlr.debug
{
	// Token: 0x0200007B RID: 123
	public class SyntacticPredicateEventArgs : GuessingEventArgs
	{
		// Token: 0x06000497 RID: 1175 RVA: 0x0000E4CC File Offset: 0x0000C6CC
		public SyntacticPredicateEventArgs()
		{
		}

		// Token: 0x06000498 RID: 1176 RVA: 0x0000E4E0 File Offset: 0x0000C6E0
		public SyntacticPredicateEventArgs(int type) : base(type)
		{
		}

		// Token: 0x06000499 RID: 1177 RVA: 0x0000E4F4 File Offset: 0x0000C6F4
		public override string ToString()
		{
			return "SyntacticPredicateEvent [" + this.Guessing + "]";
		}
	}
}
