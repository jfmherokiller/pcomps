﻿using System;
using System.Collections;

namespace antlr.debug
{
	// Token: 0x02000054 RID: 84
	public class InputBufferEventSupport
	{
		// Token: 0x17000026 RID: 38
		// (get) Token: 0x0600034A RID: 842 RVA: 0x0000A9E8 File Offset: 0x00008BE8
		public virtual ArrayList InputBufferListeners
		{
			get
			{
				return this.inputBufferListeners;
			}
		}

		// Token: 0x0600034B RID: 843 RVA: 0x0000A9FC File Offset: 0x00008BFC
		public InputBufferEventSupport(object source)
		{
			this.inputBufferEvent = new InputBufferEventArgs();
			this.source = source;
		}

		// Token: 0x0600034C RID: 844 RVA: 0x0000AA24 File Offset: 0x00008C24
		public virtual void addInputBufferListener(InputBufferListener l)
		{
			if (this.inputBufferListeners == null)
			{
				this.inputBufferListeners = new ArrayList();
			}
			this.inputBufferListeners.Add(l);
		}

		// Token: 0x0600034D RID: 845 RVA: 0x0000AA54 File Offset: 0x00008C54
		public virtual void fireConsume(char c)
		{
			this.inputBufferEvent.setValues(0, c, 0);
			this.fireEvents(0, this.inputBufferListeners);
		}

		// Token: 0x0600034E RID: 846 RVA: 0x0000AA7C File Offset: 0x00008C7C
		public virtual void fireEvent(int type, Listener l)
		{
			switch (type)
			{
			case 0:
				((InputBufferListener)l).inputBufferConsume(this.source, this.inputBufferEvent);
				return;
			case 1:
				((InputBufferListener)l).inputBufferLA(this.source, this.inputBufferEvent);
				return;
			case 2:
				((InputBufferListener)l).inputBufferMark(this.source, this.inputBufferEvent);
				return;
			case 3:
				((InputBufferListener)l).inputBufferRewind(this.source, this.inputBufferEvent);
				return;
			default:
				throw new ArgumentException("bad type " + type + " for fireEvent()");
			}
		}

		// Token: 0x0600034F RID: 847 RVA: 0x0000AB20 File Offset: 0x00008D20
		public virtual void fireEvents(int type, ArrayList listeners)
		{
			ArrayList arrayList = null;
			lock (this)
			{
				if (listeners == null)
				{
					return;
				}
				arrayList = (ArrayList)listeners.Clone();
			}
			if (arrayList != null)
			{
				for (int i = 0; i < arrayList.Count; i++)
				{
					Listener l = (Listener)arrayList[i];
					this.fireEvent(type, l);
				}
			}
		}

		// Token: 0x06000350 RID: 848 RVA: 0x0000AB8C File Offset: 0x00008D8C
		public virtual void fireLA(char c, int la)
		{
			this.inputBufferEvent.setValues(1, c, la);
			this.fireEvents(1, this.inputBufferListeners);
		}

		// Token: 0x06000351 RID: 849 RVA: 0x0000ABB4 File Offset: 0x00008DB4
		public virtual void fireMark(int pos)
		{
			this.inputBufferEvent.setValues(2, ' ', pos);
			this.fireEvents(2, this.inputBufferListeners);
		}

		// Token: 0x06000352 RID: 850 RVA: 0x0000ABE0 File Offset: 0x00008DE0
		public virtual void fireRewind(int pos)
		{
			this.inputBufferEvent.setValues(3, ' ', pos);
			this.fireEvents(3, this.inputBufferListeners);
		}

		// Token: 0x06000353 RID: 851 RVA: 0x0000AC0C File Offset: 0x00008E0C
		protected internal virtual void refresh(ArrayList listeners)
		{
			ArrayList arrayList;
			lock (listeners)
			{
				arrayList = (ArrayList)listeners.Clone();
			}
			if (arrayList != null)
			{
				for (int i = 0; i < arrayList.Count; i++)
				{
					((Listener)arrayList[i]).refresh();
				}
			}
		}

		// Token: 0x06000354 RID: 852 RVA: 0x0000AC6C File Offset: 0x00008E6C
		public virtual void refreshListeners()
		{
			this.refresh(this.inputBufferListeners);
		}

		// Token: 0x06000355 RID: 853 RVA: 0x0000AC88 File Offset: 0x00008E88
		public virtual void removeInputBufferListener(InputBufferListener l)
		{
			if (this.inputBufferListeners != null)
			{
				ArrayList arrayList = this.inputBufferListeners;
				arrayList.Contains(l);
				arrayList.Remove(l);
			}
		}

		// Token: 0x040000F4 RID: 244
		protected internal const int CONSUME = 0;

		// Token: 0x040000F5 RID: 245
		protected internal const int LA = 1;

		// Token: 0x040000F6 RID: 246
		protected internal const int MARK = 2;

		// Token: 0x040000F7 RID: 247
		protected internal const int REWIND = 3;

		// Token: 0x040000F8 RID: 248
		private object source;

		// Token: 0x040000F9 RID: 249
		private ArrayList inputBufferListeners;

		// Token: 0x040000FA RID: 250
		private InputBufferEventArgs inputBufferEvent;
	}
}
