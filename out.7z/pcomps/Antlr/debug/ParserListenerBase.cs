﻿using System;

namespace antlr.debug
{
	// Token: 0x0200006E RID: 110
	public class ParserListenerBase : ParserListener, SemanticPredicateListener, ParserMatchListener, MessageListener, ParserTokenListener, TraceListener, SyntacticPredicateListener, Listener
	{
		// Token: 0x06000401 RID: 1025 RVA: 0x0000C7B0 File Offset: 0x0000A9B0
		public virtual void doneParsing(object source, TraceEventArgs e)
		{
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x0000C7C0 File Offset: 0x0000A9C0
		public virtual void enterRule(object source, TraceEventArgs e)
		{
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x0000C7D0 File Offset: 0x0000A9D0
		public virtual void exitRule(object source, TraceEventArgs e)
		{
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x0000C7E0 File Offset: 0x0000A9E0
		public virtual void parserConsume(object source, TokenEventArgs e)
		{
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x0000C7F0 File Offset: 0x0000A9F0
		public virtual void parserLA(object source, TokenEventArgs e)
		{
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x0000C800 File Offset: 0x0000AA00
		public virtual void parserMatch(object source, MatchEventArgs e)
		{
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x0000C810 File Offset: 0x0000AA10
		public virtual void parserMatchNot(object source, MatchEventArgs e)
		{
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x0000C820 File Offset: 0x0000AA20
		public virtual void parserMismatch(object source, MatchEventArgs e)
		{
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x0000C830 File Offset: 0x0000AA30
		public virtual void parserMismatchNot(object source, MatchEventArgs e)
		{
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x0000C840 File Offset: 0x0000AA40
		public virtual void reportError(object source, MessageEventArgs e)
		{
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x0000C850 File Offset: 0x0000AA50
		public virtual void reportWarning(object source, MessageEventArgs e)
		{
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x0000C860 File Offset: 0x0000AA60
		public virtual void semanticPredicateEvaluated(object source, SemanticPredicateEventArgs e)
		{
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x0000C870 File Offset: 0x0000AA70
		public virtual void syntacticPredicateFailed(object source, SyntacticPredicateEventArgs e)
		{
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x0000C880 File Offset: 0x0000AA80
		public virtual void syntacticPredicateStarted(object source, SyntacticPredicateEventArgs e)
		{
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x0000C890 File Offset: 0x0000AA90
		public virtual void syntacticPredicateSucceeded(object source, SyntacticPredicateEventArgs e)
		{
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x0000C8A0 File Offset: 0x0000AAA0
		public virtual void refresh()
		{
		}
	}
}
