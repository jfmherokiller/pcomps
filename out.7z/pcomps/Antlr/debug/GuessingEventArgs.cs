﻿using System;

namespace antlr.debug
{
	// Token: 0x02000052 RID: 82
	public abstract class GuessingEventArgs : ANTLREventArgs
	{
		// Token: 0x0600033D RID: 829 RVA: 0x0000A870 File Offset: 0x00008A70
		public GuessingEventArgs()
		{
		}

		// Token: 0x0600033E RID: 830 RVA: 0x0000A884 File Offset: 0x00008A84
		public GuessingEventArgs(int type) : base(type)
		{
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x0600033F RID: 831 RVA: 0x0000A898 File Offset: 0x00008A98
		// (set) Token: 0x06000340 RID: 832 RVA: 0x0000A8AC File Offset: 0x00008AAC
		public virtual int Guessing
		{
			get
			{
				return this.guessing_;
			}
			set
			{
				this.guessing_ = value;
			}
		}

		// Token: 0x06000341 RID: 833 RVA: 0x0000A8C0 File Offset: 0x00008AC0
		public virtual void setValues(int type, int guessing)
		{
			base.setValues(type);
			this.Guessing = guessing;
		}

		// Token: 0x040000ED RID: 237
		private int guessing_;
	}
}
