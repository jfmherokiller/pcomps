﻿using System;

namespace antlr.debug
{
	// Token: 0x0200006F RID: 111
	public class MatchEventArgs : GuessingEventArgs
	{
		// Token: 0x06000412 RID: 1042 RVA: 0x0000C8C4 File Offset: 0x0000AAC4
		public MatchEventArgs()
		{
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x0000C8D8 File Offset: 0x0000AAD8
		public MatchEventArgs(int type, int val, object target, string text, int guessing, bool inverse, bool matched)
		{
			this.setValues(type, val, target, text, guessing, inverse, matched);
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x06000414 RID: 1044 RVA: 0x0000C8FC File Offset: 0x0000AAFC
		// (set) Token: 0x06000415 RID: 1045 RVA: 0x0000C910 File Offset: 0x0000AB10
		public virtual object Target
		{
			get
			{
				return this.target_;
			}
			set
			{
				this.target_ = value;
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x06000416 RID: 1046 RVA: 0x0000C924 File Offset: 0x0000AB24
		// (set) Token: 0x06000417 RID: 1047 RVA: 0x0000C938 File Offset: 0x0000AB38
		public virtual string Text
		{
			get
			{
				return this.text_;
			}
			set
			{
				this.text_ = value;
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x06000418 RID: 1048 RVA: 0x0000C94C File Offset: 0x0000AB4C
		// (set) Token: 0x06000419 RID: 1049 RVA: 0x0000C960 File Offset: 0x0000AB60
		public virtual int Value
		{
			get
			{
				return this.val_;
			}
			set
			{
				this.val_ = value;
			}
		}

		// Token: 0x1700002D RID: 45
		// (set) Token: 0x0600041A RID: 1050 RVA: 0x0000C974 File Offset: 0x0000AB74
		internal bool Inverse
		{
			set
			{
				this.inverse_ = value;
			}
		}

		// Token: 0x1700002E RID: 46
		// (set) Token: 0x0600041B RID: 1051 RVA: 0x0000C988 File Offset: 0x0000AB88
		internal bool Matched
		{
			set
			{
				this.matched_ = value;
			}
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x0000C99C File Offset: 0x0000AB9C
		public virtual bool isInverse()
		{
			return this.inverse_;
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x0000C9B0 File Offset: 0x0000ABB0
		public virtual bool isMatched()
		{
			return this.matched_;
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x0000C9C4 File Offset: 0x0000ABC4
		internal void setValues(int type, int val, object target, string text, int guessing, bool inverse, bool matched)
		{
			base.setValues(type, guessing);
			this.Value = val;
			this.Target = target;
			this.Inverse = inverse;
			this.Matched = matched;
			this.Text = text;
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x0000CA00 File Offset: 0x0000AC00
		public override string ToString()
		{
			return string.Concat(new object[]
			{
				"ParserMatchEvent [",
				this.isMatched() ? "ok," : "bad,",
				this.isInverse() ? "NOT " : "",
				(this.Type == MatchEventArgs.TOKEN) ? "token," : "bitset,",
				this.Value,
				",",
				this.Target,
				",",
				this.Guessing,
				"]"
			});
		}

		// Token: 0x0400010E RID: 270
		public static int TOKEN = 0;

		// Token: 0x0400010F RID: 271
		public static int BITSET = 1;

		// Token: 0x04000110 RID: 272
		public static int CHAR = 2;

		// Token: 0x04000111 RID: 273
		public static int CHAR_BITSET = 3;

		// Token: 0x04000112 RID: 274
		public static int STRING = 4;

		// Token: 0x04000113 RID: 275
		public static int CHAR_RANGE = 5;

		// Token: 0x04000114 RID: 276
		private bool inverse_;

		// Token: 0x04000115 RID: 277
		private bool matched_;

		// Token: 0x04000116 RID: 278
		private object target_;

		// Token: 0x04000117 RID: 279
		private int val_;

		// Token: 0x04000118 RID: 280
		private string text_;

		// Token: 0x02000070 RID: 112
		public enum ParserMatchEnums
		{
			// Token: 0x0400011A RID: 282
			TOKEN,
			// Token: 0x0400011B RID: 283
			BITSET,
			// Token: 0x0400011C RID: 284
			CHAR,
			// Token: 0x0400011D RID: 285
			CHAR_BITSET,
			// Token: 0x0400011E RID: 286
			STRING,
			// Token: 0x0400011F RID: 287
			CHAR_RANGE
		}
	}
}
