﻿using System;
using System.Reflection;
using System.Threading;
using antlr.collections.impl;

namespace antlr.debug
{
	// Token: 0x02000059 RID: 89
	public class LLkDebuggingParser : LLkParser, DebuggingParser
	{
		// Token: 0x06000369 RID: 873 RVA: 0x0000ADB8 File Offset: 0x00008FB8
		private void InitBlock()
		{
			this.parserEventSupport = new ParserEventSupport(this);
		}

		// Token: 0x0600036A RID: 874 RVA: 0x0000ADD4 File Offset: 0x00008FD4
		public override void setDebugMode(bool mode)
		{
			this._notDebugMode = !mode;
		}

		// Token: 0x0600036B RID: 875 RVA: 0x0000ADEC File Offset: 0x00008FEC
		public LLkDebuggingParser(int k_) : base(k_)
		{
			this.InitBlock();
		}

		// Token: 0x0600036C RID: 876 RVA: 0x0000AE10 File Offset: 0x00009010
		public LLkDebuggingParser(ParserSharedInputState state, int k_) : base(state, k_)
		{
			this.InitBlock();
		}

		// Token: 0x0600036D RID: 877 RVA: 0x0000AE34 File Offset: 0x00009034
		public LLkDebuggingParser(TokenBuffer tokenBuf, int k_) : base(tokenBuf, k_)
		{
			this.InitBlock();
		}

		// Token: 0x0600036E RID: 878 RVA: 0x0000AE58 File Offset: 0x00009058
		public LLkDebuggingParser(TokenStream lexer, int k_) : base(lexer, k_)
		{
			this.InitBlock();
		}

		// Token: 0x0600036F RID: 879 RVA: 0x0000AE7C File Offset: 0x0000907C
		public override void addMessageListener(MessageListener l)
		{
			this.parserEventSupport.addMessageListener(l);
		}

		// Token: 0x06000370 RID: 880 RVA: 0x0000AE98 File Offset: 0x00009098
		public override void addParserListener(ParserListener l)
		{
			this.parserEventSupport.addParserListener(l);
		}

		// Token: 0x06000371 RID: 881 RVA: 0x0000AEB4 File Offset: 0x000090B4
		public override void addParserMatchListener(ParserMatchListener l)
		{
			this.parserEventSupport.addParserMatchListener(l);
		}

		// Token: 0x06000372 RID: 882 RVA: 0x0000AED0 File Offset: 0x000090D0
		public override void addParserTokenListener(ParserTokenListener l)
		{
			this.parserEventSupport.addParserTokenListener(l);
		}

		// Token: 0x06000373 RID: 883 RVA: 0x0000AEEC File Offset: 0x000090EC
		public override void addSemanticPredicateListener(SemanticPredicateListener l)
		{
			this.parserEventSupport.addSemanticPredicateListener(l);
		}

		// Token: 0x06000374 RID: 884 RVA: 0x0000AF08 File Offset: 0x00009108
		public override void addSyntacticPredicateListener(SyntacticPredicateListener l)
		{
			this.parserEventSupport.addSyntacticPredicateListener(l);
		}

		// Token: 0x06000375 RID: 885 RVA: 0x0000AF24 File Offset: 0x00009124
		public override void addTraceListener(TraceListener l)
		{
			this.parserEventSupport.addTraceListener(l);
		}

		// Token: 0x06000376 RID: 886 RVA: 0x0000AF40 File Offset: 0x00009140
		public override void consume()
		{
			int c = this.LA(1);
			base.consume();
			this.parserEventSupport.fireConsume(c);
		}

		// Token: 0x06000377 RID: 887 RVA: 0x0000AF6C File Offset: 0x0000916C
		protected internal virtual void fireEnterRule(int num, int data)
		{
			if (this.isDebugMode())
			{
				this.parserEventSupport.fireEnterRule(num, this.inputState.guessing, data);
			}
		}

		// Token: 0x06000378 RID: 888 RVA: 0x0000AF9C File Offset: 0x0000919C
		protected internal virtual void fireExitRule(int num, int data)
		{
			if (this.isDebugMode())
			{
				this.parserEventSupport.fireExitRule(num, this.inputState.guessing, data);
			}
		}

		// Token: 0x06000379 RID: 889 RVA: 0x0000AFCC File Offset: 0x000091CC
		protected internal virtual bool fireSemanticPredicateEvaluated(int type, int num, bool condition)
		{
			if (this.isDebugMode())
			{
				return this.parserEventSupport.fireSemanticPredicateEvaluated(type, num, condition, this.inputState.guessing);
			}
			return condition;
		}

		// Token: 0x0600037A RID: 890 RVA: 0x0000AFFC File Offset: 0x000091FC
		protected internal virtual void fireSyntacticPredicateFailed()
		{
			if (this.isDebugMode())
			{
				this.parserEventSupport.fireSyntacticPredicateFailed(this.inputState.guessing);
			}
		}

		// Token: 0x0600037B RID: 891 RVA: 0x0000B028 File Offset: 0x00009228
		protected internal virtual void fireSyntacticPredicateStarted()
		{
			if (this.isDebugMode())
			{
				this.parserEventSupport.fireSyntacticPredicateStarted(this.inputState.guessing);
			}
		}

		// Token: 0x0600037C RID: 892 RVA: 0x0000B054 File Offset: 0x00009254
		protected internal virtual void fireSyntacticPredicateSucceeded()
		{
			if (this.isDebugMode())
			{
				this.parserEventSupport.fireSyntacticPredicateSucceeded(this.inputState.guessing);
			}
		}

		// Token: 0x0600037D RID: 893 RVA: 0x0000B080 File Offset: 0x00009280
		public virtual string getRuleName(int num)
		{
			return this.ruleNames[num];
		}

		// Token: 0x0600037E RID: 894 RVA: 0x0000B098 File Offset: 0x00009298
		public virtual string getSemPredName(int num)
		{
			return this.semPredNames[num];
		}

		// Token: 0x0600037F RID: 895 RVA: 0x0000B0B0 File Offset: 0x000092B0
		public virtual void goToSleep()
		{
			lock (this)
			{
				try
				{
					Monitor.Wait(this);
				}
				catch (ThreadInterruptedException)
				{
				}
			}
		}

		// Token: 0x06000380 RID: 896 RVA: 0x0000B0F8 File Offset: 0x000092F8
		public override bool isDebugMode()
		{
			return !this._notDebugMode;
		}

		// Token: 0x06000381 RID: 897 RVA: 0x0000B110 File Offset: 0x00009310
		public virtual bool isGuessing()
		{
			return this.inputState.guessing > 0;
		}

		// Token: 0x06000382 RID: 898 RVA: 0x0000B12C File Offset: 0x0000932C
		public override int LA(int i)
		{
			int num = base.LA(i);
			this.parserEventSupport.fireLA(i, num);
			return num;
		}

		// Token: 0x06000383 RID: 899 RVA: 0x0000B150 File Offset: 0x00009350
		public override void match(int t)
		{
			string text = this.LT(1).getText();
			int i = this.LA(1);
			try
			{
				base.match(t);
				this.parserEventSupport.fireMatch(t, text, this.inputState.guessing);
			}
			catch (MismatchedTokenException ex)
			{
				if (this.inputState.guessing == 0)
				{
					this.parserEventSupport.fireMismatch(i, t, text, this.inputState.guessing);
				}
				throw ex;
			}
		}

		// Token: 0x06000384 RID: 900 RVA: 0x0000B1CC File Offset: 0x000093CC
		public override void match(BitSet b)
		{
			string text = this.LT(1).getText();
			int num = this.LA(1);
			try
			{
				base.match(b);
				this.parserEventSupport.fireMatch(num, b, text, this.inputState.guessing);
			}
			catch (MismatchedTokenException ex)
			{
				if (this.inputState.guessing == 0)
				{
					this.parserEventSupport.fireMismatch(num, b, text, this.inputState.guessing);
				}
				throw ex;
			}
		}

		// Token: 0x06000385 RID: 901 RVA: 0x0000B24C File Offset: 0x0000944C
		public override void matchNot(int t)
		{
			string text = this.LT(1).getText();
			int num = this.LA(1);
			try
			{
				base.matchNot(t);
				this.parserEventSupport.fireMatchNot(num, t, text, this.inputState.guessing);
			}
			catch (MismatchedTokenException ex)
			{
				if (this.inputState.guessing == 0)
				{
					this.parserEventSupport.fireMismatchNot(num, t, text, this.inputState.guessing);
				}
				throw ex;
			}
		}

		// Token: 0x06000386 RID: 902 RVA: 0x0000B2CC File Offset: 0x000094CC
		public override void removeMessageListener(MessageListener l)
		{
			this.parserEventSupport.removeMessageListener(l);
		}

		// Token: 0x06000387 RID: 903 RVA: 0x0000B2E8 File Offset: 0x000094E8
		public override void removeParserListener(ParserListener l)
		{
			this.parserEventSupport.removeParserListener(l);
		}

		// Token: 0x06000388 RID: 904 RVA: 0x0000B304 File Offset: 0x00009504
		public override void removeParserMatchListener(ParserMatchListener l)
		{
			this.parserEventSupport.removeParserMatchListener(l);
		}

		// Token: 0x06000389 RID: 905 RVA: 0x0000B320 File Offset: 0x00009520
		public override void removeParserTokenListener(ParserTokenListener l)
		{
			this.parserEventSupport.removeParserTokenListener(l);
		}

		// Token: 0x0600038A RID: 906 RVA: 0x0000B33C File Offset: 0x0000953C
		public override void removeSemanticPredicateListener(SemanticPredicateListener l)
		{
			this.parserEventSupport.removeSemanticPredicateListener(l);
		}

		// Token: 0x0600038B RID: 907 RVA: 0x0000B358 File Offset: 0x00009558
		public override void removeSyntacticPredicateListener(SyntacticPredicateListener l)
		{
			this.parserEventSupport.removeSyntacticPredicateListener(l);
		}

		// Token: 0x0600038C RID: 908 RVA: 0x0000B374 File Offset: 0x00009574
		public override void removeTraceListener(TraceListener l)
		{
			this.parserEventSupport.removeTraceListener(l);
		}

		// Token: 0x0600038D RID: 909 RVA: 0x0000B390 File Offset: 0x00009590
		public override void reportError(RecognitionException ex)
		{
			this.parserEventSupport.fireReportError(ex);
			base.reportError(ex);
		}

		// Token: 0x0600038E RID: 910 RVA: 0x0000B3B0 File Offset: 0x000095B0
		public override void reportError(string s)
		{
			this.parserEventSupport.fireReportError(s);
			base.reportError(s);
		}

		// Token: 0x0600038F RID: 911 RVA: 0x0000B3D0 File Offset: 0x000095D0
		public override void reportWarning(string s)
		{
			this.parserEventSupport.fireReportWarning(s);
			base.reportWarning(s);
		}

		// Token: 0x06000390 RID: 912 RVA: 0x0000B3F0 File Offset: 0x000095F0
		public virtual void setupDebugging(TokenBuffer tokenBuf)
		{
			this.setupDebugging(null, tokenBuf);
		}

		// Token: 0x06000391 RID: 913 RVA: 0x0000B408 File Offset: 0x00009608
		public virtual void setupDebugging(TokenStream lexer)
		{
			this.setupDebugging(lexer, null);
		}

		// Token: 0x06000392 RID: 914 RVA: 0x0000B420 File Offset: 0x00009620
		protected internal virtual void setupDebugging(TokenStream lexer, TokenBuffer tokenBuf)
		{
			this.setDebugMode(true);
			try
			{
				Type type = Type.GetType("antlr.parseview.ParseView");
				ConstructorInfo constructor = type.GetConstructor(new Type[]
				{
					typeof(LLkDebuggingParser),
					typeof(TokenStream),
					typeof(TokenBuffer)
				});
				constructor.Invoke(new object[]
				{
					this,
					lexer,
					tokenBuf
				});
			}
			catch (Exception arg)
			{
				Console.Error.WriteLine("Error initializing ParseView: " + arg);
				Console.Error.WriteLine("Please report this to Scott Stanchfield, thetick@magelang.com");
				Environment.Exit(1);
			}
		}

		// Token: 0x06000393 RID: 915 RVA: 0x0000B4D4 File Offset: 0x000096D4
		public virtual void wakeUp()
		{
			lock (this)
			{
				Monitor.Pulse(this);
			}
		}

		// Token: 0x040000FB RID: 251
		protected internal ParserEventSupport parserEventSupport;

		// Token: 0x040000FC RID: 252
		private bool _notDebugMode = false;

		// Token: 0x040000FD RID: 253
		protected internal string[] ruleNames;

		// Token: 0x040000FE RID: 254
		protected internal string[] semPredNames;
	}
}
