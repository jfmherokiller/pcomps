﻿using System;

namespace antlr.debug
{
	// Token: 0x02000058 RID: 88
	public class InputBufferReporter : InputBufferListenerBase, InputBufferListener, Listener
	{
		// Token: 0x06000363 RID: 867 RVA: 0x0000AD2C File Offset: 0x00008F2C
		public virtual void inputBufferChanged(object source, InputBufferEventArgs e)
		{
			Console.Out.WriteLine(e);
		}

		// Token: 0x06000364 RID: 868 RVA: 0x0000AD44 File Offset: 0x00008F44
		public override void inputBufferConsume(object source, InputBufferEventArgs e)
		{
			Console.Out.WriteLine(e);
		}

		// Token: 0x06000365 RID: 869 RVA: 0x0000AD5C File Offset: 0x00008F5C
		public override void inputBufferLA(object source, InputBufferEventArgs e)
		{
			Console.Out.WriteLine(e);
		}

		// Token: 0x06000366 RID: 870 RVA: 0x0000AD74 File Offset: 0x00008F74
		public override void inputBufferMark(object source, InputBufferEventArgs e)
		{
			Console.Out.WriteLine(e);
		}

		// Token: 0x06000367 RID: 871 RVA: 0x0000AD8C File Offset: 0x00008F8C
		public override void inputBufferRewind(object source, InputBufferEventArgs e)
		{
			Console.Out.WriteLine(e);
		}
	}
}
