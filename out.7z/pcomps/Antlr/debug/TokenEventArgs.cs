﻿using System;

namespace antlr.debug
{
	// Token: 0x02000075 RID: 117
	public class TokenEventArgs : ANTLREventArgs
	{
		// Token: 0x0600043F RID: 1087 RVA: 0x0000CE44 File Offset: 0x0000B044
		public TokenEventArgs()
		{
		}

		// Token: 0x06000440 RID: 1088 RVA: 0x0000CE58 File Offset: 0x0000B058
		public TokenEventArgs(int type, int amount, int val)
		{
			this.setValues(type, amount, val);
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x06000441 RID: 1089 RVA: 0x0000CE74 File Offset: 0x0000B074
		// (set) Token: 0x06000442 RID: 1090 RVA: 0x0000CE88 File Offset: 0x0000B088
		public virtual int Amount
		{
			get
			{
				return this.amount;
			}
			set
			{
				this.amount = value;
			}
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x06000443 RID: 1091 RVA: 0x0000CE9C File Offset: 0x0000B09C
		// (set) Token: 0x06000444 RID: 1092 RVA: 0x0000CEB0 File Offset: 0x0000B0B0
		public virtual int Value
		{
			get
			{
				return this.value_;
			}
			set
			{
				this.value_ = value;
			}
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x0000CEC4 File Offset: 0x0000B0C4
		internal void setValues(int type, int amount, int val)
		{
			base.setValues(type);
			this.Amount = amount;
			this.Value = val;
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x0000CEE8 File Offset: 0x0000B0E8
		public override string ToString()
		{
			if (this.Type == TokenEventArgs.LA)
			{
				return string.Concat(new object[]
				{
					"ParserTokenEvent [LA,",
					this.Amount,
					",",
					this.Value,
					"]"
				});
			}
			return "ParserTokenEvent [consume,1," + this.Value + "]";
		}

		// Token: 0x04000121 RID: 289
		private int value_;

		// Token: 0x04000122 RID: 290
		private int amount;

		// Token: 0x04000123 RID: 291
		public static int LA = 0;

		// Token: 0x04000124 RID: 292
		public static int CONSUME = 1;
	}
}
