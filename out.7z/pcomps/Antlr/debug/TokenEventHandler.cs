﻿using System;

namespace antlr.debug
{
	// Token: 0x02000069 RID: 105
	// (Invoke) Token: 0x060003C3 RID: 963
	public delegate void TokenEventHandler(object sender, TokenEventArgs e);
}
