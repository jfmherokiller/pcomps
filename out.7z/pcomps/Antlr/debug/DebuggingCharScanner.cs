﻿using System;
using System.Text;
using System.Threading;
using antlr.collections.impl;

namespace antlr.debug
{
	// Token: 0x02000050 RID: 80
	public abstract class DebuggingCharScanner : CharScanner, DebuggingParser
	{
		// Token: 0x06000305 RID: 773 RVA: 0x00009EE8 File Offset: 0x000080E8
		private void InitBlock()
		{
			this.eventSupport = new ScannerEventSupport(this);
		}

		// Token: 0x06000306 RID: 774 RVA: 0x00009F04 File Offset: 0x00008104
		public virtual void setDebugMode(bool mode)
		{
			this._notDebugMode = !mode;
		}

		// Token: 0x06000307 RID: 775 RVA: 0x00009F1C File Offset: 0x0000811C
		public DebuggingCharScanner(InputBuffer cb) : base(cb)
		{
			this.InitBlock();
		}

		// Token: 0x06000308 RID: 776 RVA: 0x00009F40 File Offset: 0x00008140
		public DebuggingCharScanner(LexerSharedInputState state) : base(state)
		{
			this.InitBlock();
		}

		// Token: 0x06000309 RID: 777 RVA: 0x00009F64 File Offset: 0x00008164
		public virtual void addMessageListener(MessageListener l)
		{
			this.eventSupport.addMessageListener(l);
		}

		// Token: 0x0600030A RID: 778 RVA: 0x00009F80 File Offset: 0x00008180
		public virtual void addNewLineListener(NewLineListener l)
		{
			this.eventSupport.addNewLineListener(l);
		}

		// Token: 0x0600030B RID: 779 RVA: 0x00009F9C File Offset: 0x0000819C
		public virtual void addParserListener(ParserListener l)
		{
			this.eventSupport.addParserListener(l);
		}

		// Token: 0x0600030C RID: 780 RVA: 0x00009FB8 File Offset: 0x000081B8
		public virtual void addParserMatchListener(ParserMatchListener l)
		{
			this.eventSupport.addParserMatchListener(l);
		}

		// Token: 0x0600030D RID: 781 RVA: 0x00009FD4 File Offset: 0x000081D4
		public virtual void addParserTokenListener(ParserTokenListener l)
		{
			this.eventSupport.addParserTokenListener(l);
		}

		// Token: 0x0600030E RID: 782 RVA: 0x00009FF0 File Offset: 0x000081F0
		public virtual void addSemanticPredicateListener(SemanticPredicateListener l)
		{
			this.eventSupport.addSemanticPredicateListener(l);
		}

		// Token: 0x0600030F RID: 783 RVA: 0x0000A00C File Offset: 0x0000820C
		public virtual void addSyntacticPredicateListener(SyntacticPredicateListener l)
		{
			this.eventSupport.addSyntacticPredicateListener(l);
		}

		// Token: 0x06000310 RID: 784 RVA: 0x0000A028 File Offset: 0x00008228
		public virtual void addTraceListener(TraceListener l)
		{
			this.eventSupport.addTraceListener(l);
		}

		// Token: 0x06000311 RID: 785 RVA: 0x0000A044 File Offset: 0x00008244
		public override void consume()
		{
			int c = -99;
			try
			{
				c = (int)this.LA(1);
			}
			catch (CharStreamException)
			{
			}
			base.consume();
			this.eventSupport.fireConsume(c);
		}

		// Token: 0x06000312 RID: 786 RVA: 0x0000A084 File Offset: 0x00008284
		protected internal virtual void fireEnterRule(int num, int data)
		{
			if (this.isDebugMode())
			{
				this.eventSupport.fireEnterRule(num, this.inputState.guessing, data);
			}
		}

		// Token: 0x06000313 RID: 787 RVA: 0x0000A0B4 File Offset: 0x000082B4
		protected internal virtual void fireExitRule(int num, int ttype)
		{
			if (this.isDebugMode())
			{
				this.eventSupport.fireExitRule(num, this.inputState.guessing, ttype);
			}
		}

		// Token: 0x06000314 RID: 788 RVA: 0x0000A0E4 File Offset: 0x000082E4
		protected internal virtual bool fireSemanticPredicateEvaluated(int type, int num, bool condition)
		{
			if (this.isDebugMode())
			{
				return this.eventSupport.fireSemanticPredicateEvaluated(type, num, condition, this.inputState.guessing);
			}
			return condition;
		}

		// Token: 0x06000315 RID: 789 RVA: 0x0000A114 File Offset: 0x00008314
		protected internal virtual void fireSyntacticPredicateFailed()
		{
			if (this.isDebugMode())
			{
				this.eventSupport.fireSyntacticPredicateFailed(this.inputState.guessing);
			}
		}

		// Token: 0x06000316 RID: 790 RVA: 0x0000A140 File Offset: 0x00008340
		protected internal virtual void fireSyntacticPredicateStarted()
		{
			if (this.isDebugMode())
			{
				this.eventSupport.fireSyntacticPredicateStarted(this.inputState.guessing);
			}
		}

		// Token: 0x06000317 RID: 791 RVA: 0x0000A16C File Offset: 0x0000836C
		protected internal virtual void fireSyntacticPredicateSucceeded()
		{
			if (this.isDebugMode())
			{
				this.eventSupport.fireSyntacticPredicateSucceeded(this.inputState.guessing);
			}
		}

		// Token: 0x06000318 RID: 792 RVA: 0x0000A198 File Offset: 0x00008398
		public virtual string getRuleName(int num)
		{
			return this.ruleNames[num];
		}

		// Token: 0x06000319 RID: 793 RVA: 0x0000A1B0 File Offset: 0x000083B0
		public virtual string getSemPredName(int num)
		{
			return this.semPredNames[num];
		}

		// Token: 0x0600031A RID: 794 RVA: 0x0000A1C8 File Offset: 0x000083C8
		public virtual void goToSleep()
		{
			lock (this)
			{
				try
				{
					Monitor.Wait(this);
				}
				catch (ThreadInterruptedException)
				{
				}
			}
		}

		// Token: 0x0600031B RID: 795 RVA: 0x0000A210 File Offset: 0x00008410
		public virtual bool isDebugMode()
		{
			return !this._notDebugMode;
		}

		// Token: 0x0600031C RID: 796 RVA: 0x0000A228 File Offset: 0x00008428
		public override char LA(int i)
		{
			char c = base.LA(i);
			this.eventSupport.fireLA(i, (int)c);
			return c;
		}

		// Token: 0x0600031D RID: 797 RVA: 0x0000A24C File Offset: 0x0000844C
		protected internal override IToken makeToken(int t)
		{
			return base.makeToken(t);
		}

		// Token: 0x0600031E RID: 798 RVA: 0x0000A260 File Offset: 0x00008460
		public override void match(int c)
		{
			char c2 = this.LA(1);
			try
			{
				base.match(c);
				this.eventSupport.fireMatch(Convert.ToChar(c), this.inputState.guessing);
			}
			catch (MismatchedCharException ex)
			{
				if (this.inputState.guessing == 0)
				{
					this.eventSupport.fireMismatch(c2, Convert.ToChar(c), this.inputState.guessing);
				}
				throw ex;
			}
		}

		// Token: 0x0600031F RID: 799 RVA: 0x0000A2D8 File Offset: 0x000084D8
		public override void match(BitSet b)
		{
			string text = this.text.ToString();
			char c = this.LA(1);
			try
			{
				base.match(b);
				this.eventSupport.fireMatch((int)c, b, text, this.inputState.guessing);
			}
			catch (MismatchedCharException ex)
			{
				if (this.inputState.guessing == 0)
				{
					this.eventSupport.fireMismatch((int)c, b, text, this.inputState.guessing);
				}
				throw ex;
			}
		}

		// Token: 0x06000320 RID: 800 RVA: 0x0000A354 File Offset: 0x00008554
		public override void match(string s)
		{
			StringBuilder stringBuilder = new StringBuilder("");
			int length = s.Length;
			try
			{
				for (int i = 1; i <= length; i++)
				{
					stringBuilder.Append(base.LA(i));
				}
			}
			catch (Exception)
			{
			}
			try
			{
				base.match(s);
				this.eventSupport.fireMatch(s, this.inputState.guessing);
			}
			catch (MismatchedCharException ex)
			{
				if (this.inputState.guessing == 0)
				{
					this.eventSupport.fireMismatch(stringBuilder.ToString(), s, this.inputState.guessing);
				}
				throw ex;
			}
		}

		// Token: 0x06000321 RID: 801 RVA: 0x0000A3FC File Offset: 0x000085FC
		public override void matchNot(int c)
		{
			char c2 = this.LA(1);
			try
			{
				base.matchNot(c);
				this.eventSupport.fireMatchNot(c2, Convert.ToChar(c), this.inputState.guessing);
			}
			catch (MismatchedCharException ex)
			{
				if (this.inputState.guessing == 0)
				{
					this.eventSupport.fireMismatchNot(c2, Convert.ToChar(c), this.inputState.guessing);
				}
				throw ex;
			}
		}

		// Token: 0x06000322 RID: 802 RVA: 0x0000A474 File Offset: 0x00008674
		public override void matchRange(int c1, int c2)
		{
			char c3 = this.LA(1);
			try
			{
				base.matchRange(c1, c2);
				this.eventSupport.fireMatch(c3, "" + c1 + c2, this.inputState.guessing);
			}
			catch (MismatchedCharException ex)
			{
				if (this.inputState.guessing == 0)
				{
					this.eventSupport.fireMismatch(c3, "" + c1 + c2, this.inputState.guessing);
				}
				throw ex;
			}
		}

		// Token: 0x06000323 RID: 803 RVA: 0x0000A510 File Offset: 0x00008710
		public override void newline()
		{
			base.newline();
			this.eventSupport.fireNewLine(this.getLine());
		}

		// Token: 0x06000324 RID: 804 RVA: 0x0000A534 File Offset: 0x00008734
		public virtual void removeMessageListener(MessageListener l)
		{
			this.eventSupport.removeMessageListener(l);
		}

		// Token: 0x06000325 RID: 805 RVA: 0x0000A550 File Offset: 0x00008750
		public virtual void removeNewLineListener(NewLineListener l)
		{
			this.eventSupport.removeNewLineListener(l);
		}

		// Token: 0x06000326 RID: 806 RVA: 0x0000A56C File Offset: 0x0000876C
		public virtual void removeParserListener(ParserListener l)
		{
			this.eventSupport.removeParserListener(l);
		}

		// Token: 0x06000327 RID: 807 RVA: 0x0000A588 File Offset: 0x00008788
		public virtual void removeParserMatchListener(ParserMatchListener l)
		{
			this.eventSupport.removeParserMatchListener(l);
		}

		// Token: 0x06000328 RID: 808 RVA: 0x0000A5A4 File Offset: 0x000087A4
		public virtual void removeParserTokenListener(ParserTokenListener l)
		{
			this.eventSupport.removeParserTokenListener(l);
		}

		// Token: 0x06000329 RID: 809 RVA: 0x0000A5C0 File Offset: 0x000087C0
		public virtual void removeSemanticPredicateListener(SemanticPredicateListener l)
		{
			this.eventSupport.removeSemanticPredicateListener(l);
		}

		// Token: 0x0600032A RID: 810 RVA: 0x0000A5DC File Offset: 0x000087DC
		public virtual void removeSyntacticPredicateListener(SyntacticPredicateListener l)
		{
			this.eventSupport.removeSyntacticPredicateListener(l);
		}

		// Token: 0x0600032B RID: 811 RVA: 0x0000A5F8 File Offset: 0x000087F8
		public virtual void removeTraceListener(TraceListener l)
		{
			this.eventSupport.removeTraceListener(l);
		}

		// Token: 0x0600032C RID: 812 RVA: 0x0000A614 File Offset: 0x00008814
		public virtual void reportError(MismatchedCharException e)
		{
			this.eventSupport.fireReportError(e);
			base.reportError(e);
		}

		// Token: 0x0600032D RID: 813 RVA: 0x0000A634 File Offset: 0x00008834
		public override void reportError(string s)
		{
			this.eventSupport.fireReportError(s);
			base.reportError(s);
		}

		// Token: 0x0600032E RID: 814 RVA: 0x0000A654 File Offset: 0x00008854
		public override void reportWarning(string s)
		{
			this.eventSupport.fireReportWarning(s);
			base.reportWarning(s);
		}

		// Token: 0x0600032F RID: 815 RVA: 0x0000A674 File Offset: 0x00008874
		public virtual void setupDebugging()
		{
		}

		// Token: 0x06000330 RID: 816 RVA: 0x0000A684 File Offset: 0x00008884
		public virtual void wakeUp()
		{
			lock (this)
			{
				Monitor.Pulse(this);
			}
		}

		// Token: 0x040000E6 RID: 230
		private ScannerEventSupport eventSupport;

		// Token: 0x040000E7 RID: 231
		private bool _notDebugMode = false;

		// Token: 0x040000E8 RID: 232
		protected internal string[] ruleNames;

		// Token: 0x040000E9 RID: 233
		protected internal string[] semPredNames;
	}
}
