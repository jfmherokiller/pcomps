﻿using System;

namespace antlr.debug
{
	// Token: 0x0200007A RID: 122
	public class SemanticPredicateListenerBase : SemanticPredicateListener, Listener
	{
		// Token: 0x06000493 RID: 1171 RVA: 0x0000E488 File Offset: 0x0000C688
		public virtual void doneParsing(object source, TraceEventArgs e)
		{
		}

		// Token: 0x06000494 RID: 1172 RVA: 0x0000E498 File Offset: 0x0000C698
		public virtual void refresh()
		{
		}

		// Token: 0x06000495 RID: 1173 RVA: 0x0000E4A8 File Offset: 0x0000C6A8
		public virtual void semanticPredicateEvaluated(object source, SemanticPredicateEventArgs e)
		{
		}
	}
}
