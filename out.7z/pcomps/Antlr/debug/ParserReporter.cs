﻿using System;

namespace antlr.debug
{
	// Token: 0x02000074 RID: 116
	public class ParserReporter : Tracer, ParserListener, SemanticPredicateListener, ParserMatchListener, MessageListener, ParserTokenListener, TraceListener, SyntacticPredicateListener, Listener
	{
		// Token: 0x06000432 RID: 1074 RVA: 0x0000CC80 File Offset: 0x0000AE80
		public virtual void parserConsume(object source, TokenEventArgs e)
		{
			Console.Out.WriteLine(this.indentString + e);
		}

		// Token: 0x06000433 RID: 1075 RVA: 0x0000CCA4 File Offset: 0x0000AEA4
		public virtual void parserLA(object source, TokenEventArgs e)
		{
			Console.Out.WriteLine(this.indentString + e);
		}

		// Token: 0x06000434 RID: 1076 RVA: 0x0000CCC8 File Offset: 0x0000AEC8
		public virtual void parserMatch(object source, MatchEventArgs e)
		{
			Console.Out.WriteLine(this.indentString + e);
		}

		// Token: 0x06000435 RID: 1077 RVA: 0x0000CCEC File Offset: 0x0000AEEC
		public virtual void parserMatchNot(object source, MatchEventArgs e)
		{
			Console.Out.WriteLine(this.indentString + e);
		}

		// Token: 0x06000436 RID: 1078 RVA: 0x0000CD10 File Offset: 0x0000AF10
		public virtual void parserMismatch(object source, MatchEventArgs e)
		{
			Console.Out.WriteLine(this.indentString + e);
		}

		// Token: 0x06000437 RID: 1079 RVA: 0x0000CD34 File Offset: 0x0000AF34
		public virtual void parserMismatchNot(object source, MatchEventArgs e)
		{
			Console.Out.WriteLine(this.indentString + e);
		}

		// Token: 0x06000438 RID: 1080 RVA: 0x0000CD58 File Offset: 0x0000AF58
		public virtual void reportError(object source, MessageEventArgs e)
		{
			Console.Out.WriteLine(this.indentString + e);
		}

		// Token: 0x06000439 RID: 1081 RVA: 0x0000CD7C File Offset: 0x0000AF7C
		public virtual void reportWarning(object source, MessageEventArgs e)
		{
			Console.Out.WriteLine(this.indentString + e);
		}

		// Token: 0x0600043A RID: 1082 RVA: 0x0000CDA0 File Offset: 0x0000AFA0
		public virtual void semanticPredicateEvaluated(object source, SemanticPredicateEventArgs e)
		{
			Console.Out.WriteLine(this.indentString + e);
		}

		// Token: 0x0600043B RID: 1083 RVA: 0x0000CDC4 File Offset: 0x0000AFC4
		public virtual void syntacticPredicateFailed(object source, SyntacticPredicateEventArgs e)
		{
			Console.Out.WriteLine(this.indentString + e);
		}

		// Token: 0x0600043C RID: 1084 RVA: 0x0000CDE8 File Offset: 0x0000AFE8
		public virtual void syntacticPredicateStarted(object source, SyntacticPredicateEventArgs e)
		{
			Console.Out.WriteLine(this.indentString + e);
		}

		// Token: 0x0600043D RID: 1085 RVA: 0x0000CE0C File Offset: 0x0000B00C
		public virtual void syntacticPredicateSucceeded(object source, SyntacticPredicateEventArgs e)
		{
			Console.Out.WriteLine(this.indentString + e);
		}
	}
}
