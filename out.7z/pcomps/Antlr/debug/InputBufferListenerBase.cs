﻿using System;

namespace antlr.debug
{
	// Token: 0x02000057 RID: 87
	public abstract class InputBufferListenerBase : InputBufferListener, Listener
	{
		// Token: 0x0600035C RID: 860 RVA: 0x0000ACB8 File Offset: 0x00008EB8
		public virtual void doneParsing(object source, TraceEventArgs e)
		{
		}

		// Token: 0x0600035D RID: 861 RVA: 0x0000ACC8 File Offset: 0x00008EC8
		public virtual void inputBufferConsume(object source, InputBufferEventArgs e)
		{
		}

		// Token: 0x0600035E RID: 862 RVA: 0x0000ACD8 File Offset: 0x00008ED8
		public virtual void inputBufferLA(object source, InputBufferEventArgs e)
		{
		}

		// Token: 0x0600035F RID: 863 RVA: 0x0000ACE8 File Offset: 0x00008EE8
		public virtual void inputBufferMark(object source, InputBufferEventArgs e)
		{
		}

		// Token: 0x06000360 RID: 864 RVA: 0x0000ACF8 File Offset: 0x00008EF8
		public virtual void inputBufferRewind(object source, InputBufferEventArgs e)
		{
		}

		// Token: 0x06000361 RID: 865 RVA: 0x0000AD08 File Offset: 0x00008F08
		public virtual void refresh()
		{
		}
	}
}
