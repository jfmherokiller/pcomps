﻿using System;

namespace antlr.debug
{
	// Token: 0x02000053 RID: 83
	public class InputBufferEventArgs : ANTLREventArgs
	{
		// Token: 0x06000342 RID: 834 RVA: 0x0000A8DC File Offset: 0x00008ADC
		public InputBufferEventArgs()
		{
		}

		// Token: 0x06000343 RID: 835 RVA: 0x0000A8F0 File Offset: 0x00008AF0
		public InputBufferEventArgs(int type, char c, int lookaheadAmount)
		{
			this.setValues(type, c, lookaheadAmount);
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x06000344 RID: 836 RVA: 0x0000A90C File Offset: 0x00008B0C
		// (set) Token: 0x06000345 RID: 837 RVA: 0x0000A920 File Offset: 0x00008B20
		public virtual char Char
		{
			get
			{
				return this.c_;
			}
			set
			{
				this.c_ = value;
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x06000346 RID: 838 RVA: 0x0000A934 File Offset: 0x00008B34
		// (set) Token: 0x06000347 RID: 839 RVA: 0x0000A948 File Offset: 0x00008B48
		public virtual int LookaheadAmount
		{
			get
			{
				return this.lookaheadAmount_;
			}
			set
			{
				this.lookaheadAmount_ = value;
			}
		}

		// Token: 0x06000348 RID: 840 RVA: 0x0000A95C File Offset: 0x00008B5C
		internal void setValues(int type, char c, int la)
		{
			base.setValues(type);
			this.Char = c;
			this.LookaheadAmount = la;
		}

		// Token: 0x06000349 RID: 841 RVA: 0x0000A980 File Offset: 0x00008B80
		public override string ToString()
		{
			return string.Concat(new object[]
			{
				"CharBufferEvent [",
				(this.Type == 0) ? "CONSUME, " : "LA, ",
				this.Char,
				",",
				this.LookaheadAmount,
				"]"
			});
		}

		// Token: 0x040000EE RID: 238
		public const int CONSUME = 0;

		// Token: 0x040000EF RID: 239
		public const int LA = 1;

		// Token: 0x040000F0 RID: 240
		public const int MARK = 2;

		// Token: 0x040000F1 RID: 241
		public const int REWIND = 3;

		// Token: 0x040000F2 RID: 242
		internal char c_;

		// Token: 0x040000F3 RID: 243
		internal int lookaheadAmount_;
	}
}
