﻿using System;

namespace antlr.debug
{
	// Token: 0x02000076 RID: 118
	public abstract class ParserTokenListenerBase : ParserTokenListener, Listener
	{
		// Token: 0x06000448 RID: 1096 RVA: 0x0000CF7C File Offset: 0x0000B17C
		public virtual void doneParsing(object source, TraceEventArgs e)
		{
		}

		// Token: 0x06000449 RID: 1097 RVA: 0x0000CF8C File Offset: 0x0000B18C
		public virtual void refresh()
		{
		}

		// Token: 0x0600044A RID: 1098 RVA: 0x0000CF9C File Offset: 0x0000B19C
		public virtual void parserConsume(object source, TokenEventArgs e)
		{
		}

		// Token: 0x0600044B RID: 1099 RVA: 0x0000CFAC File Offset: 0x0000B1AC
		public virtual void parserLA(object source, TokenEventArgs e)
		{
		}
	}
}
