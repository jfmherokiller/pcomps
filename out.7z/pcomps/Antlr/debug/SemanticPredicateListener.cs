﻿using System;

namespace antlr.debug
{
	// Token: 0x0200005F RID: 95
	public interface SemanticPredicateListener : Listener
	{
		// Token: 0x060003A8 RID: 936
		void semanticPredicateEvaluated(object source, SemanticPredicateEventArgs e);
	}
}
