﻿using System;

namespace antlr.debug
{
	// Token: 0x02000063 RID: 99
	public interface SyntacticPredicateListener : Listener
	{
		// Token: 0x060003B1 RID: 945
		void syntacticPredicateFailed(object source, SyntacticPredicateEventArgs e);

		// Token: 0x060003B2 RID: 946
		void syntacticPredicateStarted(object source, SyntacticPredicateEventArgs e);

		// Token: 0x060003B3 RID: 947
		void syntacticPredicateSucceeded(object source, SyntacticPredicateEventArgs e);
	}
}
