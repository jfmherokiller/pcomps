﻿using System;

namespace antlr.debug
{
	// Token: 0x02000067 RID: 103
	// (Invoke) Token: 0x060003BB RID: 955
	public delegate void NewLineEventHandler(object sender, NewLineEventArgs e);
}
