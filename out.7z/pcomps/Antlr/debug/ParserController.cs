﻿using System;

namespace antlr.debug
{
	// Token: 0x02000065 RID: 101
	public interface ParserController : ParserListener, SemanticPredicateListener, ParserMatchListener, MessageListener, ParserTokenListener, TraceListener, SyntacticPredicateListener, Listener
	{
		// Token: 0x17000029 RID: 41
		// (set) Token: 0x060003B4 RID: 948
		ParserEventSupport ParserEventSupport { set; }

		// Token: 0x060003B5 RID: 949
		void checkBreak();
	}
}
