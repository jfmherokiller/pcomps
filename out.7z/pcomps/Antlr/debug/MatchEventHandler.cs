﻿using System;

namespace antlr.debug
{
	// Token: 0x02000068 RID: 104
	// (Invoke) Token: 0x060003BF RID: 959
	public delegate void MatchEventHandler(object sender, MatchEventArgs e);
}
