﻿using System;

namespace antlr.debug
{
	// Token: 0x0200006B RID: 107
	// (Invoke) Token: 0x060003CB RID: 971
	public delegate void SyntacticPredicateEventHandler(object sender, SyntacticPredicateEventArgs e);
}
