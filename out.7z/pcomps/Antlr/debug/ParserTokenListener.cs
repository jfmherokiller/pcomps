﻿using System;

namespace antlr.debug
{
	// Token: 0x02000061 RID: 97
	public interface ParserTokenListener : Listener
	{
		// Token: 0x060003AD RID: 941
		void parserConsume(object source, TokenEventArgs e);

		// Token: 0x060003AE RID: 942
		void parserLA(object source, TokenEventArgs e);
	}
}
