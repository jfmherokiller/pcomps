﻿using System;

namespace antlr.debug
{
	// Token: 0x0200005C RID: 92
	public class MessageListenerBase : MessageListener, Listener
	{
		// Token: 0x0600039D RID: 925 RVA: 0x0000B5D4 File Offset: 0x000097D4
		public virtual void doneParsing(object source, TraceEventArgs e)
		{
		}

		// Token: 0x0600039E RID: 926 RVA: 0x0000B5E4 File Offset: 0x000097E4
		public virtual void refresh()
		{
		}

		// Token: 0x0600039F RID: 927 RVA: 0x0000B5F4 File Offset: 0x000097F4
		public virtual void reportError(object source, MessageEventArgs e)
		{
		}

		// Token: 0x060003A0 RID: 928 RVA: 0x0000B604 File Offset: 0x00009804
		public virtual void reportWarning(object source, MessageEventArgs e)
		{
		}
	}
}
