﻿using System;

namespace antlr.debug
{
	// Token: 0x02000015 RID: 21
	public interface ICharScannerDebugSubject : IDebugSubject
	{
		// Token: 0x1400000A RID: 10
		// (add) Token: 0x060000D2 RID: 210
		// (remove) Token: 0x060000D3 RID: 211
		event NewLineEventHandler HitNewLine;

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x060000D4 RID: 212
		// (remove) Token: 0x060000D5 RID: 213
		event MatchEventHandler MatchedChar;

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x060000D6 RID: 214
		// (remove) Token: 0x060000D7 RID: 215
		event MatchEventHandler MatchedNotChar;

		// Token: 0x1400000D RID: 13
		// (add) Token: 0x060000D8 RID: 216
		// (remove) Token: 0x060000D9 RID: 217
		event MatchEventHandler MisMatchedChar;

		// Token: 0x1400000E RID: 14
		// (add) Token: 0x060000DA RID: 218
		// (remove) Token: 0x060000DB RID: 219
		event MatchEventHandler MisMatchedNotChar;

		// Token: 0x1400000F RID: 15
		// (add) Token: 0x060000DC RID: 220
		// (remove) Token: 0x060000DD RID: 221
		event TokenEventHandler ConsumedChar;

		// Token: 0x14000010 RID: 16
		// (add) Token: 0x060000DE RID: 222
		// (remove) Token: 0x060000DF RID: 223
		event TokenEventHandler CharLA;
	}
}
