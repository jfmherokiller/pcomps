﻿using System;

namespace antlr.debug
{
	// Token: 0x0200005E RID: 94
	public interface NewLineListener : Listener
	{
		// Token: 0x060003A7 RID: 935
		void hitNewLine(object source, NewLineEventArgs e);
	}
}
