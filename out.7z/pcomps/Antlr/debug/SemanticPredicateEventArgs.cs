﻿using System;

namespace antlr.debug
{
	// Token: 0x02000079 RID: 121
	public class SemanticPredicateEventArgs : GuessingEventArgs
	{
		// Token: 0x0600048B RID: 1163 RVA: 0x0000E388 File Offset: 0x0000C588
		public SemanticPredicateEventArgs()
		{
		}

		// Token: 0x0600048C RID: 1164 RVA: 0x0000E39C File Offset: 0x0000C59C
		public SemanticPredicateEventArgs(int type) : base(type)
		{
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x0600048D RID: 1165 RVA: 0x0000E3B0 File Offset: 0x0000C5B0
		// (set) Token: 0x0600048E RID: 1166 RVA: 0x0000E3C4 File Offset: 0x0000C5C4
		public virtual int Condition
		{
			get
			{
				return this.condition_;
			}
			set
			{
				this.condition_ = value;
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x0600048F RID: 1167 RVA: 0x0000E3D8 File Offset: 0x0000C5D8
		// (set) Token: 0x06000490 RID: 1168 RVA: 0x0000E3EC File Offset: 0x0000C5EC
		public virtual bool Result
		{
			get
			{
				return this.result_;
			}
			set
			{
				this.result_ = value;
			}
		}

		// Token: 0x06000491 RID: 1169 RVA: 0x0000E400 File Offset: 0x0000C600
		internal void setValues(int type, int condition, bool result, int guessing)
		{
			base.setValues(type, guessing);
			this.Condition = condition;
			this.Result = result;
		}

		// Token: 0x06000492 RID: 1170 RVA: 0x0000E424 File Offset: 0x0000C624
		public override string ToString()
		{
			return string.Concat(new object[]
			{
				"SemanticPredicateEvent [",
				this.Condition,
				",",
				this.Result,
				",",
				this.Guessing,
				"]"
			});
		}

		// Token: 0x04000132 RID: 306
		public const int VALIDATING = 0;

		// Token: 0x04000133 RID: 307
		public const int PREDICTING = 1;

		// Token: 0x04000134 RID: 308
		private int condition_;

		// Token: 0x04000135 RID: 309
		private bool result_;
	}
}
