﻿using System;

namespace antlr.debug
{
	// Token: 0x02000060 RID: 96
	public interface ParserMatchListener : Listener
	{
		// Token: 0x060003A9 RID: 937
		void parserMatch(object source, MatchEventArgs e);

		// Token: 0x060003AA RID: 938
		void parserMatchNot(object source, MatchEventArgs e);

		// Token: 0x060003AB RID: 939
		void parserMismatch(object source, MatchEventArgs e);

		// Token: 0x060003AC RID: 940
		void parserMismatchNot(object source, MatchEventArgs e);
	}
}
