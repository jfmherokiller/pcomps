﻿using System;

namespace antlr.debug
{
	// Token: 0x02000062 RID: 98
	public interface TraceListener : Listener
	{
		// Token: 0x060003AF RID: 943
		void enterRule(object source, TraceEventArgs e);

		// Token: 0x060003B0 RID: 944
		void exitRule(object source, TraceEventArgs e);
	}
}
