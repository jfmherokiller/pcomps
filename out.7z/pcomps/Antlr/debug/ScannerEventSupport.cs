﻿using System;
using System.Collections;
using antlr.collections.impl;

namespace antlr.debug
{
	// Token: 0x02000078 RID: 120
	public class ScannerEventSupport
	{
		// Token: 0x06000459 RID: 1113 RVA: 0x0000D204 File Offset: 0x0000B404
		public ScannerEventSupport(object source)
		{
			this.matchEvent = new MatchEventArgs();
			this.messageEvent = new MessageEventArgs();
			this.tokenEvent = new TokenEventArgs();
			this.traceEvent = new TraceEventArgs();
			this.semPredEvent = new SemanticPredicateEventArgs();
			this.synPredEvent = new SyntacticPredicateEventArgs();
			this.newLineEvent = new NewLineEventArgs();
			this.listeners = new Hashtable();
			this.source = source;
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x0000D280 File Offset: 0x0000B480
		public virtual void checkController()
		{
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x0000D290 File Offset: 0x0000B490
		public virtual void addDoneListener(Listener l)
		{
			((CharScanner)this.source).Done += l.doneParsing;
			this.listeners[l] = l;
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x0000D2C8 File Offset: 0x0000B4C8
		public virtual void addMessageListener(MessageListener l)
		{
			((CharScanner)this.source).ErrorReported += l.reportError;
			((CharScanner)this.source).WarningReported += l.reportWarning;
			this.addDoneListener(l);
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x0000D318 File Offset: 0x0000B518
		public virtual void addNewLineListener(NewLineListener l)
		{
			((CharScanner)this.source).HitNewLine += l.hitNewLine;
			this.addDoneListener(l);
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x0000D34C File Offset: 0x0000B54C
		public virtual void addParserListener(ParserListener l)
		{
			ParserController parserController = l as ParserController;
			this.addParserMatchListener(l);
			this.addParserTokenListener(l);
			this.addMessageListener(l);
			this.addTraceListener(l);
			this.addSemanticPredicateListener(l);
			this.addSyntacticPredicateListener(l);
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x0000D38C File Offset: 0x0000B58C
		public virtual void addParserMatchListener(ParserMatchListener l)
		{
			((CharScanner)this.source).MatchedChar += l.parserMatch;
			((CharScanner)this.source).MatchedNotChar += l.parserMatchNot;
			((CharScanner)this.source).MisMatchedChar += l.parserMismatch;
			((CharScanner)this.source).MisMatchedNotChar += l.parserMismatchNot;
			this.addDoneListener(l);
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x0000D414 File Offset: 0x0000B614
		public virtual void addParserTokenListener(ParserTokenListener l)
		{
			((CharScanner)this.source).ConsumedChar += l.parserConsume;
			((CharScanner)this.source).CharLA += l.parserLA;
			this.addDoneListener(l);
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x0000D464 File Offset: 0x0000B664
		public virtual void addSemanticPredicateListener(SemanticPredicateListener l)
		{
			((CharScanner)this.source).SemPredEvaluated += l.semanticPredicateEvaluated;
			this.addDoneListener(l);
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x0000D498 File Offset: 0x0000B698
		public virtual void addSyntacticPredicateListener(SyntacticPredicateListener l)
		{
			((CharScanner)this.source).SynPredStarted += l.syntacticPredicateStarted;
			((CharScanner)this.source).SynPredFailed += l.syntacticPredicateFailed;
			((CharScanner)this.source).SynPredSucceeded += l.syntacticPredicateSucceeded;
			this.addDoneListener(l);
		}

		// Token: 0x06000463 RID: 1123 RVA: 0x0000D504 File Offset: 0x0000B704
		public virtual void addTraceListener(TraceListener l)
		{
			((CharScanner)this.source).EnterRule += l.enterRule;
			((CharScanner)this.source).ExitRule += l.exitRule;
			this.addDoneListener(l);
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x0000D554 File Offset: 0x0000B754
		public virtual void fireConsume(int c)
		{
			TokenEventHandler tokenEventHandler = (TokenEventHandler)((CharScanner)this.source).Events[Parser.LAEventKey];
			if (tokenEventHandler != null)
			{
				this.tokenEvent.setValues(TokenEventArgs.CONSUME, 1, c);
				tokenEventHandler(this.source, this.tokenEvent);
			}
			this.checkController();
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x0000D5B0 File Offset: 0x0000B7B0
		public virtual void fireDoneParsing()
		{
			TraceEventHandler traceEventHandler = (TraceEventHandler)((CharScanner)this.source).Events[Parser.DoneEventKey];
			if (traceEventHandler != null)
			{
				this.traceEvent.setValues(TraceEventArgs.DONE_PARSING, 0, 0, 0);
				traceEventHandler(this.source, this.traceEvent);
			}
			this.checkController();
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x0000D60C File Offset: 0x0000B80C
		public virtual void fireEnterRule(int ruleNum, int guessing, int data)
		{
			this.ruleDepth++;
			TraceEventHandler traceEventHandler = (TraceEventHandler)((CharScanner)this.source).Events[Parser.EnterRuleEventKey];
			if (traceEventHandler != null)
			{
				this.traceEvent.setValues(TraceEventArgs.ENTER, ruleNum, guessing, data);
				traceEventHandler(this.source, this.traceEvent);
			}
			this.checkController();
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x0000D678 File Offset: 0x0000B878
		public virtual void fireExitRule(int ruleNum, int guessing, int data)
		{
			TraceEventHandler traceEventHandler = (TraceEventHandler)((CharScanner)this.source).Events[Parser.ExitRuleEventKey];
			if (traceEventHandler != null)
			{
				this.traceEvent.setValues(TraceEventArgs.EXIT, ruleNum, guessing, data);
				traceEventHandler(this.source, this.traceEvent);
			}
			this.checkController();
			this.ruleDepth--;
			if (this.ruleDepth == 0)
			{
				this.fireDoneParsing();
			}
		}

		// Token: 0x06000468 RID: 1128 RVA: 0x0000D6F0 File Offset: 0x0000B8F0
		public virtual void fireLA(int k, int la)
		{
			TokenEventHandler tokenEventHandler = (TokenEventHandler)((CharScanner)this.source).Events[Parser.LAEventKey];
			if (tokenEventHandler != null)
			{
				this.tokenEvent.setValues(TokenEventArgs.LA, k, la);
				tokenEventHandler(this.source, this.tokenEvent);
			}
			this.checkController();
		}

		// Token: 0x06000469 RID: 1129 RVA: 0x0000D74C File Offset: 0x0000B94C
		public virtual void fireMatch(char c, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR, (int)c, c, null, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x0000D7B0 File Offset: 0x0000B9B0
		public virtual void fireMatch(char c, BitSet b, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR_BITSET, (int)c, b, null, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x0000D810 File Offset: 0x0000BA10
		public virtual void fireMatch(char c, string target, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR_RANGE, (int)c, target, null, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x0600046C RID: 1132 RVA: 0x0000D870 File Offset: 0x0000BA70
		public virtual void fireMatch(int c, BitSet b, string text, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.BITSET, c, b, text, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x0600046D RID: 1133 RVA: 0x0000D8D0 File Offset: 0x0000BAD0
		public virtual void fireMatch(int n, string text, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.TOKEN, n, n, text, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x0600046E RID: 1134 RVA: 0x0000D934 File Offset: 0x0000BB34
		public virtual void fireMatch(string s, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.STRING, 0, s, null, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x0600046F RID: 1135 RVA: 0x0000D994 File Offset: 0x0000BB94
		public virtual void fireMatchNot(char c, char n, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MatchNotEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR, (int)c, n, null, guessing, true, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x0000D9F8 File Offset: 0x0000BBF8
		public virtual void fireMatchNot(int c, int n, string text, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MatchNotEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.TOKEN, c, n, text, guessing, true, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x06000471 RID: 1137 RVA: 0x0000DA5C File Offset: 0x0000BC5C
		public virtual void fireMismatch(char c, char n, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MisMatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR, (int)c, n, null, guessing, false, false);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x0000DAC0 File Offset: 0x0000BCC0
		public virtual void fireMismatch(char c, BitSet b, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MisMatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR_BITSET, (int)c, b, null, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x06000473 RID: 1139 RVA: 0x0000DB20 File Offset: 0x0000BD20
		public virtual void fireMismatch(char c, string target, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MisMatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR_RANGE, (int)c, target, null, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x06000474 RID: 1140 RVA: 0x0000DB80 File Offset: 0x0000BD80
		public virtual void fireMismatch(int i, int n, string text, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MisMatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.TOKEN, i, n, text, guessing, false, false);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x06000475 RID: 1141 RVA: 0x0000DBE4 File Offset: 0x0000BDE4
		public virtual void fireMismatch(int i, BitSet b, string text, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MisMatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.BITSET, i, b, text, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x06000476 RID: 1142 RVA: 0x0000DC44 File Offset: 0x0000BE44
		public virtual void fireMismatch(string s, string text, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MisMatchEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.STRING, 0, text, s, guessing, false, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x06000477 RID: 1143 RVA: 0x0000DCA4 File Offset: 0x0000BEA4
		public virtual void fireMismatchNot(char v, char c, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MisMatchNotEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.CHAR, (int)v, c, null, guessing, true, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x06000478 RID: 1144 RVA: 0x0000DD08 File Offset: 0x0000BF08
		public virtual void fireMismatchNot(int i, int n, string text, int guessing)
		{
			MatchEventHandler matchEventHandler = (MatchEventHandler)((CharScanner)this.source).Events[Parser.MisMatchNotEventKey];
			if (matchEventHandler != null)
			{
				this.matchEvent.setValues(MatchEventArgs.TOKEN, i, n, text, guessing, true, true);
				matchEventHandler(this.source, this.matchEvent);
			}
			this.checkController();
		}

		// Token: 0x06000479 RID: 1145 RVA: 0x0000DD6C File Offset: 0x0000BF6C
		public virtual void fireNewLine(int line)
		{
			NewLineEventHandler newLineEventHandler = (NewLineEventHandler)((CharScanner)this.source).Events[Parser.NewLineEventKey];
			if (newLineEventHandler != null)
			{
				this.newLineEvent.Line = line;
				newLineEventHandler(this.source, this.newLineEvent);
			}
			this.checkController();
		}

		// Token: 0x0600047A RID: 1146 RVA: 0x0000DDC0 File Offset: 0x0000BFC0
		public virtual void fireReportError(Exception e)
		{
			MessageEventHandler messageEventHandler = (MessageEventHandler)((CharScanner)this.source).Events[Parser.ReportErrorEventKey];
			if (messageEventHandler != null)
			{
				this.messageEvent.setValues(MessageEventArgs.ERROR, e.ToString());
				messageEventHandler(this.source, this.messageEvent);
			}
			this.checkController();
		}

		// Token: 0x0600047B RID: 1147 RVA: 0x0000DE20 File Offset: 0x0000C020
		public virtual void fireReportError(string s)
		{
			MessageEventHandler messageEventHandler = (MessageEventHandler)((CharScanner)this.source).Events[Parser.ReportErrorEventKey];
			if (messageEventHandler != null)
			{
				this.messageEvent.setValues(MessageEventArgs.ERROR, s);
				messageEventHandler(this.source, this.messageEvent);
			}
			this.checkController();
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x0000DE7C File Offset: 0x0000C07C
		public virtual void fireReportWarning(string s)
		{
			MessageEventHandler messageEventHandler = (MessageEventHandler)((CharScanner)this.source).Events[Parser.ReportWarningEventKey];
			if (messageEventHandler != null)
			{
				this.messageEvent.setValues(MessageEventArgs.WARNING, s);
				messageEventHandler(this.source, this.messageEvent);
			}
			this.checkController();
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x0000DED8 File Offset: 0x0000C0D8
		public virtual bool fireSemanticPredicateEvaluated(int type, int condition, bool result, int guessing)
		{
			SemanticPredicateEventHandler semanticPredicateEventHandler = (SemanticPredicateEventHandler)((CharScanner)this.source).Events[Parser.SemPredEvaluatedEventKey];
			if (semanticPredicateEventHandler != null)
			{
				this.semPredEvent.setValues(type, condition, result, guessing);
				semanticPredicateEventHandler(this.source, this.semPredEvent);
			}
			this.checkController();
			return result;
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x0000DF34 File Offset: 0x0000C134
		public virtual void fireSyntacticPredicateFailed(int guessing)
		{
			SyntacticPredicateEventHandler syntacticPredicateEventHandler = (SyntacticPredicateEventHandler)((CharScanner)this.source).Events[Parser.SynPredFailedEventKey];
			if (syntacticPredicateEventHandler != null)
			{
				this.synPredEvent.setValues(0, guessing);
				syntacticPredicateEventHandler(this.source, this.synPredEvent);
			}
			this.checkController();
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x0000DF8C File Offset: 0x0000C18C
		public virtual void fireSyntacticPredicateStarted(int guessing)
		{
			SyntacticPredicateEventHandler syntacticPredicateEventHandler = (SyntacticPredicateEventHandler)((CharScanner)this.source).Events[Parser.SynPredStartedEventKey];
			if (syntacticPredicateEventHandler != null)
			{
				this.synPredEvent.setValues(0, guessing);
				syntacticPredicateEventHandler(this.source, this.synPredEvent);
			}
			this.checkController();
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x0000DFE4 File Offset: 0x0000C1E4
		public virtual void fireSyntacticPredicateSucceeded(int guessing)
		{
			SyntacticPredicateEventHandler syntacticPredicateEventHandler = (SyntacticPredicateEventHandler)((CharScanner)this.source).Events[Parser.SynPredSucceededEventKey];
			if (syntacticPredicateEventHandler != null)
			{
				this.synPredEvent.setValues(0, guessing);
				syntacticPredicateEventHandler(this.source, this.synPredEvent);
			}
			this.checkController();
		}

		// Token: 0x06000481 RID: 1153 RVA: 0x0000E03C File Offset: 0x0000C23C
		public virtual void refreshListeners()
		{
			Hashtable hashtable;
			lock (this.listeners.SyncRoot)
			{
				hashtable = (Hashtable)this.listeners.Clone();
			}
			foreach (object obj in hashtable)
			{
				Listener listener = (Listener)obj;
				listener.refresh();
			}
		}

		// Token: 0x06000482 RID: 1154 RVA: 0x0000E0CC File Offset: 0x0000C2CC
		public virtual void removeDoneListener(Listener l)
		{
			((CharScanner)this.source).Done -= l.doneParsing;
			this.listeners.Remove(l);
		}

		// Token: 0x06000483 RID: 1155 RVA: 0x0000E104 File Offset: 0x0000C304
		public virtual void removeMessageListener(MessageListener l)
		{
			((CharScanner)this.source).ErrorReported -= l.reportError;
			((CharScanner)this.source).WarningReported -= l.reportWarning;
			this.removeDoneListener(l);
		}

		// Token: 0x06000484 RID: 1156 RVA: 0x0000E154 File Offset: 0x0000C354
		public virtual void removeNewLineListener(NewLineListener l)
		{
			((CharScanner)this.source).HitNewLine -= l.hitNewLine;
			this.removeDoneListener(l);
		}

		// Token: 0x06000485 RID: 1157 RVA: 0x0000E188 File Offset: 0x0000C388
		public virtual void removeParserListener(ParserListener l)
		{
			this.removeParserMatchListener(l);
			this.removeMessageListener(l);
			this.removeParserTokenListener(l);
			this.removeTraceListener(l);
			this.removeSemanticPredicateListener(l);
			this.removeSyntacticPredicateListener(l);
		}

		// Token: 0x06000486 RID: 1158 RVA: 0x0000E1C0 File Offset: 0x0000C3C0
		public virtual void removeParserMatchListener(ParserMatchListener l)
		{
			((CharScanner)this.source).MatchedChar -= l.parserMatch;
			((CharScanner)this.source).MatchedNotChar -= l.parserMatchNot;
			((CharScanner)this.source).MisMatchedChar -= l.parserMismatch;
			((CharScanner)this.source).MisMatchedNotChar -= l.parserMismatchNot;
			this.removeDoneListener(l);
		}

		// Token: 0x06000487 RID: 1159 RVA: 0x0000E248 File Offset: 0x0000C448
		public virtual void removeParserTokenListener(ParserTokenListener l)
		{
			((CharScanner)this.source).ConsumedChar -= l.parserConsume;
			((CharScanner)this.source).CharLA -= l.parserLA;
			this.removeDoneListener(l);
		}

		// Token: 0x06000488 RID: 1160 RVA: 0x0000E298 File Offset: 0x0000C498
		public virtual void removeSemanticPredicateListener(SemanticPredicateListener l)
		{
			((CharScanner)this.source).SemPredEvaluated -= l.semanticPredicateEvaluated;
			this.removeDoneListener(l);
		}

		// Token: 0x06000489 RID: 1161 RVA: 0x0000E2CC File Offset: 0x0000C4CC
		public virtual void removeSyntacticPredicateListener(SyntacticPredicateListener l)
		{
			((CharScanner)this.source).SynPredStarted -= l.syntacticPredicateStarted;
			((CharScanner)this.source).SynPredFailed -= l.syntacticPredicateFailed;
			((CharScanner)this.source).SynPredSucceeded -= l.syntacticPredicateSucceeded;
			this.removeDoneListener(l);
		}

		// Token: 0x0600048A RID: 1162 RVA: 0x0000E338 File Offset: 0x0000C538
		public virtual void removeTraceListener(TraceListener l)
		{
			((CharScanner)this.source).EnterRule -= l.enterRule;
			((CharScanner)this.source).ExitRule -= l.exitRule;
			this.removeDoneListener(l);
		}

		// Token: 0x04000128 RID: 296
		private object source;

		// Token: 0x04000129 RID: 297
		private Hashtable listeners;

		// Token: 0x0400012A RID: 298
		private MatchEventArgs matchEvent;

		// Token: 0x0400012B RID: 299
		private MessageEventArgs messageEvent;

		// Token: 0x0400012C RID: 300
		private TokenEventArgs tokenEvent;

		// Token: 0x0400012D RID: 301
		private SemanticPredicateEventArgs semPredEvent;

		// Token: 0x0400012E RID: 302
		private SyntacticPredicateEventArgs synPredEvent;

		// Token: 0x0400012F RID: 303
		private TraceEventArgs traceEvent;

		// Token: 0x04000130 RID: 304
		private NewLineEventArgs newLineEvent;

		// Token: 0x04000131 RID: 305
		private int ruleDepth = 0;
	}
}
