﻿using System;

namespace antlr.debug
{
	// Token: 0x02000066 RID: 102
	// (Invoke) Token: 0x060003B7 RID: 951
	public delegate void MessageEventHandler(object sender, MessageEventArgs e);
}
