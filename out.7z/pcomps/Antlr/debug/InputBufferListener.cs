﻿using System;

namespace antlr.debug
{
	// Token: 0x02000056 RID: 86
	public interface InputBufferListener : Listener
	{
		// Token: 0x06000358 RID: 856
		void inputBufferConsume(object source, InputBufferEventArgs e);

		// Token: 0x06000359 RID: 857
		void inputBufferLA(object source, InputBufferEventArgs e);

		// Token: 0x0600035A RID: 858
		void inputBufferMark(object source, InputBufferEventArgs e);

		// Token: 0x0600035B RID: 859
		void inputBufferRewind(object source, InputBufferEventArgs e);
	}
}
