﻿using System;

namespace antlr.debug
{
	// Token: 0x02000073 RID: 115
	public class Tracer : TraceListenerBase, TraceListener, Listener
	{
		// Token: 0x0600042D RID: 1069 RVA: 0x0000CBA8 File Offset: 0x0000ADA8
		protected internal virtual void dedent()
		{
			if (this.indentString.Length < 2)
			{
				this.indentString = "";
				return;
			}
			this.indentString = this.indentString.Substring(2);
		}

		// Token: 0x0600042E RID: 1070 RVA: 0x0000CBE4 File Offset: 0x0000ADE4
		public override void enterRule(object source, TraceEventArgs e)
		{
			Console.Out.WriteLine(this.indentString + e);
			this.indent();
		}

		// Token: 0x0600042F RID: 1071 RVA: 0x0000CC10 File Offset: 0x0000AE10
		public override void exitRule(object source, TraceEventArgs e)
		{
			this.dedent();
			Console.Out.WriteLine(this.indentString + e);
		}

		// Token: 0x06000430 RID: 1072 RVA: 0x0000CC3C File Offset: 0x0000AE3C
		protected internal virtual void indent()
		{
			this.indentString += "  ";
		}

		// Token: 0x04000120 RID: 288
		protected string indentString = "";
	}
}
