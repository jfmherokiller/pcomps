﻿using System;

namespace antlr.debug
{
	// Token: 0x0200006A RID: 106
	// (Invoke) Token: 0x060003C7 RID: 967
	public delegate void SemanticPredicateEventHandler(object sender, SemanticPredicateEventArgs e);
}
