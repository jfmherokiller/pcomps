﻿using System;
using System.Collections;

namespace antlr.debug
{
	// Token: 0x02000051 RID: 81
	public class DebuggingInputBuffer : InputBuffer
	{
		// Token: 0x17000021 RID: 33
		// (get) Token: 0x06000331 RID: 817 RVA: 0x0000A6B8 File Offset: 0x000088B8
		public virtual ArrayList InputBufferListeners
		{
			get
			{
				return this.inputBufferEventSupport.InputBufferListeners;
			}
		}

		// Token: 0x17000022 RID: 34
		// (set) Token: 0x06000332 RID: 818 RVA: 0x0000A6D0 File Offset: 0x000088D0
		public virtual bool DebugMode
		{
			set
			{
				this.debugMode = value;
			}
		}

		// Token: 0x06000333 RID: 819 RVA: 0x0000A6E4 File Offset: 0x000088E4
		public DebuggingInputBuffer(InputBuffer buffer)
		{
			this.buffer = buffer;
			this.inputBufferEventSupport = new InputBufferEventSupport(this);
		}

		// Token: 0x06000334 RID: 820 RVA: 0x0000A714 File Offset: 0x00008914
		public virtual void addInputBufferListener(InputBufferListener l)
		{
			this.inputBufferEventSupport.addInputBufferListener(l);
		}

		// Token: 0x06000335 RID: 821 RVA: 0x0000A730 File Offset: 0x00008930
		public override char consume()
		{
			char c = ' ';
			try
			{
				c = this.buffer.LA(1);
			}
			catch (CharStreamException)
			{
			}
			this.buffer.consume();
			if (this.debugMode)
			{
				this.inputBufferEventSupport.fireConsume(c);
			}
			return c;
		}

		// Token: 0x06000336 RID: 822 RVA: 0x0000A784 File Offset: 0x00008984
		public override void fill(int a)
		{
			this.buffer.fill(a);
		}

		// Token: 0x06000337 RID: 823 RVA: 0x0000A7A0 File Offset: 0x000089A0
		public virtual bool isDebugMode()
		{
			return this.debugMode;
		}

		// Token: 0x06000338 RID: 824 RVA: 0x0000A7B4 File Offset: 0x000089B4
		public override bool isMarked()
		{
			return this.buffer.isMarked();
		}

		// Token: 0x06000339 RID: 825 RVA: 0x0000A7CC File Offset: 0x000089CC
		public override char LA(int i)
		{
			char c = this.buffer.LA(i);
			if (this.debugMode)
			{
				this.inputBufferEventSupport.fireLA(c, i);
			}
			return c;
		}

		// Token: 0x0600033A RID: 826 RVA: 0x0000A7FC File Offset: 0x000089FC
		public override int mark()
		{
			int num = this.buffer.mark();
			this.inputBufferEventSupport.fireMark(num);
			return num;
		}

		// Token: 0x0600033B RID: 827 RVA: 0x0000A824 File Offset: 0x00008A24
		public virtual void removeInputBufferListener(InputBufferListener l)
		{
			if (this.inputBufferEventSupport != null)
			{
				this.inputBufferEventSupport.removeInputBufferListener(l);
			}
		}

		// Token: 0x0600033C RID: 828 RVA: 0x0000A848 File Offset: 0x00008A48
		public override void rewind(int mark)
		{
			this.buffer.rewind(mark);
			this.inputBufferEventSupport.fireRewind(mark);
		}

		// Token: 0x040000EA RID: 234
		private InputBuffer buffer;

		// Token: 0x040000EB RID: 235
		private InputBufferEventSupport inputBufferEventSupport;

		// Token: 0x040000EC RID: 236
		private bool debugMode = true;
	}
}
