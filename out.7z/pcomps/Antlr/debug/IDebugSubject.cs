﻿using System;

namespace antlr.debug
{
	// Token: 0x02000014 RID: 20
	public interface IDebugSubject
	{
		// Token: 0x14000001 RID: 1
		// (add) Token: 0x060000C0 RID: 192
		// (remove) Token: 0x060000C1 RID: 193
		event TraceEventHandler EnterRule;

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x060000C2 RID: 194
		// (remove) Token: 0x060000C3 RID: 195
		event TraceEventHandler ExitRule;

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x060000C4 RID: 196
		// (remove) Token: 0x060000C5 RID: 197
		event TraceEventHandler Done;

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x060000C6 RID: 198
		// (remove) Token: 0x060000C7 RID: 199
		event MessageEventHandler ErrorReported;

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x060000C8 RID: 200
		// (remove) Token: 0x060000C9 RID: 201
		event MessageEventHandler WarningReported;

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x060000CA RID: 202
		// (remove) Token: 0x060000CB RID: 203
		event SemanticPredicateEventHandler SemPredEvaluated;

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x060000CC RID: 204
		// (remove) Token: 0x060000CD RID: 205
		event SyntacticPredicateEventHandler SynPredStarted;

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x060000CE RID: 206
		// (remove) Token: 0x060000CF RID: 207
		event SyntacticPredicateEventHandler SynPredFailed;

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x060000D0 RID: 208
		// (remove) Token: 0x060000D1 RID: 209
		event SyntacticPredicateEventHandler SynPredSucceeded;
	}
}
