﻿using System;

namespace antlr.debug
{
	// Token: 0x0200005A RID: 90
	public class MessageEventArgs : ANTLREventArgs
	{
		// Token: 0x06000394 RID: 916 RVA: 0x0000B508 File Offset: 0x00009708
		public MessageEventArgs()
		{
		}

		// Token: 0x06000395 RID: 917 RVA: 0x0000B51C File Offset: 0x0000971C
		public MessageEventArgs(int type, string text)
		{
			this.setValues(type, text);
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x06000396 RID: 918 RVA: 0x0000B538 File Offset: 0x00009738
		// (set) Token: 0x06000397 RID: 919 RVA: 0x0000B54C File Offset: 0x0000974C
		public virtual string Text
		{
			get
			{
				return this.text_;
			}
			set
			{
				this.text_ = value;
			}
		}

		// Token: 0x06000398 RID: 920 RVA: 0x0000B560 File Offset: 0x00009760
		internal void setValues(int type, string text)
		{
			base.setValues(type);
			this.Text = text;
		}

		// Token: 0x06000399 RID: 921 RVA: 0x0000B57C File Offset: 0x0000977C
		public override string ToString()
		{
			return "ParserMessageEvent [" + ((this.Type == MessageEventArgs.WARNING) ? "warning," : "error,") + this.Text + "]";
		}

		// Token: 0x040000FF RID: 255
		private string text_;

		// Token: 0x04000100 RID: 256
		public static int WARNING = 0;

		// Token: 0x04000101 RID: 257
		public static int ERROR = 1;
	}
}
