﻿using System;

namespace antlr.debug
{
	// Token: 0x0200007C RID: 124
	public abstract class SyntacticPredicateListenerBase : SyntacticPredicateListener, Listener
	{
		// Token: 0x0600049A RID: 1178 RVA: 0x0000E51C File Offset: 0x0000C71C
		public virtual void doneParsing(object source, TraceEventArgs e)
		{
		}

		// Token: 0x0600049B RID: 1179 RVA: 0x0000E52C File Offset: 0x0000C72C
		public virtual void refresh()
		{
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x0000E53C File Offset: 0x0000C73C
		public virtual void syntacticPredicateFailed(object source, SyntacticPredicateEventArgs e)
		{
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x0000E54C File Offset: 0x0000C74C
		public virtual void syntacticPredicateStarted(object source, SyntacticPredicateEventArgs e)
		{
		}

		// Token: 0x0600049E RID: 1182 RVA: 0x0000E55C File Offset: 0x0000C75C
		public virtual void syntacticPredicateSucceeded(object source, SyntacticPredicateEventArgs e)
		{
		}
	}
}
