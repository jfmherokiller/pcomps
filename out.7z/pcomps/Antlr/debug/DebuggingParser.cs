﻿using System;

namespace antlr.debug
{
	// Token: 0x0200004F RID: 79
	public interface DebuggingParser
	{
		// Token: 0x06000303 RID: 771
		string getRuleName(int n);

		// Token: 0x06000304 RID: 772
		string getSemPredName(int n);
	}
}
