﻿using System;
using System.Collections;
using antlr.collections.impl;

namespace antlr.debug
{
	// Token: 0x02000077 RID: 119
	public class ParseTreeDebugParser : LLkParser
	{
		// Token: 0x0600044D RID: 1101 RVA: 0x0000CFD0 File Offset: 0x0000B1D0
		public ParseTreeDebugParser(int k_) : base(k_)
		{
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x0000D000 File Offset: 0x0000B200
		public ParseTreeDebugParser(ParserSharedInputState state, int k_) : base(state, k_)
		{
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x0000D030 File Offset: 0x0000B230
		public ParseTreeDebugParser(TokenBuffer tokenBuf, int k_) : base(tokenBuf, k_)
		{
		}

		// Token: 0x06000450 RID: 1104 RVA: 0x0000D060 File Offset: 0x0000B260
		public ParseTreeDebugParser(TokenStream lexer, int k_) : base(lexer, k_)
		{
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x0000D090 File Offset: 0x0000B290
		public ParseTree getParseTree()
		{
			return this.mostRecentParseTreeRoot;
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x0000D0A4 File Offset: 0x0000B2A4
		public int getNumberOfDerivationSteps()
		{
			return this.numberOfDerivationSteps;
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x0000D0B8 File Offset: 0x0000B2B8
		public override void match(int i)
		{
			this.addCurrentTokenToParseTree();
			base.match(i);
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x0000D0D4 File Offset: 0x0000B2D4
		public override void match(BitSet bitSet)
		{
			this.addCurrentTokenToParseTree();
			base.match(bitSet);
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x0000D0F0 File Offset: 0x0000B2F0
		public override void matchNot(int i)
		{
			this.addCurrentTokenToParseTree();
			base.matchNot(i);
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x0000D10C File Offset: 0x0000B30C
		protected void addCurrentTokenToParseTree()
		{
			if (this.inputState.guessing > 0)
			{
				return;
			}
			ParseTreeRule parseTreeRule = (ParseTreeRule)this.currentParseTreeRoot.Peek();
			ParseTreeToken node;
			if (this.LA(1) == 1)
			{
				node = new ParseTreeToken(new CommonToken("EOF"));
			}
			else
			{
				node = new ParseTreeToken(this.LT(1));
			}
			parseTreeRule.addChild(node);
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x0000D16C File Offset: 0x0000B36C
		public override void traceIn(string s)
		{
			if (this.inputState.guessing > 0)
			{
				return;
			}
			ParseTreeRule parseTreeRule = new ParseTreeRule(s);
			if (this.currentParseTreeRoot.Count > 0)
			{
				ParseTreeRule parseTreeRule2 = (ParseTreeRule)this.currentParseTreeRoot.Peek();
				parseTreeRule2.addChild(parseTreeRule);
			}
			this.currentParseTreeRoot.Push(parseTreeRule);
			this.numberOfDerivationSteps++;
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x0000D1D0 File Offset: 0x0000B3D0
		public override void traceOut(string s)
		{
			if (this.inputState.guessing > 0)
			{
				return;
			}
			this.mostRecentParseTreeRoot = (ParseTreeRule)this.currentParseTreeRoot.Pop();
		}

		// Token: 0x04000125 RID: 293
		protected Stack currentParseTreeRoot = new Stack();

		// Token: 0x04000126 RID: 294
		protected ParseTreeRule mostRecentParseTreeRoot = null;

		// Token: 0x04000127 RID: 295
		protected int numberOfDerivationSteps = 1;
	}
}
