﻿using System;

namespace antlr.debug
{
	// Token: 0x02000055 RID: 85
	public interface Listener
	{
		// Token: 0x06000356 RID: 854
		void doneParsing(object source, TraceEventArgs e);

		// Token: 0x06000357 RID: 855
		void refresh();
	}
}
