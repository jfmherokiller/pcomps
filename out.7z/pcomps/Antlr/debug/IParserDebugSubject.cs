﻿using System;

namespace antlr.debug
{
	// Token: 0x0200002A RID: 42
	public interface IParserDebugSubject : IDebugSubject
	{
		// Token: 0x14000021 RID: 33
		// (add) Token: 0x060001B0 RID: 432
		// (remove) Token: 0x060001B1 RID: 433
		event MatchEventHandler MatchedToken;

		// Token: 0x14000022 RID: 34
		// (add) Token: 0x060001B2 RID: 434
		// (remove) Token: 0x060001B3 RID: 435
		event MatchEventHandler MatchedNotToken;

		// Token: 0x14000023 RID: 35
		// (add) Token: 0x060001B4 RID: 436
		// (remove) Token: 0x060001B5 RID: 437
		event MatchEventHandler MisMatchedToken;

		// Token: 0x14000024 RID: 36
		// (add) Token: 0x060001B6 RID: 438
		// (remove) Token: 0x060001B7 RID: 439
		event MatchEventHandler MisMatchedNotToken;

		// Token: 0x14000025 RID: 37
		// (add) Token: 0x060001B8 RID: 440
		// (remove) Token: 0x060001B9 RID: 441
		event TokenEventHandler ConsumedToken;

		// Token: 0x14000026 RID: 38
		// (add) Token: 0x060001BA RID: 442
		// (remove) Token: 0x060001BB RID: 443
		event TokenEventHandler TokenLA;
	}
}
