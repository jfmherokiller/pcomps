﻿using System;

namespace antlr.debug
{
	// Token: 0x0200006C RID: 108
	// (Invoke) Token: 0x060003CF RID: 975
	public delegate void TraceEventHandler(object sender, TraceEventArgs e);
}
