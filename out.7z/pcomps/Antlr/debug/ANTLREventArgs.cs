﻿using System;

namespace antlr.debug
{
	// Token: 0x0200004E RID: 78
	public abstract class ANTLREventArgs : EventArgs
	{
		// Token: 0x060002FE RID: 766 RVA: 0x00009E7C File Offset: 0x0000807C
		public ANTLREventArgs()
		{
		}

		// Token: 0x060002FF RID: 767 RVA: 0x00009E90 File Offset: 0x00008090
		public ANTLREventArgs(int type)
		{
			this.Type = type;
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x06000300 RID: 768 RVA: 0x00009EAC File Offset: 0x000080AC
		// (set) Token: 0x06000301 RID: 769 RVA: 0x00009EC0 File Offset: 0x000080C0
		public virtual int Type
		{
			get
			{
				return this.type_;
			}
			set
			{
				this.type_ = value;
			}
		}

		// Token: 0x06000302 RID: 770 RVA: 0x00009ED4 File Offset: 0x000080D4
		internal void setValues(int type)
		{
			this.Type = type;
		}

		// Token: 0x040000E5 RID: 229
		private int type_;
	}
}
