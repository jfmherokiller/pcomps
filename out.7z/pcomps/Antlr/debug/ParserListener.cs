﻿using System;

namespace antlr.debug
{
	// Token: 0x02000064 RID: 100
	public interface ParserListener : SemanticPredicateListener, ParserMatchListener, MessageListener, ParserTokenListener, TraceListener, SyntacticPredicateListener, Listener
	{
	}
}
