﻿using System;

namespace antlr
{
	// Token: 0x02000041 RID: 65
	[Serializable]
	public class TokenStreamRetryException : TokenStreamException
	{
	}
}
