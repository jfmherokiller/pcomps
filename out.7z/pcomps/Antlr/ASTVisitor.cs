﻿using System;
using antlr.collections;

namespace antlr
{
	// Token: 0x0200000D RID: 13
	public interface ASTVisitor
	{
		// Token: 0x0600007D RID: 125
		void visit(AST node);
	}
}
