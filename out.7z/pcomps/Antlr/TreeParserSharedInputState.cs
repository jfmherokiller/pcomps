﻿using System;

namespace antlr
{
	// Token: 0x0200004B RID: 75
	public class TreeParserSharedInputState
	{
		// Token: 0x060002D3 RID: 723 RVA: 0x000094E4 File Offset: 0x000076E4
		public virtual void reset()
		{
			this.guessing = 0;
		}

		// Token: 0x040000DD RID: 221
		public int guessing = 0;
	}
}
