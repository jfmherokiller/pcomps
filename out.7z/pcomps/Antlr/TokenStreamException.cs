﻿using System;

namespace antlr
{
	// Token: 0x0200003D RID: 61
	[Serializable]
	public class TokenStreamException : ANTLRException
	{
		// Token: 0x06000265 RID: 613 RVA: 0x00008340 File Offset: 0x00006540
		public TokenStreamException()
		{
		}

		// Token: 0x06000266 RID: 614 RVA: 0x00008354 File Offset: 0x00006554
		public TokenStreamException(string s) : base(s)
		{
		}
	}
}
