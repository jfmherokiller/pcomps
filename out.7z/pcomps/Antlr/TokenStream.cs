﻿using System;

namespace antlr
{
	// Token: 0x02000013 RID: 19
	public interface TokenStream
	{
		// Token: 0x060000BF RID: 191
		IToken nextToken();
	}
}
