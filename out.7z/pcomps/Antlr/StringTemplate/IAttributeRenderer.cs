﻿using System;

namespace Antlr.StringTemplate
{
	// Token: 0x0200021D RID: 541
	public interface IAttributeRenderer
	{
		// Token: 0x06000F54 RID: 3924
		string ToString(object o);

		// Token: 0x06000F55 RID: 3925
		string ToString(object o, string formatName);
	}
}
