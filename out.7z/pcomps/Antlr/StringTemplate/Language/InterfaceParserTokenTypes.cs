﻿using System;

namespace Antlr.StringTemplate.Language
{
	// Token: 0x02000247 RID: 583
	public class InterfaceParserTokenTypes
	{
		// Token: 0x04000EEC RID: 3820
		public const int EOF = 1;

		// Token: 0x04000EED RID: 3821
		public const int NULL_TREE_LOOKAHEAD = 3;

		// Token: 0x04000EEE RID: 3822
		public const int LITERAL_interface = 4;

		// Token: 0x04000EEF RID: 3823
		public const int ID = 5;

		// Token: 0x04000EF0 RID: 3824
		public const int SEMI = 6;

		// Token: 0x04000EF1 RID: 3825
		public const int LITERAL_optional = 7;

		// Token: 0x04000EF2 RID: 3826
		public const int LPAREN = 8;

		// Token: 0x04000EF3 RID: 3827
		public const int RPAREN = 9;

		// Token: 0x04000EF4 RID: 3828
		public const int COMMA = 10;

		// Token: 0x04000EF5 RID: 3829
		public const int COLON = 11;

		// Token: 0x04000EF6 RID: 3830
		public const int SL_COMMENT = 12;

		// Token: 0x04000EF7 RID: 3831
		public const int ML_COMMENT = 13;

		// Token: 0x04000EF8 RID: 3832
		public const int WS = 14;
	}
}
