﻿using System;

namespace Antlr.StringTemplate.Language
{
	// Token: 0x02000244 RID: 580
	public class GroupParserTokenTypes
	{
		// Token: 0x04000EB2 RID: 3762
		public const int EOF = 1;

		// Token: 0x04000EB3 RID: 3763
		public const int NULL_TREE_LOOKAHEAD = 3;

		// Token: 0x04000EB4 RID: 3764
		public const int LITERAL_group = 4;

		// Token: 0x04000EB5 RID: 3765
		public const int ID = 5;

		// Token: 0x04000EB6 RID: 3766
		public const int COLON = 6;

		// Token: 0x04000EB7 RID: 3767
		public const int LITERAL_implements = 7;

		// Token: 0x04000EB8 RID: 3768
		public const int COMMA = 8;

		// Token: 0x04000EB9 RID: 3769
		public const int SEMI = 9;

		// Token: 0x04000EBA RID: 3770
		public const int AT = 10;

		// Token: 0x04000EBB RID: 3771
		public const int DOT = 11;

		// Token: 0x04000EBC RID: 3772
		public const int LPAREN = 12;

		// Token: 0x04000EBD RID: 3773
		public const int RPAREN = 13;

		// Token: 0x04000EBE RID: 3774
		public const int DEFINED_TO_BE = 14;

		// Token: 0x04000EBF RID: 3775
		public const int STRING = 15;

		// Token: 0x04000EC0 RID: 3776
		public const int BIGSTRING = 16;

		// Token: 0x04000EC1 RID: 3777
		public const int ASSIGN = 17;

		// Token: 0x04000EC2 RID: 3778
		public const int ANONYMOUS_TEMPLATE = 18;

		// Token: 0x04000EC3 RID: 3779
		public const int LBRACK = 19;

		// Token: 0x04000EC4 RID: 3780
		public const int RBRACK = 20;

		// Token: 0x04000EC5 RID: 3781
		public const int LITERAL_default = 21;

		// Token: 0x04000EC6 RID: 3782
		public const int STAR = 22;

		// Token: 0x04000EC7 RID: 3783
		public const int PLUS = 23;

		// Token: 0x04000EC8 RID: 3784
		public const int OPTIONAL = 24;

		// Token: 0x04000EC9 RID: 3785
		public const int SL_COMMENT = 25;

		// Token: 0x04000ECA RID: 3786
		public const int ML_COMMENT = 26;

		// Token: 0x04000ECB RID: 3787
		public const int WS = 27;
	}
}
