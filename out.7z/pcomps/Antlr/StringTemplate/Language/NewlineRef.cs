﻿using System;

namespace Antlr.StringTemplate.Language
{
	// Token: 0x02000249 RID: 585
	public class NewlineRef : StringRef
	{
		// Token: 0x060011B7 RID: 4535 RVA: 0x00082274 File Offset: 0x00080474
		public NewlineRef(StringTemplate enclosingTemplate, string str) : base(enclosingTemplate, str)
		{
		}
	}
}
