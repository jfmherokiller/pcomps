﻿using System;

namespace Antlr.StringTemplate
{
	// Token: 0x02000216 RID: 534
	public class Constants
	{
		// Token: 0x04000CC0 RID: 3264
		public const int TEMPLATE_WRITER_NO_WRAP = -1;
	}
}
