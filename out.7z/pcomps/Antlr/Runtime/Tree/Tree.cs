﻿using System;

namespace Antlr.Runtime.Tree
{
	// Token: 0x020000A9 RID: 169
	public sealed class Tree
	{
		// Token: 0x040001B6 RID: 438
		public static readonly ITree INVALID_NODE = new CommonTree(Token.INVALID_TOKEN);
	}
}
