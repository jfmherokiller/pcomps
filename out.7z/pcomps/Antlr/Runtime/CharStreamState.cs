﻿using System;

namespace Antlr.Runtime
{
	// Token: 0x02000084 RID: 132
	public class CharStreamState
	{
		// Token: 0x0400014B RID: 331
		internal int p;

		// Token: 0x0400014C RID: 332
		internal int line;

		// Token: 0x0400014D RID: 333
		internal int charPositionInLine;
	}
}
