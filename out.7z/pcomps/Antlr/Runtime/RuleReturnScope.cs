﻿using System;

namespace Antlr.Runtime
{
	// Token: 0x02000095 RID: 149
	public class RuleReturnScope
	{
		// Token: 0x17000061 RID: 97
		// (get) Token: 0x06000576 RID: 1398 RVA: 0x00010294 File Offset: 0x0000E494
		// (set) Token: 0x06000577 RID: 1399 RVA: 0x00010298 File Offset: 0x0000E498
		public virtual object Start
		{
			get
			{
				return null;
			}
			set
			{
				throw new NotSupportedException("Setter has not been defined for this property.");
			}
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06000578 RID: 1400 RVA: 0x000102A4 File Offset: 0x0000E4A4
		// (set) Token: 0x06000579 RID: 1401 RVA: 0x000102A8 File Offset: 0x0000E4A8
		public virtual object Stop
		{
			get
			{
				return null;
			}
			set
			{
				throw new NotSupportedException("Setter has not been defined for this property.");
			}
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x0600057A RID: 1402 RVA: 0x000102B4 File Offset: 0x0000E4B4
		// (set) Token: 0x0600057B RID: 1403 RVA: 0x000102B8 File Offset: 0x0000E4B8
		public virtual object Tree
		{
			get
			{
				return null;
			}
			set
			{
				throw new NotSupportedException("Setter has not been defined for this property.");
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x0600057C RID: 1404 RVA: 0x000102C4 File Offset: 0x0000E4C4
		public virtual object Template
		{
			get
			{
				return null;
			}
		}
	}
}
