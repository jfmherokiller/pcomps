﻿using System;

namespace Antlr.Runtime
{
	// Token: 0x020000E9 RID: 233
	// (Invoke) Token: 0x06000983 RID: 2435
	public delegate void SynPredPointer();
}
