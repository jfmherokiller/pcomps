﻿using System;

namespace Antlr.Runtime
{
	// Token: 0x020000B4 RID: 180
	internal sealed class Constants
	{
		// Token: 0x040001D4 RID: 468
		public static readonly string VERSION = "3.1b1";

		// Token: 0x040001D5 RID: 469
		public static readonly string DEBUG_PROTOCOL_VERSION = "2";

		// Token: 0x040001D6 RID: 470
		public static readonly string ANTLRWORKS_DIR = "antlrworks";
	}
}
