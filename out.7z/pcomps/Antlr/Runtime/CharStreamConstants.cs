﻿using System;

namespace Antlr.Runtime
{
	// Token: 0x02000082 RID: 130
	public enum CharStreamConstants
	{
		// Token: 0x0400014A RID: 330
		EOF = -1
	}
}
