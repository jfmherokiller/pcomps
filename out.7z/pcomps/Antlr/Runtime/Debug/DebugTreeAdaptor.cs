﻿using System;
using Antlr.Runtime.Tree;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000B3 RID: 179
	public class DebugTreeAdaptor : ITreeAdaptor
	{
		// Token: 0x06000721 RID: 1825 RVA: 0x00013AC8 File Offset: 0x00011CC8
		public DebugTreeAdaptor(IDebugEventListener dbg, ITreeAdaptor adaptor)
		{
			this.dbg = dbg;
			this.adaptor = adaptor;
		}

		// Token: 0x06000722 RID: 1826 RVA: 0x00013AE0 File Offset: 0x00011CE0
		public object Create(IToken payload)
		{
			if (payload.TokenIndex < 0)
			{
				return this.Create(payload.Type, payload.Text);
			}
			object obj = this.adaptor.Create(payload);
			this.dbg.CreateNode(obj, payload);
			return obj;
		}

		// Token: 0x06000723 RID: 1827 RVA: 0x00013B28 File Offset: 0x00011D28
		public object ErrorNode(ITokenStream input, IToken start, IToken stop, RecognitionException e)
		{
			object obj = this.adaptor.ErrorNode(input, start, stop, e);
			if (obj != null)
			{
				this.dbg.ErrorNode(obj);
			}
			return obj;
		}

		// Token: 0x06000724 RID: 1828 RVA: 0x00013B5C File Offset: 0x00011D5C
		public object DupTree(object tree)
		{
			object obj = this.adaptor.DupTree(tree);
			this.SimulateTreeConstruction(obj);
			return obj;
		}

		// Token: 0x06000725 RID: 1829 RVA: 0x00013B80 File Offset: 0x00011D80
		protected void SimulateTreeConstruction(object t)
		{
			this.dbg.CreateNode(t);
			int childCount = this.adaptor.GetChildCount(t);
			for (int i = 0; i < childCount; i++)
			{
				object child = this.adaptor.GetChild(t, i);
				this.SimulateTreeConstruction(child);
				this.dbg.AddChild(t, child);
			}
		}

		// Token: 0x06000726 RID: 1830 RVA: 0x00013BDC File Offset: 0x00011DDC
		public object DupNode(object treeNode)
		{
			object obj = this.adaptor.DupNode(treeNode);
			this.dbg.CreateNode(obj);
			return obj;
		}

		// Token: 0x06000727 RID: 1831 RVA: 0x00013C04 File Offset: 0x00011E04
		public object GetNilNode()
		{
			object nilNode = this.adaptor.GetNilNode();
			this.dbg.GetNilNode(nilNode);
			return nilNode;
		}

		// Token: 0x06000728 RID: 1832 RVA: 0x00013C2C File Offset: 0x00011E2C
		public bool IsNil(object tree)
		{
			return this.adaptor.IsNil(tree);
		}

		// Token: 0x06000729 RID: 1833 RVA: 0x00013C3C File Offset: 0x00011E3C
		public void AddChild(object t, object child)
		{
			if (t == null || child == null)
			{
				return;
			}
			this.adaptor.AddChild(t, child);
			this.dbg.AddChild(t, child);
		}

		// Token: 0x0600072A RID: 1834 RVA: 0x00013C68 File Offset: 0x00011E68
		public object BecomeRoot(object newRoot, object oldRoot)
		{
			object result = this.adaptor.BecomeRoot(newRoot, oldRoot);
			this.dbg.BecomeRoot(newRoot, oldRoot);
			return result;
		}

		// Token: 0x0600072B RID: 1835 RVA: 0x00013C94 File Offset: 0x00011E94
		public object RulePostProcessing(object root)
		{
			return this.adaptor.RulePostProcessing(root);
		}

		// Token: 0x0600072C RID: 1836 RVA: 0x00013CA4 File Offset: 0x00011EA4
		public void AddChild(object t, IToken child)
		{
			object child2 = this.Create(child);
			this.AddChild(t, child2);
		}

		// Token: 0x0600072D RID: 1837 RVA: 0x00013CC4 File Offset: 0x00011EC4
		public object BecomeRoot(IToken newRoot, object oldRoot)
		{
			object obj = this.Create(newRoot);
			this.adaptor.BecomeRoot(obj, oldRoot);
			this.dbg.BecomeRoot(newRoot, oldRoot);
			return obj;
		}

		// Token: 0x0600072E RID: 1838 RVA: 0x00013CF8 File Offset: 0x00011EF8
		public object Create(int tokenType, IToken fromToken)
		{
			object obj = this.adaptor.Create(tokenType, fromToken);
			this.dbg.CreateNode(obj);
			return obj;
		}

		// Token: 0x0600072F RID: 1839 RVA: 0x00013D20 File Offset: 0x00011F20
		public object Create(int tokenType, IToken fromToken, string text)
		{
			object obj = this.adaptor.Create(tokenType, fromToken, text);
			this.dbg.CreateNode(obj);
			return obj;
		}

		// Token: 0x06000730 RID: 1840 RVA: 0x00013D4C File Offset: 0x00011F4C
		public object Create(int tokenType, string text)
		{
			object obj = this.adaptor.Create(tokenType, text);
			this.dbg.CreateNode(obj);
			return obj;
		}

		// Token: 0x06000731 RID: 1841 RVA: 0x00013D74 File Offset: 0x00011F74
		public int GetNodeType(object t)
		{
			return this.adaptor.GetNodeType(t);
		}

		// Token: 0x06000732 RID: 1842 RVA: 0x00013D84 File Offset: 0x00011F84
		public void SetNodeType(object t, int type)
		{
			this.adaptor.SetNodeType(t, type);
		}

		// Token: 0x06000733 RID: 1843 RVA: 0x00013D94 File Offset: 0x00011F94
		public string GetNodeText(object t)
		{
			return this.adaptor.GetNodeText(t);
		}

		// Token: 0x06000734 RID: 1844 RVA: 0x00013DA4 File Offset: 0x00011FA4
		public void SetNodeText(object t, string text)
		{
			this.adaptor.SetNodeText(t, text);
		}

		// Token: 0x06000735 RID: 1845 RVA: 0x00013DB4 File Offset: 0x00011FB4
		public IToken GetToken(object treeNode)
		{
			return this.adaptor.GetToken(treeNode);
		}

		// Token: 0x06000736 RID: 1846 RVA: 0x00013DC4 File Offset: 0x00011FC4
		public void SetTokenBoundaries(object t, IToken startToken, IToken stopToken)
		{
			this.adaptor.SetTokenBoundaries(t, startToken, stopToken);
			if (t != null && startToken != null && stopToken != null)
			{
				this.dbg.SetTokenBoundaries(t, startToken.TokenIndex, stopToken.TokenIndex);
			}
		}

		// Token: 0x06000737 RID: 1847 RVA: 0x00013E0C File Offset: 0x0001200C
		public int GetTokenStartIndex(object t)
		{
			return this.adaptor.GetTokenStartIndex(t);
		}

		// Token: 0x06000738 RID: 1848 RVA: 0x00013E1C File Offset: 0x0001201C
		public int GetTokenStopIndex(object t)
		{
			return this.adaptor.GetTokenStopIndex(t);
		}

		// Token: 0x06000739 RID: 1849 RVA: 0x00013E2C File Offset: 0x0001202C
		public object GetChild(object t, int i)
		{
			return this.adaptor.GetChild(t, i);
		}

		// Token: 0x0600073A RID: 1850 RVA: 0x00013E3C File Offset: 0x0001203C
		public void SetChild(object t, int i, object child)
		{
			this.adaptor.SetChild(t, i, child);
		}

		// Token: 0x0600073B RID: 1851 RVA: 0x00013E4C File Offset: 0x0001204C
		public object DeleteChild(object t, int i)
		{
			return this.adaptor.DeleteChild(t, i);
		}

		// Token: 0x0600073C RID: 1852 RVA: 0x00013E5C File Offset: 0x0001205C
		public int GetChildCount(object t)
		{
			return this.adaptor.GetChildCount(t);
		}

		// Token: 0x0600073D RID: 1853 RVA: 0x00013E6C File Offset: 0x0001206C
		public int GetUniqueID(object node)
		{
			return this.adaptor.GetUniqueID(node);
		}

		// Token: 0x0600073E RID: 1854 RVA: 0x00013E7C File Offset: 0x0001207C
		public object GetParent(object t)
		{
			return this.adaptor.GetParent(t);
		}

		// Token: 0x0600073F RID: 1855 RVA: 0x00013E8C File Offset: 0x0001208C
		public int GetChildIndex(object t)
		{
			return this.adaptor.GetChildIndex(t);
		}

		// Token: 0x06000740 RID: 1856 RVA: 0x00013E9C File Offset: 0x0001209C
		public void SetParent(object t, object parent)
		{
			this.adaptor.SetParent(t, parent);
		}

		// Token: 0x06000741 RID: 1857 RVA: 0x00013EAC File Offset: 0x000120AC
		public void SetChildIndex(object t, int index)
		{
			this.adaptor.SetChildIndex(t, index);
		}

		// Token: 0x06000742 RID: 1858 RVA: 0x00013EBC File Offset: 0x000120BC
		public void ReplaceChildren(object parent, int startChildIndex, int stopChildIndex, object t)
		{
			this.adaptor.ReplaceChildren(parent, startChildIndex, stopChildIndex, t);
		}

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x06000743 RID: 1859 RVA: 0x00013ED0 File Offset: 0x000120D0
		// (set) Token: 0x06000744 RID: 1860 RVA: 0x00013ED8 File Offset: 0x000120D8
		public IDebugEventListener DebugListener
		{
			get
			{
				return this.dbg;
			}
			set
			{
				this.dbg = value;
			}
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x06000745 RID: 1861 RVA: 0x00013EE4 File Offset: 0x000120E4
		public ITreeAdaptor TreeAdaptor
		{
			get
			{
				return this.adaptor;
			}
		}

		// Token: 0x040001D2 RID: 466
		protected IDebugEventListener dbg;

		// Token: 0x040001D3 RID: 467
		protected ITreeAdaptor adaptor;
	}
}
