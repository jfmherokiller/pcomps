﻿using System;
using System.Collections;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000BC RID: 188
	public class DebugEventHub : IDebugEventListener
	{
		// Token: 0x060007B8 RID: 1976 RVA: 0x000154D8 File Offset: 0x000136D8
		public DebugEventHub(IDebugEventListener listener)
		{
			this.listeners.Add(listener);
		}

		// Token: 0x060007B9 RID: 1977 RVA: 0x000154F8 File Offset: 0x000136F8
		public DebugEventHub(params IDebugEventListener[] listeners)
		{
			foreach (IDebugEventListener value in listeners)
			{
				this.listeners.Add(value);
			}
		}

		// Token: 0x060007BA RID: 1978 RVA: 0x00015540 File Offset: 0x00013740
		public void AddListener(IDebugEventListener listener)
		{
			this.listeners.Add(listener);
		}

		// Token: 0x060007BB RID: 1979 RVA: 0x00015550 File Offset: 0x00013750
		public void EnterRule(string grammarFileName, string ruleName)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.EnterRule(grammarFileName, ruleName);
			}
		}

		// Token: 0x060007BC RID: 1980 RVA: 0x00015594 File Offset: 0x00013794
		public void ExitRule(string grammarFileName, string ruleName)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.ExitRule(grammarFileName, ruleName);
			}
		}

		// Token: 0x060007BD RID: 1981 RVA: 0x000155D8 File Offset: 0x000137D8
		public void EnterAlt(int alt)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.EnterAlt(alt);
			}
		}

		// Token: 0x060007BE RID: 1982 RVA: 0x0001561C File Offset: 0x0001381C
		public void EnterSubRule(int decisionNumber)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.EnterSubRule(decisionNumber);
			}
		}

		// Token: 0x060007BF RID: 1983 RVA: 0x00015660 File Offset: 0x00013860
		public void ExitSubRule(int decisionNumber)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.ExitSubRule(decisionNumber);
			}
		}

		// Token: 0x060007C0 RID: 1984 RVA: 0x000156A4 File Offset: 0x000138A4
		public void EnterDecision(int decisionNumber)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.EnterDecision(decisionNumber);
			}
		}

		// Token: 0x060007C1 RID: 1985 RVA: 0x000156E8 File Offset: 0x000138E8
		public void ExitDecision(int decisionNumber)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.ExitDecision(decisionNumber);
			}
		}

		// Token: 0x060007C2 RID: 1986 RVA: 0x0001572C File Offset: 0x0001392C
		public void Location(int line, int pos)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.Location(line, pos);
			}
		}

		// Token: 0x060007C3 RID: 1987 RVA: 0x00015770 File Offset: 0x00013970
		public void ConsumeToken(IToken token)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.ConsumeToken(token);
			}
		}

		// Token: 0x060007C4 RID: 1988 RVA: 0x000157B4 File Offset: 0x000139B4
		public void ConsumeHiddenToken(IToken token)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.ConsumeHiddenToken(token);
			}
		}

		// Token: 0x060007C5 RID: 1989 RVA: 0x000157F8 File Offset: 0x000139F8
		public void LT(int index, IToken t)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.LT(index, t);
			}
		}

		// Token: 0x060007C6 RID: 1990 RVA: 0x0001583C File Offset: 0x00013A3C
		public void Mark(int index)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.Mark(index);
			}
		}

		// Token: 0x060007C7 RID: 1991 RVA: 0x00015880 File Offset: 0x00013A80
		public void Rewind(int index)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.Rewind(index);
			}
		}

		// Token: 0x060007C8 RID: 1992 RVA: 0x000158C4 File Offset: 0x00013AC4
		public void Rewind()
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.Rewind();
			}
		}

		// Token: 0x060007C9 RID: 1993 RVA: 0x00015908 File Offset: 0x00013B08
		public void BeginBacktrack(int level)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.BeginBacktrack(level);
			}
		}

		// Token: 0x060007CA RID: 1994 RVA: 0x0001594C File Offset: 0x00013B4C
		public void EndBacktrack(int level, bool successful)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.EndBacktrack(level, successful);
			}
		}

		// Token: 0x060007CB RID: 1995 RVA: 0x00015990 File Offset: 0x00013B90
		public void RecognitionException(RecognitionException e)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.RecognitionException(e);
			}
		}

		// Token: 0x060007CC RID: 1996 RVA: 0x000159D4 File Offset: 0x00013BD4
		public void BeginResync()
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.BeginResync();
			}
		}

		// Token: 0x060007CD RID: 1997 RVA: 0x00015A18 File Offset: 0x00013C18
		public void EndResync()
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.EndResync();
			}
		}

		// Token: 0x060007CE RID: 1998 RVA: 0x00015A5C File Offset: 0x00013C5C
		public void SemanticPredicate(bool result, string predicate)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.SemanticPredicate(result, predicate);
			}
		}

		// Token: 0x060007CF RID: 1999 RVA: 0x00015AA0 File Offset: 0x00013CA0
		public void Commence()
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.Commence();
			}
		}

		// Token: 0x060007D0 RID: 2000 RVA: 0x00015AE4 File Offset: 0x00013CE4
		public void Terminate()
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.Terminate();
			}
		}

		// Token: 0x060007D1 RID: 2001 RVA: 0x00015B28 File Offset: 0x00013D28
		public void ConsumeNode(object t)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.ConsumeNode(t);
			}
		}

		// Token: 0x060007D2 RID: 2002 RVA: 0x00015B6C File Offset: 0x00013D6C
		public void LT(int index, object t)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.LT(index, t);
			}
		}

		// Token: 0x060007D3 RID: 2003 RVA: 0x00015BB0 File Offset: 0x00013DB0
		public void GetNilNode(object t)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.GetNilNode(t);
			}
		}

		// Token: 0x060007D4 RID: 2004 RVA: 0x00015BF4 File Offset: 0x00013DF4
		public void ErrorNode(object t)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.ErrorNode(t);
			}
		}

		// Token: 0x060007D5 RID: 2005 RVA: 0x00015C38 File Offset: 0x00013E38
		public void CreateNode(object t)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.CreateNode(t);
			}
		}

		// Token: 0x060007D6 RID: 2006 RVA: 0x00015C7C File Offset: 0x00013E7C
		public void CreateNode(object node, IToken token)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.CreateNode(node, token);
			}
		}

		// Token: 0x060007D7 RID: 2007 RVA: 0x00015CC0 File Offset: 0x00013EC0
		public void BecomeRoot(object newRoot, object oldRoot)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.BecomeRoot(newRoot, oldRoot);
			}
		}

		// Token: 0x060007D8 RID: 2008 RVA: 0x00015D04 File Offset: 0x00013F04
		public void AddChild(object root, object child)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.AddChild(root, child);
			}
		}

		// Token: 0x060007D9 RID: 2009 RVA: 0x00015D48 File Offset: 0x00013F48
		public void SetTokenBoundaries(object t, int tokenStartIndex, int tokenStopIndex)
		{
			for (int i = 0; i < this.listeners.Count; i++)
			{
				IDebugEventListener debugEventListener = (IDebugEventListener)this.listeners[i];
				debugEventListener.SetTokenBoundaries(t, tokenStartIndex, tokenStopIndex);
			}
		}

		// Token: 0x040001F7 RID: 503
		protected IList listeners = new ArrayList();
	}
}
