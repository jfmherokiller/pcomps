﻿using System;
using System.IO;
using Antlr.Runtime.Misc;
using Antlr.Runtime.Tree;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000BE RID: 190
	public class DebugTreeParser : TreeParser
	{
		// Token: 0x060007FA RID: 2042 RVA: 0x00015F8C File Offset: 0x0001418C
		public DebugTreeParser(ITreeNodeStream input, IDebugEventListener dbg, RecognizerSharedState state) : base((!(input is DebugTreeNodeStream)) ? new DebugTreeNodeStream(input, dbg) : input, state)
		{
			this.DebugListener = dbg;
		}

		// Token: 0x060007FB RID: 2043 RVA: 0x00015FC4 File Offset: 0x000141C4
		public DebugTreeParser(ITreeNodeStream input, RecognizerSharedState state) : base((!(input is DebugTreeNodeStream)) ? new DebugTreeNodeStream(input, null) : input, state)
		{
		}

		// Token: 0x060007FC RID: 2044 RVA: 0x00015FF4 File Offset: 0x000141F4
		public DebugTreeParser(ITreeNodeStream input, IDebugEventListener dbg) : this((!(input is DebugTreeNodeStream)) ? new DebugTreeNodeStream(input, dbg) : input, dbg, null)
		{
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x060007FD RID: 2045 RVA: 0x00016024 File Offset: 0x00014224
		// (set) Token: 0x060007FE RID: 2046 RVA: 0x0001602C File Offset: 0x0001422C
		public IDebugEventListener DebugListener
		{
			get
			{
				return this.dbg;
			}
			set
			{
				if (this.input is DebugTreeNodeStream)
				{
					((DebugTreeNodeStream)this.input).SetDebugListener(value);
				}
				this.dbg = value;
			}
		}

		// Token: 0x060007FF RID: 2047 RVA: 0x00016064 File Offset: 0x00014264
		public virtual void ReportError(IOException e)
		{
			ErrorManager.InternalError(e);
		}

		// Token: 0x06000800 RID: 2048 RVA: 0x0001606C File Offset: 0x0001426C
		public override void ReportError(RecognitionException e)
		{
			this.dbg.RecognitionException(e);
		}

		// Token: 0x06000801 RID: 2049 RVA: 0x0001607C File Offset: 0x0001427C
		protected override object GetMissingSymbol(IIntStream input, RecognitionException e, int expectedTokenType, BitSet follow)
		{
			object missingSymbol = base.GetMissingSymbol(input, e, expectedTokenType, follow);
			this.dbg.ConsumeNode(missingSymbol);
			return missingSymbol;
		}

		// Token: 0x06000802 RID: 2050 RVA: 0x000160A4 File Offset: 0x000142A4
		public override void BeginResync()
		{
			this.dbg.BeginResync();
		}

		// Token: 0x06000803 RID: 2051 RVA: 0x000160B4 File Offset: 0x000142B4
		public override void EndResync()
		{
			this.dbg.EndResync();
		}

		// Token: 0x06000804 RID: 2052 RVA: 0x000160C4 File Offset: 0x000142C4
		public override void BeginBacktrack(int level)
		{
			this.dbg.BeginBacktrack(level);
		}

		// Token: 0x06000805 RID: 2053 RVA: 0x000160D4 File Offset: 0x000142D4
		public override void EndBacktrack(int level, bool successful)
		{
			this.dbg.EndBacktrack(level, successful);
		}

		// Token: 0x040001F9 RID: 505
		protected IDebugEventListener dbg;

		// Token: 0x040001FA RID: 506
		public bool isCyclicDecision;
	}
}
