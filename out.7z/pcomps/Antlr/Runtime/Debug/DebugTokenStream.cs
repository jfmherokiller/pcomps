﻿using System;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000B1 RID: 177
	public class DebugTokenStream : IIntStream, ITokenStream
	{
		// Token: 0x060006EE RID: 1774 RVA: 0x00013820 File Offset: 0x00011A20
		public DebugTokenStream(ITokenStream input, IDebugEventListener dbg)
		{
			this.input = input;
			this.DebugListener = dbg;
			input.LT(1);
		}

		// Token: 0x170000B3 RID: 179
		// (set) Token: 0x060006EF RID: 1775 RVA: 0x00013848 File Offset: 0x00011A48
		public virtual IDebugEventListener DebugListener
		{
			set
			{
				this.dbg = value;
			}
		}

		// Token: 0x060006F0 RID: 1776 RVA: 0x00013854 File Offset: 0x00011A54
		public virtual void Consume()
		{
			if (this.initialStreamState)
			{
				this.ConsumeInitialHiddenTokens();
			}
			int num = this.input.Index();
			IToken t = this.input.LT(1);
			this.input.Consume();
			int num2 = this.input.Index();
			this.dbg.ConsumeToken(t);
			if (num2 > num + 1)
			{
				for (int i = num + 1; i < num2; i++)
				{
					this.dbg.ConsumeHiddenToken(this.input.Get(i));
				}
			}
		}

		// Token: 0x060006F1 RID: 1777 RVA: 0x000138E4 File Offset: 0x00011AE4
		protected internal virtual void ConsumeInitialHiddenTokens()
		{
			int num = this.input.Index();
			for (int i = 0; i < num; i++)
			{
				this.dbg.ConsumeHiddenToken(this.input.Get(i));
			}
			this.initialStreamState = false;
		}

		// Token: 0x060006F2 RID: 1778 RVA: 0x00013930 File Offset: 0x00011B30
		public virtual IToken LT(int i)
		{
			if (this.initialStreamState)
			{
				this.ConsumeInitialHiddenTokens();
			}
			this.dbg.LT(i, this.input.LT(i));
			return this.input.LT(i);
		}

		// Token: 0x060006F3 RID: 1779 RVA: 0x00013974 File Offset: 0x00011B74
		public virtual int LA(int i)
		{
			if (this.initialStreamState)
			{
				this.ConsumeInitialHiddenTokens();
			}
			this.dbg.LT(i, this.input.LT(i));
			return this.input.LA(i);
		}

		// Token: 0x060006F4 RID: 1780 RVA: 0x000139B8 File Offset: 0x00011BB8
		public virtual IToken Get(int i)
		{
			return this.input.Get(i);
		}

		// Token: 0x060006F5 RID: 1781 RVA: 0x000139C8 File Offset: 0x00011BC8
		public virtual int Mark()
		{
			this.lastMarker = this.input.Mark();
			this.dbg.Mark(this.lastMarker);
			return this.lastMarker;
		}

		// Token: 0x060006F6 RID: 1782 RVA: 0x00013A00 File Offset: 0x00011C00
		public virtual int Index()
		{
			return this.input.Index();
		}

		// Token: 0x060006F7 RID: 1783 RVA: 0x00013A10 File Offset: 0x00011C10
		public virtual void Rewind(int marker)
		{
			this.dbg.Rewind(marker);
			this.input.Rewind(marker);
		}

		// Token: 0x060006F8 RID: 1784 RVA: 0x00013A2C File Offset: 0x00011C2C
		public virtual void Rewind()
		{
			this.dbg.Rewind();
			this.input.Rewind(this.lastMarker);
		}

		// Token: 0x060006F9 RID: 1785 RVA: 0x00013A4C File Offset: 0x00011C4C
		public virtual void Release(int marker)
		{
		}

		// Token: 0x060006FA RID: 1786 RVA: 0x00013A50 File Offset: 0x00011C50
		public virtual void Seek(int index)
		{
			this.input.Seek(index);
		}

		// Token: 0x060006FB RID: 1787 RVA: 0x00013A60 File Offset: 0x00011C60
		[Obsolete("Please use property Count instead.")]
		public virtual int Size()
		{
			return this.Count;
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x060006FC RID: 1788 RVA: 0x00013A68 File Offset: 0x00011C68
		public virtual int Count
		{
			get
			{
				return this.input.Count;
			}
		}

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x060006FD RID: 1789 RVA: 0x00013A78 File Offset: 0x00011C78
		public virtual ITokenSource TokenSource
		{
			get
			{
				return this.input.TokenSource;
			}
		}

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x060006FE RID: 1790 RVA: 0x00013A88 File Offset: 0x00011C88
		public virtual string SourceName
		{
			get
			{
				return this.TokenSource.SourceName;
			}
		}

		// Token: 0x060006FF RID: 1791 RVA: 0x00013A98 File Offset: 0x00011C98
		public override string ToString()
		{
			return this.input.ToString();
		}

		// Token: 0x06000700 RID: 1792 RVA: 0x00013AA8 File Offset: 0x00011CA8
		public virtual string ToString(int start, int stop)
		{
			return this.input.ToString(start, stop);
		}

		// Token: 0x06000701 RID: 1793 RVA: 0x00013AB8 File Offset: 0x00011CB8
		public virtual string ToString(IToken start, IToken stop)
		{
			return this.input.ToString(start, stop);
		}

		// Token: 0x040001CE RID: 462
		protected internal IDebugEventListener dbg;

		// Token: 0x040001CF RID: 463
		public ITokenStream input;

		// Token: 0x040001D0 RID: 464
		protected internal bool initialStreamState = true;

		// Token: 0x040001D1 RID: 465
		protected int lastMarker;
	}
}
