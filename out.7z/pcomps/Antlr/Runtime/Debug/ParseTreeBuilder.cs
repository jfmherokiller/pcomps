﻿using System;
using System.Collections;
using Antlr.Runtime.Tree;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000BF RID: 191
	public class ParseTreeBuilder : BlankDebugEventListener
	{
		// Token: 0x06000806 RID: 2054 RVA: 0x000160E4 File Offset: 0x000142E4
		public ParseTreeBuilder(string grammarName)
		{
			ParseTree obj = this.Create("<grammar " + grammarName + ">");
			this.callStack.Push(obj);
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x06000808 RID: 2056 RVA: 0x0001613C File Offset: 0x0001433C
		public ParseTree Tree
		{
			get
			{
				return (ParseTree)this.callStack.Peek();
			}
		}

		// Token: 0x06000809 RID: 2057 RVA: 0x00016150 File Offset: 0x00014350
		public ParseTree Create(object payload)
		{
			return new ParseTree(payload);
		}

		// Token: 0x0600080A RID: 2058 RVA: 0x00016158 File Offset: 0x00014358
		public ParseTree EpsilonNode()
		{
			return this.Create(ParseTreeBuilder.EPSILON_PAYLOAD);
		}

		// Token: 0x0600080B RID: 2059 RVA: 0x00016168 File Offset: 0x00014368
		public override void EnterDecision(int d)
		{
			this.backtracking++;
		}

		// Token: 0x0600080C RID: 2060 RVA: 0x00016178 File Offset: 0x00014378
		public override void ExitDecision(int i)
		{
			this.backtracking--;
		}

		// Token: 0x0600080D RID: 2061 RVA: 0x00016188 File Offset: 0x00014388
		public override void EnterRule(string filename, string ruleName)
		{
			if (this.backtracking > 0)
			{
				return;
			}
			ParseTree parseTree = (ParseTree)this.callStack.Peek();
			ParseTree parseTree2 = this.Create(ruleName);
			parseTree.AddChild(parseTree2);
			this.callStack.Push(parseTree2);
		}

		// Token: 0x0600080E RID: 2062 RVA: 0x000161D0 File Offset: 0x000143D0
		public override void ExitRule(string filename, string ruleName)
		{
			if (this.backtracking > 0)
			{
				return;
			}
			ParseTree parseTree = (ParseTree)this.callStack.Peek();
			if (parseTree.ChildCount == 0)
			{
				parseTree.AddChild(this.EpsilonNode());
			}
			this.callStack.Pop();
		}

		// Token: 0x0600080F RID: 2063 RVA: 0x00016220 File Offset: 0x00014420
		public override void ConsumeToken(IToken token)
		{
			if (this.backtracking > 0)
			{
				return;
			}
			ParseTree parseTree = (ParseTree)this.callStack.Peek();
			ParseTree parseTree2 = this.Create(token);
			parseTree2.hiddenTokens = this.hiddenTokens;
			this.hiddenTokens = new ArrayList();
			parseTree.AddChild(parseTree2);
		}

		// Token: 0x06000810 RID: 2064 RVA: 0x00016274 File Offset: 0x00014474
		public override void ConsumeHiddenToken(IToken token)
		{
			if (this.backtracking > 0)
			{
				return;
			}
			this.hiddenTokens.Add(token);
		}

		// Token: 0x06000811 RID: 2065 RVA: 0x00016290 File Offset: 0x00014490
		public override void RecognitionException(RecognitionException e)
		{
			if (this.backtracking > 0)
			{
				return;
			}
			ParseTree parseTree = (ParseTree)this.callStack.Peek();
			ParseTree t = this.Create(e);
			parseTree.AddChild(t);
		}

		// Token: 0x040001FB RID: 507
		public static readonly string EPSILON_PAYLOAD = "<epsilon>";

		// Token: 0x040001FC RID: 508
		private Stack callStack = new Stack();

		// Token: 0x040001FD RID: 509
		private IList hiddenTokens = new ArrayList();

		// Token: 0x040001FE RID: 510
		private int backtracking;
	}
}
