﻿using System;
using Antlr.Runtime.Tree;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000BB RID: 187
	public class TraceDebugEventListener : BlankDebugEventListener
	{
		// Token: 0x060007AA RID: 1962 RVA: 0x00015114 File Offset: 0x00013314
		public TraceDebugEventListener(ITreeAdaptor adaptor)
		{
			this.adaptor = adaptor;
		}

		// Token: 0x060007AB RID: 1963 RVA: 0x00015124 File Offset: 0x00013324
		public override void EnterRule(string grammarFileName, string ruleName)
		{
			Console.Out.WriteLine("EnterRule " + grammarFileName + " " + ruleName);
		}

		// Token: 0x060007AC RID: 1964 RVA: 0x00015144 File Offset: 0x00013344
		public override void ExitRule(string grammarFileName, string ruleName)
		{
			Console.Out.WriteLine("ExitRule " + grammarFileName + " " + ruleName);
		}

		// Token: 0x060007AD RID: 1965 RVA: 0x00015164 File Offset: 0x00013364
		public override void EnterSubRule(int decisionNumber)
		{
			Console.Out.WriteLine("EnterSubRule");
		}

		// Token: 0x060007AE RID: 1966 RVA: 0x00015178 File Offset: 0x00013378
		public override void ExitSubRule(int decisionNumber)
		{
			Console.Out.WriteLine("ExitSubRule");
		}

		// Token: 0x060007AF RID: 1967 RVA: 0x0001518C File Offset: 0x0001338C
		public override void Location(int line, int pos)
		{
			Console.Out.WriteLine(string.Concat(new object[]
			{
				"Location ",
				line,
				":",
				pos
			}));
		}

		// Token: 0x060007B0 RID: 1968 RVA: 0x000151C8 File Offset: 0x000133C8
		public override void ConsumeNode(object t)
		{
			int uniqueID = this.adaptor.GetUniqueID(t);
			string nodeText = this.adaptor.GetNodeText(t);
			int nodeType = this.adaptor.GetNodeType(t);
			Console.Out.WriteLine(string.Concat(new object[]
			{
				"ConsumeNode ",
				uniqueID,
				" ",
				nodeText,
				" ",
				nodeType
			}));
		}

		// Token: 0x060007B1 RID: 1969 RVA: 0x00015240 File Offset: 0x00013440
		public override void LT(int i, object t)
		{
			int uniqueID = this.adaptor.GetUniqueID(t);
			string nodeText = this.adaptor.GetNodeText(t);
			int nodeType = this.adaptor.GetNodeType(t);
			Console.Out.WriteLine(string.Concat(new object[]
			{
				"LT ",
				i,
				" ",
				uniqueID,
				" ",
				nodeText,
				" ",
				nodeType
			}));
		}

		// Token: 0x060007B2 RID: 1970 RVA: 0x000152C8 File Offset: 0x000134C8
		public override void GetNilNode(object t)
		{
			Console.Out.WriteLine("GetNilNode " + this.adaptor.GetUniqueID(t));
		}

		// Token: 0x060007B3 RID: 1971 RVA: 0x000152F0 File Offset: 0x000134F0
		public override void CreateNode(object t)
		{
			int uniqueID = this.adaptor.GetUniqueID(t);
			string nodeText = this.adaptor.GetNodeText(t);
			int nodeType = this.adaptor.GetNodeType(t);
			Console.Out.WriteLine(string.Concat(new object[]
			{
				"Create ",
				uniqueID,
				": ",
				nodeText,
				", ",
				nodeType
			}));
		}

		// Token: 0x060007B4 RID: 1972 RVA: 0x00015368 File Offset: 0x00013568
		public override void CreateNode(object t, IToken token)
		{
			int uniqueID = this.adaptor.GetUniqueID(t);
			int tokenIndex = token.TokenIndex;
			Console.Out.WriteLine(string.Concat(new object[]
			{
				"Create ",
				uniqueID,
				": ",
				tokenIndex
			}));
		}

		// Token: 0x060007B5 RID: 1973 RVA: 0x000153C0 File Offset: 0x000135C0
		public override void BecomeRoot(object newRoot, object oldRoot)
		{
			Console.Out.WriteLine(string.Concat(new object[]
			{
				"BecomeRoot ",
				this.adaptor.GetUniqueID(newRoot),
				", ",
				this.adaptor.GetUniqueID(oldRoot)
			}));
		}

		// Token: 0x060007B6 RID: 1974 RVA: 0x0001541C File Offset: 0x0001361C
		public override void AddChild(object root, object child)
		{
			Console.Out.WriteLine(string.Concat(new object[]
			{
				"AddChild ",
				this.adaptor.GetUniqueID(root),
				", ",
				this.adaptor.GetUniqueID(child)
			}));
		}

		// Token: 0x060007B7 RID: 1975 RVA: 0x00015478 File Offset: 0x00013678
		public override void SetTokenBoundaries(object t, int tokenStartIndex, int tokenStopIndex)
		{
			Console.Out.WriteLine(string.Concat(new object[]
			{
				"SetTokenBoundaries ",
				this.adaptor.GetUniqueID(t),
				", ",
				tokenStartIndex,
				", ",
				tokenStopIndex
			}));
		}

		// Token: 0x040001F6 RID: 502
		private ITreeAdaptor adaptor;
	}
}
