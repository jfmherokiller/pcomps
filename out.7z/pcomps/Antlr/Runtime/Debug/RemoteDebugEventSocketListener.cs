﻿using System;
using System.Globalization;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Antlr.Runtime.Tree;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000B8 RID: 184
	public class RemoteDebugEventSocketListener
	{
		// Token: 0x06000781 RID: 1921 RVA: 0x000141F8 File Offset: 0x000123F8
		public RemoteDebugEventSocketListener(IDebugEventListener listener, string hostName, int port)
		{
			this.listener = listener;
			this.hostName = hostName;
			this.port = port;
			if (!this.OpenConnection())
			{
				throw new Exception();
			}
		}

		// Token: 0x06000782 RID: 1922 RVA: 0x00014230 File Offset: 0x00012430
		protected virtual void EventHandler()
		{
			try
			{
				this.Handshake();
				this.eventLabel = this.reader.ReadLine();
				while (this.eventLabel != null)
				{
					this.Dispatch(this.eventLabel);
					this.Ack();
					this.eventLabel = this.reader.ReadLine();
				}
			}
			catch (Exception ex)
			{
				Console.Error.WriteLine(ex);
				Console.Error.WriteLine(ex.StackTrace);
			}
			finally
			{
				this.CloseConnection();
			}
		}

		// Token: 0x06000783 RID: 1923 RVA: 0x000142D0 File Offset: 0x000124D0
		protected virtual bool OpenConnection()
		{
			bool result = false;
			try
			{
				this.channel = new TcpClient(this.hostName, this.port);
				this.channel.NoDelay = true;
				this.writer = new StreamWriter(this.channel.GetStream(), Encoding.UTF8);
				this.reader = new StreamReader(this.channel.GetStream(), Encoding.UTF8);
				result = true;
			}
			catch (Exception value)
			{
				Console.Error.WriteLine(value);
			}
			return result;
		}

		// Token: 0x06000784 RID: 1924 RVA: 0x00014364 File Offset: 0x00012564
		protected virtual void CloseConnection()
		{
			try
			{
				this.reader.Close();
				this.reader = null;
				this.writer.Close();
				this.writer = null;
				this.channel.Close();
				this.channel = null;
			}
			catch (Exception ex)
			{
				Console.Error.WriteLine(ex);
				Console.Error.WriteLine(ex.StackTrace);
			}
			finally
			{
				if (this.reader != null)
				{
					try
					{
						this.reader.Close();
					}
					catch (IOException value)
					{
						Console.Error.WriteLine(value);
					}
				}
				if (this.writer != null)
				{
					this.writer.Close();
				}
				if (this.channel != null)
				{
					try
					{
						this.channel.Close();
					}
					catch (IOException value2)
					{
						Console.Error.WriteLine(value2);
					}
				}
			}
		}

		// Token: 0x06000785 RID: 1925 RVA: 0x00014470 File Offset: 0x00012670
		protected virtual void Handshake()
		{
			string text = this.reader.ReadLine();
			string[] eventElements = this.GetEventElements(text);
			this.version = eventElements[1];
			string text2 = this.reader.ReadLine();
			string[] eventElements2 = this.GetEventElements(text2);
			this.grammarFileName = eventElements2[1];
			this.Ack();
			this.listener.Commence();
		}

		// Token: 0x06000786 RID: 1926 RVA: 0x000144C8 File Offset: 0x000126C8
		protected virtual void Ack()
		{
			this.writer.WriteLine("ack");
			this.writer.Flush();
		}

		// Token: 0x06000787 RID: 1927 RVA: 0x000144E8 File Offset: 0x000126E8
		protected virtual void Dispatch(string line)
		{
			string[] eventElements = this.GetEventElements(line);
			if (eventElements == null || eventElements[0] == null)
			{
				Console.Error.WriteLine("unknown debug event: " + line);
				return;
			}
			if (eventElements[0].Equals("enterRule"))
			{
				this.listener.EnterRule(eventElements[1], eventElements[2]);
			}
			else if (eventElements[0].Equals("exitRule"))
			{
				this.listener.ExitRule(eventElements[1], eventElements[2]);
			}
			else if (eventElements[0].Equals("enterAlt"))
			{
				this.listener.EnterAlt(int.Parse(eventElements[1], CultureInfo.InvariantCulture));
			}
			else if (eventElements[0].Equals("enterSubRule"))
			{
				this.listener.EnterSubRule(int.Parse(eventElements[1], CultureInfo.InvariantCulture));
			}
			else if (eventElements[0].Equals("exitSubRule"))
			{
				this.listener.ExitSubRule(int.Parse(eventElements[1], CultureInfo.InvariantCulture));
			}
			else if (eventElements[0].Equals("enterDecision"))
			{
				this.listener.EnterDecision(int.Parse(eventElements[1], CultureInfo.InvariantCulture));
			}
			else if (eventElements[0].Equals("exitDecision"))
			{
				this.listener.ExitDecision(int.Parse(eventElements[1], CultureInfo.InvariantCulture));
			}
			else if (eventElements[0].Equals("location"))
			{
				this.listener.Location(int.Parse(eventElements[1], CultureInfo.InvariantCulture), int.Parse(eventElements[2], CultureInfo.InvariantCulture));
			}
			else if (eventElements[0].Equals("consumeToken"))
			{
				RemoteDebugEventSocketListener.ProxyToken proxyToken = this.DeserializeToken(eventElements, 1);
				if (proxyToken.TokenIndex == this.previousTokenIndex)
				{
					this.tokenIndexesInvalid = true;
				}
				this.previousTokenIndex = proxyToken.TokenIndex;
				this.listener.ConsumeToken(proxyToken);
			}
			else if (eventElements[0].Equals("consumeHiddenToken"))
			{
				RemoteDebugEventSocketListener.ProxyToken proxyToken2 = this.DeserializeToken(eventElements, 1);
				if (proxyToken2.TokenIndex == this.previousTokenIndex)
				{
					this.tokenIndexesInvalid = true;
				}
				this.previousTokenIndex = proxyToken2.TokenIndex;
				this.listener.ConsumeHiddenToken(proxyToken2);
			}
			else if (eventElements[0].Equals("LT"))
			{
				IToken t = this.DeserializeToken(eventElements, 2);
				this.listener.LT(int.Parse(eventElements[1], CultureInfo.InvariantCulture), t);
			}
			else if (eventElements[0].Equals("mark"))
			{
				this.listener.Mark(int.Parse(eventElements[1], CultureInfo.InvariantCulture));
			}
			else if (eventElements[0].Equals("rewind"))
			{
				if (eventElements[1] != null)
				{
					this.listener.Rewind(int.Parse(eventElements[1], CultureInfo.InvariantCulture));
				}
				else
				{
					this.listener.Rewind();
				}
			}
			else if (eventElements[0].Equals("beginBacktrack"))
			{
				this.listener.BeginBacktrack(int.Parse(eventElements[1], CultureInfo.InvariantCulture));
			}
			else if (eventElements[0].Equals("endBacktrack"))
			{
				int level = int.Parse(eventElements[1], CultureInfo.InvariantCulture);
				int num = int.Parse(eventElements[2], CultureInfo.InvariantCulture);
				this.listener.EndBacktrack(level, num == 1);
			}
			else if (eventElements[0].Equals("exception"))
			{
				string typeName = eventElements[1];
				string s = eventElements[2];
				string s2 = eventElements[3];
				string s3 = eventElements[4];
				try
				{
					Type type = Type.GetType(typeName);
					RecognitionException ex = (RecognitionException)Activator.CreateInstance(type);
					ex.Index = int.Parse(s, CultureInfo.InvariantCulture);
					ex.Line = int.Parse(s2, CultureInfo.InvariantCulture);
					ex.CharPositionInLine = int.Parse(s3, CultureInfo.InvariantCulture);
					this.listener.RecognitionException(ex);
				}
				catch (UnauthorizedAccessException ex2)
				{
					Console.Error.WriteLine("can't access class " + ex2);
					Console.Error.WriteLine(ex2.StackTrace);
				}
			}
			else if (eventElements[0].Equals("beginResync"))
			{
				this.listener.BeginResync();
			}
			else if (eventElements[0].Equals("endResync"))
			{
				this.listener.EndResync();
			}
			else if (eventElements[0].Equals("terminate"))
			{
				this.listener.Terminate();
			}
			else if (eventElements[0].Equals("semanticPredicate"))
			{
				bool result = bool.Parse(eventElements[1]);
				string text = eventElements[2];
				text = this.UnEscapeNewlines(text);
				this.listener.SemanticPredicate(result, text);
			}
			else if (eventElements[0].Equals("consumeNode"))
			{
				RemoteDebugEventSocketListener.ProxyTree t2 = this.DeserializeNode(eventElements, 1);
				this.listener.ConsumeNode(t2);
			}
			else if (eventElements[0].Equals("LN"))
			{
				int i = int.Parse(eventElements[1], CultureInfo.InvariantCulture);
				RemoteDebugEventSocketListener.ProxyTree t3 = this.DeserializeNode(eventElements, 2);
				this.listener.LT(i, t3);
			}
			else if (eventElements[0].Equals("createNodeFromTokenElements"))
			{
				int id = int.Parse(eventElements[1], CultureInfo.InvariantCulture);
				int type2 = int.Parse(eventElements[2], CultureInfo.InvariantCulture);
				string text2 = eventElements[3];
				text2 = this.UnEscapeNewlines(text2);
				RemoteDebugEventSocketListener.ProxyTree t4 = new RemoteDebugEventSocketListener.ProxyTree(id, type2, -1, -1, -1, text2);
				this.listener.CreateNode(t4);
			}
			else if (eventElements[0].Equals("createNode"))
			{
				int id2 = int.Parse(eventElements[1], CultureInfo.InvariantCulture);
				int index = int.Parse(eventElements[2], CultureInfo.InvariantCulture);
				RemoteDebugEventSocketListener.ProxyTree node = new RemoteDebugEventSocketListener.ProxyTree(id2);
				RemoteDebugEventSocketListener.ProxyToken token = new RemoteDebugEventSocketListener.ProxyToken(index);
				this.listener.CreateNode(node, token);
			}
			else if (eventElements[0].Equals("nilNode"))
			{
				int id3 = int.Parse(eventElements[1], CultureInfo.InvariantCulture);
				RemoteDebugEventSocketListener.ProxyTree t5 = new RemoteDebugEventSocketListener.ProxyTree(id3);
				this.listener.GetNilNode(t5);
			}
			else if (eventElements[0].Equals("errorNode"))
			{
				int id4 = int.Parse(eventElements[1], CultureInfo.InvariantCulture);
				int type3 = int.Parse(eventElements[2], CultureInfo.InvariantCulture);
				string text3 = eventElements[3];
				text3 = this.UnEscapeNewlines(text3);
				RemoteDebugEventSocketListener.ProxyTree t6 = new RemoteDebugEventSocketListener.ProxyTree(id4, type3, -1, -1, -1, text3);
				this.listener.ErrorNode(t6);
			}
			else if (eventElements[0].Equals("becomeRoot"))
			{
				int id5 = int.Parse(eventElements[1], CultureInfo.InvariantCulture);
				int id6 = int.Parse(eventElements[2], CultureInfo.InvariantCulture);
				RemoteDebugEventSocketListener.ProxyTree newRoot = new RemoteDebugEventSocketListener.ProxyTree(id5);
				RemoteDebugEventSocketListener.ProxyTree oldRoot = new RemoteDebugEventSocketListener.ProxyTree(id6);
				this.listener.BecomeRoot(newRoot, oldRoot);
			}
			else if (eventElements[0].Equals("addChild"))
			{
				int id7 = int.Parse(eventElements[1], CultureInfo.InvariantCulture);
				int id8 = int.Parse(eventElements[2], CultureInfo.InvariantCulture);
				RemoteDebugEventSocketListener.ProxyTree root = new RemoteDebugEventSocketListener.ProxyTree(id7);
				RemoteDebugEventSocketListener.ProxyTree child = new RemoteDebugEventSocketListener.ProxyTree(id8);
				this.listener.AddChild(root, child);
			}
			else if (eventElements[0].Equals("setTokenBoundaries"))
			{
				int id9 = int.Parse(eventElements[1], CultureInfo.InvariantCulture);
				RemoteDebugEventSocketListener.ProxyTree t7 = new RemoteDebugEventSocketListener.ProxyTree(id9);
				this.listener.SetTokenBoundaries(t7, int.Parse(eventElements[2], CultureInfo.InvariantCulture), int.Parse(eventElements[3], CultureInfo.InvariantCulture));
			}
			else
			{
				Console.Error.WriteLine("unknown debug event: " + line);
			}
		}

		// Token: 0x06000788 RID: 1928 RVA: 0x00014CA8 File Offset: 0x00012EA8
		protected internal RemoteDebugEventSocketListener.ProxyTree DeserializeNode(string[] elements, int offset)
		{
			int id = int.Parse(elements[offset], CultureInfo.InvariantCulture);
			int type = int.Parse(elements[offset + 1], CultureInfo.InvariantCulture);
			int line = int.Parse(elements[offset + 2], CultureInfo.InvariantCulture);
			int charPos = int.Parse(elements[offset + 3], CultureInfo.InvariantCulture);
			int tokenIndex = int.Parse(elements[offset + 4], CultureInfo.InvariantCulture);
			string text = elements[offset + 5];
			text = this.UnEscapeNewlines(text);
			return new RemoteDebugEventSocketListener.ProxyTree(id, type, line, charPos, tokenIndex, text);
		}

		// Token: 0x06000789 RID: 1929 RVA: 0x00014D24 File Offset: 0x00012F24
		protected internal virtual RemoteDebugEventSocketListener.ProxyToken DeserializeToken(string[] elements, int offset)
		{
			string s = elements[offset];
			string s2 = elements[offset + 1];
			string s3 = elements[offset + 2];
			string s4 = elements[offset + 3];
			string s5 = elements[offset + 4];
			string text = elements[offset + 5];
			text = this.UnEscapeNewlines(text);
			int index = int.Parse(s, CultureInfo.InvariantCulture);
			return new RemoteDebugEventSocketListener.ProxyToken(index, int.Parse(s2, CultureInfo.InvariantCulture), int.Parse(s3, CultureInfo.InvariantCulture), int.Parse(s4, CultureInfo.InvariantCulture), int.Parse(s5, CultureInfo.InvariantCulture), text);
		}

		// Token: 0x0600078A RID: 1930 RVA: 0x00014DA8 File Offset: 0x00012FA8
		public virtual void start()
		{
			Thread thread = new Thread(new ThreadStart(this.Run));
			thread.Start();
		}

		// Token: 0x0600078B RID: 1931 RVA: 0x00014DD0 File Offset: 0x00012FD0
		public virtual void Run()
		{
			this.EventHandler();
		}

		// Token: 0x0600078C RID: 1932 RVA: 0x00014DD8 File Offset: 0x00012FD8
		public virtual string[] GetEventElements(string eventLabel)
		{
			if (eventLabel == null)
			{
				return null;
			}
			string[] array = new string[8];
			string text = null;
			try
			{
				int num = eventLabel.IndexOf('"');
				if (num >= 0)
				{
					string text2 = eventLabel.Substring(0, num);
					text = eventLabel.Substring(num + 1, eventLabel.Length - (num + 1));
					eventLabel = text2;
				}
				string[] array2 = eventLabel.Split(new char[]
				{
					'\t'
				});
				int i;
				for (i = 0; i < array2.Length; i++)
				{
					if (i >= 8)
					{
						return array;
					}
					array[i] = array2[i];
				}
				if (text != null)
				{
					array[i] = text;
				}
			}
			catch (Exception ex)
			{
				Console.Error.WriteLine(ex.StackTrace);
			}
			return array;
		}

		// Token: 0x0600078D RID: 1933 RVA: 0x00014EA8 File Offset: 0x000130A8
		protected string UnEscapeNewlines(string txt)
		{
			txt = txt.Replace("%0A", "\n");
			txt = txt.Replace("%0D", "\r");
			txt = txt.Replace("%25", "%");
			return txt;
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x0600078E RID: 1934 RVA: 0x00014EE4 File Offset: 0x000130E4
		public bool TokenIndexesAreInvalid
		{
			get
			{
				return false;
			}
		}

		// Token: 0x040001DE RID: 478
		internal const int MAX_EVENT_ELEMENTS = 8;

		// Token: 0x040001DF RID: 479
		internal IDebugEventListener listener;

		// Token: 0x040001E0 RID: 480
		internal string hostName;

		// Token: 0x040001E1 RID: 481
		internal int port;

		// Token: 0x040001E2 RID: 482
		internal TcpClient channel;

		// Token: 0x040001E3 RID: 483
		internal StreamWriter writer;

		// Token: 0x040001E4 RID: 484
		internal StreamReader reader;

		// Token: 0x040001E5 RID: 485
		internal string eventLabel;

		// Token: 0x040001E6 RID: 486
		public string version;

		// Token: 0x040001E7 RID: 487
		public string grammarFileName;

		// Token: 0x040001E8 RID: 488
		private int previousTokenIndex = -1;

		// Token: 0x040001E9 RID: 489
		private bool tokenIndexesInvalid;

		// Token: 0x020000B9 RID: 185
		public class ProxyToken : IToken
		{
			// Token: 0x0600078F RID: 1935 RVA: 0x00014EE8 File Offset: 0x000130E8
			public ProxyToken(int index)
			{
				this.index = index;
			}

			// Token: 0x06000790 RID: 1936 RVA: 0x00014EF8 File Offset: 0x000130F8
			public ProxyToken(int index, int type, int channel, int line, int charPos, string text)
			{
				this.index = index;
				this.type = type;
				this.channel = channel;
				this.line = line;
				this.charPos = charPos;
				this.text = text;
			}

			// Token: 0x170000C2 RID: 194
			// (get) Token: 0x06000791 RID: 1937 RVA: 0x00014F30 File Offset: 0x00013130
			// (set) Token: 0x06000792 RID: 1938 RVA: 0x00014F38 File Offset: 0x00013138
			public int Type
			{
				get
				{
					return this.type;
				}
				set
				{
					this.type = value;
				}
			}

			// Token: 0x170000C3 RID: 195
			// (get) Token: 0x06000793 RID: 1939 RVA: 0x00014F44 File Offset: 0x00013144
			// (set) Token: 0x06000794 RID: 1940 RVA: 0x00014F4C File Offset: 0x0001314C
			public int Line
			{
				get
				{
					return this.line;
				}
				set
				{
					this.line = value;
				}
			}

			// Token: 0x170000C4 RID: 196
			// (get) Token: 0x06000795 RID: 1941 RVA: 0x00014F58 File Offset: 0x00013158
			// (set) Token: 0x06000796 RID: 1942 RVA: 0x00014F60 File Offset: 0x00013160
			public int CharPositionInLine
			{
				get
				{
					return this.charPos;
				}
				set
				{
					this.charPos = value;
				}
			}

			// Token: 0x170000C5 RID: 197
			// (get) Token: 0x06000797 RID: 1943 RVA: 0x00014F6C File Offset: 0x0001316C
			// (set) Token: 0x06000798 RID: 1944 RVA: 0x00014F74 File Offset: 0x00013174
			public int Channel
			{
				get
				{
					return this.channel;
				}
				set
				{
					this.channel = value;
				}
			}

			// Token: 0x170000C6 RID: 198
			// (get) Token: 0x06000799 RID: 1945 RVA: 0x00014F80 File Offset: 0x00013180
			// (set) Token: 0x0600079A RID: 1946 RVA: 0x00014F88 File Offset: 0x00013188
			public int TokenIndex
			{
				get
				{
					return this.index;
				}
				set
				{
					this.index = value;
				}
			}

			// Token: 0x170000C7 RID: 199
			// (get) Token: 0x0600079B RID: 1947 RVA: 0x00014F94 File Offset: 0x00013194
			// (set) Token: 0x0600079C RID: 1948 RVA: 0x00014F9C File Offset: 0x0001319C
			public string Text
			{
				get
				{
					return this.text;
				}
				set
				{
					this.text = value;
				}
			}

			// Token: 0x170000C8 RID: 200
			// (get) Token: 0x0600079D RID: 1949 RVA: 0x00014FA8 File Offset: 0x000131A8
			// (set) Token: 0x0600079E RID: 1950 RVA: 0x00014FAC File Offset: 0x000131AC
			public ICharStream InputStream
			{
				get
				{
					return null;
				}
				set
				{
				}
			}

			// Token: 0x0600079F RID: 1951 RVA: 0x00014FB0 File Offset: 0x000131B0
			public override string ToString()
			{
				string text = string.Empty;
				if (this.channel != 0)
				{
					text = ",channel=" + this.channel;
				}
				return string.Concat(new object[]
				{
					"[",
					this.Text,
					"/<",
					this.type,
					">",
					text,
					",",
					this.line,
					":",
					this.CharPositionInLine,
					",@",
					this.index,
					"]"
				});
			}

			// Token: 0x040001EA RID: 490
			internal int index;

			// Token: 0x040001EB RID: 491
			internal int type;

			// Token: 0x040001EC RID: 492
			internal int channel;

			// Token: 0x040001ED RID: 493
			internal int line;

			// Token: 0x040001EE RID: 494
			internal int charPos;

			// Token: 0x040001EF RID: 495
			internal string text;
		}

		// Token: 0x020000BA RID: 186
		public class ProxyTree : BaseTree
		{
			// Token: 0x060007A0 RID: 1952 RVA: 0x00015074 File Offset: 0x00013274
			public ProxyTree(int ID)
			{
				this.ID = ID;
			}

			// Token: 0x060007A1 RID: 1953 RVA: 0x00015094 File Offset: 0x00013294
			public ProxyTree(int ID, int type, int line, int charPos, int tokenIndex, string text)
			{
				this.ID = ID;
				this.type = type;
				this.line = line;
				this.charPos = charPos;
				this.tokenIndex = tokenIndex;
				this.text = text;
			}

			// Token: 0x170000C9 RID: 201
			// (get) Token: 0x060007A2 RID: 1954 RVA: 0x000150E4 File Offset: 0x000132E4
			// (set) Token: 0x060007A3 RID: 1955 RVA: 0x000150EC File Offset: 0x000132EC
			public override int TokenStartIndex
			{
				get
				{
					return this.tokenIndex;
				}
				set
				{
				}
			}

			// Token: 0x170000CA RID: 202
			// (get) Token: 0x060007A4 RID: 1956 RVA: 0x000150F0 File Offset: 0x000132F0
			// (set) Token: 0x060007A5 RID: 1957 RVA: 0x000150F4 File Offset: 0x000132F4
			public override int TokenStopIndex
			{
				get
				{
					return 0;
				}
				set
				{
				}
			}

			// Token: 0x060007A6 RID: 1958 RVA: 0x000150F8 File Offset: 0x000132F8
			public override ITree DupNode()
			{
				return null;
			}

			// Token: 0x170000CB RID: 203
			// (get) Token: 0x060007A7 RID: 1959 RVA: 0x000150FC File Offset: 0x000132FC
			public override int Type
			{
				get
				{
					return this.type;
				}
			}

			// Token: 0x170000CC RID: 204
			// (get) Token: 0x060007A8 RID: 1960 RVA: 0x00015104 File Offset: 0x00013304
			public override string Text
			{
				get
				{
					return this.text;
				}
			}

			// Token: 0x060007A9 RID: 1961 RVA: 0x0001510C File Offset: 0x0001330C
			public override string ToString()
			{
				return "fix this";
			}

			// Token: 0x040001F0 RID: 496
			public int ID;

			// Token: 0x040001F1 RID: 497
			public int type;

			// Token: 0x040001F2 RID: 498
			public int line;

			// Token: 0x040001F3 RID: 499
			public int charPos = -1;

			// Token: 0x040001F4 RID: 500
			public int tokenIndex = -1;

			// Token: 0x040001F5 RID: 501
			public string text;
		}
	}
}
