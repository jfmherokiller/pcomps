﻿using System;
using Antlr.Runtime.Tree;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000B6 RID: 182
	public class DebugTreeNodeStream : IIntStream, ITreeNodeStream
	{
		// Token: 0x0600074C RID: 1868 RVA: 0x00013F70 File Offset: 0x00012170
		public DebugTreeNodeStream(ITreeNodeStream input, IDebugEventListener dbg)
		{
			this.input = input;
			this.adaptor = input.TreeAdaptor;
			this.input.HasUniqueNavigationNodes = true;
			this.SetDebugListener(dbg);
		}

		// Token: 0x0600074D RID: 1869 RVA: 0x00013FB0 File Offset: 0x000121B0
		public void SetDebugListener(IDebugEventListener dbg)
		{
			this.dbg = dbg;
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x0600074E RID: 1870 RVA: 0x00013FBC File Offset: 0x000121BC
		public ITokenStream TokenStream
		{
			get
			{
				return this.input.TokenStream;
			}
		}

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x0600074F RID: 1871 RVA: 0x00013FCC File Offset: 0x000121CC
		public string SourceName
		{
			get
			{
				return this.TokenStream.SourceName;
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x06000750 RID: 1872 RVA: 0x00013FDC File Offset: 0x000121DC
		public ITreeAdaptor TreeAdaptor
		{
			get
			{
				return this.adaptor;
			}
		}

		// Token: 0x06000751 RID: 1873 RVA: 0x00013FE4 File Offset: 0x000121E4
		public void Consume()
		{
			object t = this.input.LT(1);
			this.input.Consume();
			this.dbg.ConsumeNode(t);
		}

		// Token: 0x06000752 RID: 1874 RVA: 0x00014018 File Offset: 0x00012218
		public object Get(int i)
		{
			return this.input.Get(i);
		}

		// Token: 0x06000753 RID: 1875 RVA: 0x00014028 File Offset: 0x00012228
		public object LT(int i)
		{
			object obj = this.input.LT(i);
			this.dbg.LT(i, obj);
			return obj;
		}

		// Token: 0x06000754 RID: 1876 RVA: 0x00014050 File Offset: 0x00012250
		public int LA(int i)
		{
			object t = this.input.LT(i);
			int nodeType = this.adaptor.GetNodeType(t);
			this.dbg.LT(i, t);
			return nodeType;
		}

		// Token: 0x06000755 RID: 1877 RVA: 0x00014088 File Offset: 0x00012288
		public int Mark()
		{
			this.lastMarker = this.input.Mark();
			this.dbg.Mark(this.lastMarker);
			return this.lastMarker;
		}

		// Token: 0x06000756 RID: 1878 RVA: 0x000140C0 File Offset: 0x000122C0
		public int Index()
		{
			return this.input.Index();
		}

		// Token: 0x06000757 RID: 1879 RVA: 0x000140D0 File Offset: 0x000122D0
		public void Rewind(int marker)
		{
			this.dbg.Rewind(marker);
			this.input.Rewind(marker);
		}

		// Token: 0x06000758 RID: 1880 RVA: 0x000140EC File Offset: 0x000122EC
		public void Rewind()
		{
			this.dbg.Rewind();
			this.input.Rewind(this.lastMarker);
		}

		// Token: 0x06000759 RID: 1881 RVA: 0x0001410C File Offset: 0x0001230C
		public void Release(int marker)
		{
		}

		// Token: 0x0600075A RID: 1882 RVA: 0x00014110 File Offset: 0x00012310
		public void Seek(int index)
		{
			this.input.Seek(index);
		}

		// Token: 0x0600075B RID: 1883 RVA: 0x00014120 File Offset: 0x00012320
		[Obsolete("Please use property Count instead.")]
		public int Size()
		{
			return this.Count;
		}

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x0600075C RID: 1884 RVA: 0x00014128 File Offset: 0x00012328
		public int Count
		{
			get
			{
				return this.input.Count;
			}
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x0600075D RID: 1885 RVA: 0x00014138 File Offset: 0x00012338
		public object TreeSource
		{
			get
			{
				return this.input;
			}
		}

		// Token: 0x170000C0 RID: 192
		// (set) Token: 0x0600075E RID: 1886 RVA: 0x00014140 File Offset: 0x00012340
		public virtual bool HasUniqueNavigationNodes
		{
			set
			{
				this.input.HasUniqueNavigationNodes = value;
			}
		}

		// Token: 0x0600075F RID: 1887 RVA: 0x00014150 File Offset: 0x00012350
		public void ReplaceChildren(object parent, int startChildIndex, int stopChildIndex, object t)
		{
			this.input.ReplaceChildren(parent, startChildIndex, stopChildIndex, t);
		}

		// Token: 0x06000760 RID: 1888 RVA: 0x00014164 File Offset: 0x00012364
		public string ToString(object start, object stop)
		{
			return this.input.ToString(start, stop);
		}

		// Token: 0x040001D9 RID: 473
		protected IDebugEventListener dbg;

		// Token: 0x040001DA RID: 474
		protected ITreeAdaptor adaptor;

		// Token: 0x040001DB RID: 475
		protected ITreeNodeStream input;

		// Token: 0x040001DC RID: 476
		protected bool initialStreamState = true;

		// Token: 0x040001DD RID: 477
		protected int lastMarker;
	}
}
