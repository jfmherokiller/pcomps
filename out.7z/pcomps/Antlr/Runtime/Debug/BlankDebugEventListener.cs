﻿using System;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000B7 RID: 183
	public class BlankDebugEventListener : IDebugEventListener
	{
		// Token: 0x06000762 RID: 1890 RVA: 0x0001417C File Offset: 0x0001237C
		public virtual void EnterRule(string grammarFileName, string ruleName)
		{
		}

		// Token: 0x06000763 RID: 1891 RVA: 0x00014180 File Offset: 0x00012380
		public virtual void ExitRule(string grammarFileName, string ruleName)
		{
		}

		// Token: 0x06000764 RID: 1892 RVA: 0x00014184 File Offset: 0x00012384
		public virtual void EnterAlt(int alt)
		{
		}

		// Token: 0x06000765 RID: 1893 RVA: 0x00014188 File Offset: 0x00012388
		public virtual void EnterSubRule(int decisionNumber)
		{
		}

		// Token: 0x06000766 RID: 1894 RVA: 0x0001418C File Offset: 0x0001238C
		public virtual void ExitSubRule(int decisionNumber)
		{
		}

		// Token: 0x06000767 RID: 1895 RVA: 0x00014190 File Offset: 0x00012390
		public virtual void EnterDecision(int decisionNumber)
		{
		}

		// Token: 0x06000768 RID: 1896 RVA: 0x00014194 File Offset: 0x00012394
		public virtual void ExitDecision(int decisionNumber)
		{
		}

		// Token: 0x06000769 RID: 1897 RVA: 0x00014198 File Offset: 0x00012398
		public virtual void Location(int line, int pos)
		{
		}

		// Token: 0x0600076A RID: 1898 RVA: 0x0001419C File Offset: 0x0001239C
		public virtual void ConsumeToken(IToken token)
		{
		}

		// Token: 0x0600076B RID: 1899 RVA: 0x000141A0 File Offset: 0x000123A0
		public virtual void ConsumeHiddenToken(IToken token)
		{
		}

		// Token: 0x0600076C RID: 1900 RVA: 0x000141A4 File Offset: 0x000123A4
		public virtual void LT(int i, IToken t)
		{
		}

		// Token: 0x0600076D RID: 1901 RVA: 0x000141A8 File Offset: 0x000123A8
		public virtual void Mark(int i)
		{
		}

		// Token: 0x0600076E RID: 1902 RVA: 0x000141AC File Offset: 0x000123AC
		public virtual void Rewind(int i)
		{
		}

		// Token: 0x0600076F RID: 1903 RVA: 0x000141B0 File Offset: 0x000123B0
		public virtual void Rewind()
		{
		}

		// Token: 0x06000770 RID: 1904 RVA: 0x000141B4 File Offset: 0x000123B4
		public virtual void BeginBacktrack(int level)
		{
		}

		// Token: 0x06000771 RID: 1905 RVA: 0x000141B8 File Offset: 0x000123B8
		public virtual void EndBacktrack(int level, bool successful)
		{
		}

		// Token: 0x06000772 RID: 1906 RVA: 0x000141BC File Offset: 0x000123BC
		public virtual void RecognitionException(RecognitionException e)
		{
		}

		// Token: 0x06000773 RID: 1907 RVA: 0x000141C0 File Offset: 0x000123C0
		public virtual void BeginResync()
		{
		}

		// Token: 0x06000774 RID: 1908 RVA: 0x000141C4 File Offset: 0x000123C4
		public virtual void EndResync()
		{
		}

		// Token: 0x06000775 RID: 1909 RVA: 0x000141C8 File Offset: 0x000123C8
		public virtual void SemanticPredicate(bool result, string predicate)
		{
		}

		// Token: 0x06000776 RID: 1910 RVA: 0x000141CC File Offset: 0x000123CC
		public virtual void Commence()
		{
		}

		// Token: 0x06000777 RID: 1911 RVA: 0x000141D0 File Offset: 0x000123D0
		public virtual void Terminate()
		{
		}

		// Token: 0x06000778 RID: 1912 RVA: 0x000141D4 File Offset: 0x000123D4
		public virtual void ConsumeNode(object t)
		{
		}

		// Token: 0x06000779 RID: 1913 RVA: 0x000141D8 File Offset: 0x000123D8
		public virtual void LT(int i, object t)
		{
		}

		// Token: 0x0600077A RID: 1914 RVA: 0x000141DC File Offset: 0x000123DC
		public virtual void GetNilNode(object t)
		{
		}

		// Token: 0x0600077B RID: 1915 RVA: 0x000141E0 File Offset: 0x000123E0
		public virtual void ErrorNode(object t)
		{
		}

		// Token: 0x0600077C RID: 1916 RVA: 0x000141E4 File Offset: 0x000123E4
		public virtual void CreateNode(object t)
		{
		}

		// Token: 0x0600077D RID: 1917 RVA: 0x000141E8 File Offset: 0x000123E8
		public virtual void CreateNode(object node, IToken token)
		{
		}

		// Token: 0x0600077E RID: 1918 RVA: 0x000141EC File Offset: 0x000123EC
		public virtual void BecomeRoot(object newRoot, object oldRoot)
		{
		}

		// Token: 0x0600077F RID: 1919 RVA: 0x000141F0 File Offset: 0x000123F0
		public virtual void AddChild(object root, object child)
		{
		}

		// Token: 0x06000780 RID: 1920 RVA: 0x000141F4 File Offset: 0x000123F4
		public virtual void SetTokenBoundaries(object t, int tokenStartIndex, int tokenStopIndex)
		{
		}
	}
}
