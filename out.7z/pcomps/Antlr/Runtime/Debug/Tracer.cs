﻿using System;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000C1 RID: 193
	public class Tracer : BlankDebugEventListener
	{
		// Token: 0x0600082B RID: 2091 RVA: 0x00016F54 File Offset: 0x00015154
		public Tracer(IIntStream input)
		{
			this.input = input;
		}

		// Token: 0x0600082C RID: 2092 RVA: 0x00016F64 File Offset: 0x00015164
		public override void EnterRule(string grammarFileName, string ruleName)
		{
			for (int i = 1; i <= this.level; i++)
			{
				Console.Out.Write(" ");
			}
			Console.Out.WriteLine(string.Concat(new object[]
			{
				"> ",
				grammarFileName,
				" ",
				ruleName,
				" lookahead(1)=",
				this.GetInputSymbol(1)
			}));
			this.level++;
		}

		// Token: 0x0600082D RID: 2093 RVA: 0x00016FE4 File Offset: 0x000151E4
		public override void ExitRule(string grammarFileName, string ruleName)
		{
			this.level--;
			for (int i = 1; i <= this.level; i++)
			{
				Console.Out.Write(" ");
			}
			Console.Out.WriteLine(string.Concat(new object[]
			{
				"< ",
				grammarFileName,
				" ",
				ruleName,
				" lookahead(1)=",
				this.GetInputSymbol(1)
			}));
		}

		// Token: 0x0600082E RID: 2094 RVA: 0x00017064 File Offset: 0x00015264
		public virtual object GetInputSymbol(int k)
		{
			if (this.input is ITokenStream)
			{
				return ((ITokenStream)this.input).LT(k);
			}
			return (char)this.input.LA(k);
		}

		// Token: 0x0400021A RID: 538
		public IIntStream input;

		// Token: 0x0400021B RID: 539
		protected int level;
	}
}
