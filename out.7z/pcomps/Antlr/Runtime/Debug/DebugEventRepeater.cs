﻿using System;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000BD RID: 189
	public class DebugEventRepeater : IDebugEventListener
	{
		// Token: 0x060007DA RID: 2010 RVA: 0x00015D8C File Offset: 0x00013F8C
		public DebugEventRepeater(IDebugEventListener listener)
		{
			this.listener = listener;
		}

		// Token: 0x060007DB RID: 2011 RVA: 0x00015D9C File Offset: 0x00013F9C
		public void EnterRule(string grammarFileName, string ruleName)
		{
			this.listener.EnterRule(grammarFileName, ruleName);
		}

		// Token: 0x060007DC RID: 2012 RVA: 0x00015DAC File Offset: 0x00013FAC
		public void ExitRule(string grammarFileName, string ruleName)
		{
			this.listener.ExitRule(grammarFileName, ruleName);
		}

		// Token: 0x060007DD RID: 2013 RVA: 0x00015DBC File Offset: 0x00013FBC
		public void EnterAlt(int alt)
		{
			this.listener.EnterAlt(alt);
		}

		// Token: 0x060007DE RID: 2014 RVA: 0x00015DCC File Offset: 0x00013FCC
		public void EnterSubRule(int decisionNumber)
		{
			this.listener.EnterSubRule(decisionNumber);
		}

		// Token: 0x060007DF RID: 2015 RVA: 0x00015DDC File Offset: 0x00013FDC
		public void ExitSubRule(int decisionNumber)
		{
			this.listener.ExitSubRule(decisionNumber);
		}

		// Token: 0x060007E0 RID: 2016 RVA: 0x00015DEC File Offset: 0x00013FEC
		public void EnterDecision(int decisionNumber)
		{
			this.listener.EnterDecision(decisionNumber);
		}

		// Token: 0x060007E1 RID: 2017 RVA: 0x00015DFC File Offset: 0x00013FFC
		public void ExitDecision(int decisionNumber)
		{
			this.listener.ExitDecision(decisionNumber);
		}

		// Token: 0x060007E2 RID: 2018 RVA: 0x00015E0C File Offset: 0x0001400C
		public void Location(int line, int pos)
		{
			this.listener.Location(line, pos);
		}

		// Token: 0x060007E3 RID: 2019 RVA: 0x00015E1C File Offset: 0x0001401C
		public void ConsumeToken(IToken token)
		{
			this.listener.ConsumeToken(token);
		}

		// Token: 0x060007E4 RID: 2020 RVA: 0x00015E2C File Offset: 0x0001402C
		public void ConsumeHiddenToken(IToken token)
		{
			this.listener.ConsumeHiddenToken(token);
		}

		// Token: 0x060007E5 RID: 2021 RVA: 0x00015E3C File Offset: 0x0001403C
		public void LT(int i, IToken t)
		{
			this.listener.LT(i, t);
		}

		// Token: 0x060007E6 RID: 2022 RVA: 0x00015E4C File Offset: 0x0001404C
		public void Mark(int i)
		{
			this.listener.Mark(i);
		}

		// Token: 0x060007E7 RID: 2023 RVA: 0x00015E5C File Offset: 0x0001405C
		public void Rewind(int i)
		{
			this.listener.Rewind(i);
		}

		// Token: 0x060007E8 RID: 2024 RVA: 0x00015E6C File Offset: 0x0001406C
		public void Rewind()
		{
			this.listener.Rewind();
		}

		// Token: 0x060007E9 RID: 2025 RVA: 0x00015E7C File Offset: 0x0001407C
		public void BeginBacktrack(int level)
		{
			this.listener.BeginBacktrack(level);
		}

		// Token: 0x060007EA RID: 2026 RVA: 0x00015E8C File Offset: 0x0001408C
		public void EndBacktrack(int level, bool successful)
		{
			this.listener.EndBacktrack(level, successful);
		}

		// Token: 0x060007EB RID: 2027 RVA: 0x00015E9C File Offset: 0x0001409C
		public void RecognitionException(RecognitionException e)
		{
			this.listener.RecognitionException(e);
		}

		// Token: 0x060007EC RID: 2028 RVA: 0x00015EAC File Offset: 0x000140AC
		public void BeginResync()
		{
			this.listener.BeginResync();
		}

		// Token: 0x060007ED RID: 2029 RVA: 0x00015EBC File Offset: 0x000140BC
		public void EndResync()
		{
			this.listener.EndResync();
		}

		// Token: 0x060007EE RID: 2030 RVA: 0x00015ECC File Offset: 0x000140CC
		public void SemanticPredicate(bool result, string predicate)
		{
			this.listener.SemanticPredicate(result, predicate);
		}

		// Token: 0x060007EF RID: 2031 RVA: 0x00015EDC File Offset: 0x000140DC
		public void Commence()
		{
			this.listener.Commence();
		}

		// Token: 0x060007F0 RID: 2032 RVA: 0x00015EEC File Offset: 0x000140EC
		public void Terminate()
		{
			this.listener.Terminate();
		}

		// Token: 0x060007F1 RID: 2033 RVA: 0x00015EFC File Offset: 0x000140FC
		public void ConsumeNode(object t)
		{
			this.listener.ConsumeNode(t);
		}

		// Token: 0x060007F2 RID: 2034 RVA: 0x00015F0C File Offset: 0x0001410C
		public void LT(int i, object t)
		{
			this.listener.LT(i, t);
		}

		// Token: 0x060007F3 RID: 2035 RVA: 0x00015F1C File Offset: 0x0001411C
		public void GetNilNode(object t)
		{
			this.listener.GetNilNode(t);
		}

		// Token: 0x060007F4 RID: 2036 RVA: 0x00015F2C File Offset: 0x0001412C
		public void ErrorNode(object t)
		{
			this.listener.ErrorNode(t);
		}

		// Token: 0x060007F5 RID: 2037 RVA: 0x00015F3C File Offset: 0x0001413C
		public void CreateNode(object t)
		{
			this.listener.CreateNode(t);
		}

		// Token: 0x060007F6 RID: 2038 RVA: 0x00015F4C File Offset: 0x0001414C
		public void CreateNode(object node, IToken token)
		{
			this.listener.CreateNode(node, token);
		}

		// Token: 0x060007F7 RID: 2039 RVA: 0x00015F5C File Offset: 0x0001415C
		public void BecomeRoot(object newRoot, object oldRoot)
		{
			this.listener.BecomeRoot(newRoot, oldRoot);
		}

		// Token: 0x060007F8 RID: 2040 RVA: 0x00015F6C File Offset: 0x0001416C
		public void AddChild(object root, object child)
		{
			this.listener.AddChild(root, child);
		}

		// Token: 0x060007F9 RID: 2041 RVA: 0x00015F7C File Offset: 0x0001417C
		public void SetTokenBoundaries(object t, int tokenStartIndex, int tokenStopIndex)
		{
			this.listener.SetTokenBoundaries(t, tokenStartIndex, tokenStopIndex);
		}

		// Token: 0x040001F8 RID: 504
		protected IDebugEventListener listener;
	}
}
