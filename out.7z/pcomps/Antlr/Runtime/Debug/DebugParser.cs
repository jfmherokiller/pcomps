﻿using System;
using System.IO;
using Antlr.Runtime.Misc;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000B0 RID: 176
	public class DebugParser : Parser
	{
		// Token: 0x060006E5 RID: 1765 RVA: 0x00013710 File Offset: 0x00011910
		public DebugParser(ITokenStream input, IDebugEventListener dbg, RecognizerSharedState state) : base((!(input is DebugTokenStream)) ? new DebugTokenStream(input, dbg) : input, state)
		{
			this.DebugListener = dbg;
		}

		// Token: 0x060006E6 RID: 1766 RVA: 0x00013748 File Offset: 0x00011948
		public DebugParser(ITokenStream input, RecognizerSharedState state) : base((!(input is DebugTokenStream)) ? new DebugTokenStream(input, null) : input, state)
		{
		}

		// Token: 0x060006E7 RID: 1767 RVA: 0x00013778 File Offset: 0x00011978
		public DebugParser(ITokenStream input, IDebugEventListener dbg) : this((!(input is DebugTokenStream)) ? new DebugTokenStream(input, dbg) : input, dbg, null)
		{
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x060006E8 RID: 1768 RVA: 0x000137A8 File Offset: 0x000119A8
		// (set) Token: 0x060006E9 RID: 1769 RVA: 0x000137B0 File Offset: 0x000119B0
		public virtual IDebugEventListener DebugListener
		{
			get
			{
				return this.dbg;
			}
			set
			{
				if (this.input is DebugTokenStream)
				{
					((DebugTokenStream)this.input).DebugListener = value;
				}
				this.dbg = value;
			}
		}

		// Token: 0x060006EA RID: 1770 RVA: 0x000137E8 File Offset: 0x000119E8
		public virtual void ReportError(IOException e)
		{
			ErrorManager.InternalError(e);
		}

		// Token: 0x060006EB RID: 1771 RVA: 0x000137F0 File Offset: 0x000119F0
		public override void BeginResync()
		{
			this.dbg.BeginResync();
		}

		// Token: 0x060006EC RID: 1772 RVA: 0x00013800 File Offset: 0x00011A00
		public override void EndResync()
		{
			this.dbg.EndResync();
		}

		// Token: 0x060006ED RID: 1773 RVA: 0x00013810 File Offset: 0x00011A10
		public override void ReportError(RecognitionException e)
		{
			this.dbg.RecognitionException(e);
		}

		// Token: 0x040001CC RID: 460
		protected internal IDebugEventListener dbg;

		// Token: 0x040001CD RID: 461
		public bool isCyclicDecision;
	}
}
