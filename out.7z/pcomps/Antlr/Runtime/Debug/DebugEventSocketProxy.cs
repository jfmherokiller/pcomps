﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using Antlr.Runtime.Tree;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000AF RID: 175
	public class DebugEventSocketProxy : BlankDebugEventListener
	{
		// Token: 0x060006BB RID: 1723 RVA: 0x00012D14 File Offset: 0x00010F14
		public DebugEventSocketProxy(BaseRecognizer recognizer, ITreeAdaptor adaptor) : this(recognizer, 49100, adaptor)
		{
		}

		// Token: 0x060006BC RID: 1724 RVA: 0x00012D24 File Offset: 0x00010F24
		public DebugEventSocketProxy(BaseRecognizer recognizer, int port, ITreeAdaptor adaptor)
		{
			this.grammarFileName = recognizer.GrammarFileName;
			this.port = port;
			this.adaptor = adaptor;
		}

		// Token: 0x060006BD RID: 1725 RVA: 0x00012D54 File Offset: 0x00010F54
		public virtual void Handshake()
		{
			if (this.serverSocket == null)
			{
				this.serverSocket = new TcpListener(this.port);
				this.serverSocket.Start();
				this.socket = this.serverSocket.AcceptTcpClient();
				this.socket.NoDelay = true;
				this.reader = new StreamReader(this.socket.GetStream(), Encoding.UTF8);
				this.writer = new StreamWriter(this.socket.GetStream(), Encoding.UTF8);
				this.writer.WriteLine("ANTLR " + Constants.DEBUG_PROTOCOL_VERSION);
				this.writer.WriteLine("grammar \"" + this.grammarFileName);
				this.writer.Flush();
				this.Ack();
			}
		}

		// Token: 0x060006BE RID: 1726 RVA: 0x00012E24 File Offset: 0x00011024
		public override void Commence()
		{
		}

		// Token: 0x060006BF RID: 1727 RVA: 0x00012E28 File Offset: 0x00011028
		public override void Terminate()
		{
			this.Transmit("terminate");
			this.writer.Close();
			try
			{
				this.socket.Close();
			}
			catch (IOException ex)
			{
				Console.Error.WriteLine(ex.StackTrace);
			}
		}

		// Token: 0x060006C0 RID: 1728 RVA: 0x00012E84 File Offset: 0x00011084
		protected internal virtual void Ack()
		{
			try
			{
				this.reader.ReadLine();
			}
			catch (IOException ex)
			{
				Console.Error.WriteLine(ex.StackTrace);
			}
		}

		// Token: 0x060006C1 RID: 1729 RVA: 0x00012EC8 File Offset: 0x000110C8
		protected internal virtual void Transmit(string eventLabel)
		{
			this.writer.WriteLine(eventLabel);
			this.writer.Flush();
			this.Ack();
		}

		// Token: 0x060006C2 RID: 1730 RVA: 0x00012EE8 File Offset: 0x000110E8
		public override void EnterRule(string grammarFileName, string ruleName)
		{
			this.Transmit("enterRule\t" + grammarFileName + "\t" + ruleName);
		}

		// Token: 0x060006C3 RID: 1731 RVA: 0x00012F04 File Offset: 0x00011104
		public override void EnterAlt(int alt)
		{
			this.Transmit("enterAlt\t" + alt);
		}

		// Token: 0x060006C4 RID: 1732 RVA: 0x00012F1C File Offset: 0x0001111C
		public override void ExitRule(string grammarFileName, string ruleName)
		{
			this.Transmit("exitRule\t" + grammarFileName + "\t" + ruleName);
		}

		// Token: 0x060006C5 RID: 1733 RVA: 0x00012F38 File Offset: 0x00011138
		public override void EnterSubRule(int decisionNumber)
		{
			this.Transmit("enterSubRule\t" + decisionNumber);
		}

		// Token: 0x060006C6 RID: 1734 RVA: 0x00012F50 File Offset: 0x00011150
		public override void ExitSubRule(int decisionNumber)
		{
			this.Transmit("exitSubRule\t" + decisionNumber);
		}

		// Token: 0x060006C7 RID: 1735 RVA: 0x00012F68 File Offset: 0x00011168
		public override void EnterDecision(int decisionNumber)
		{
			this.Transmit("enterDecision\t" + decisionNumber);
		}

		// Token: 0x060006C8 RID: 1736 RVA: 0x00012F80 File Offset: 0x00011180
		public override void ExitDecision(int decisionNumber)
		{
			this.Transmit("exitDecision\t" + decisionNumber);
		}

		// Token: 0x060006C9 RID: 1737 RVA: 0x00012F98 File Offset: 0x00011198
		public override void ConsumeToken(IToken t)
		{
			string str = this.SerializeToken(t);
			this.Transmit("consumeToken\t" + str);
		}

		// Token: 0x060006CA RID: 1738 RVA: 0x00012FC0 File Offset: 0x000111C0
		public override void ConsumeHiddenToken(IToken t)
		{
			string str = this.SerializeToken(t);
			this.Transmit("consumeHiddenToken\t" + str);
		}

		// Token: 0x060006CB RID: 1739 RVA: 0x00012FE8 File Offset: 0x000111E8
		public override void LT(int i, IToken t)
		{
			if (t != null)
			{
				this.Transmit(string.Concat(new object[]
				{
					"LT\t",
					i,
					"\t",
					this.SerializeToken(t)
				}));
			}
		}

		// Token: 0x060006CC RID: 1740 RVA: 0x00013030 File Offset: 0x00011230
		public override void Mark(int i)
		{
			this.Transmit("mark\t" + i);
		}

		// Token: 0x060006CD RID: 1741 RVA: 0x00013048 File Offset: 0x00011248
		public override void Rewind(int i)
		{
			this.Transmit("rewind\t" + i);
		}

		// Token: 0x060006CE RID: 1742 RVA: 0x00013060 File Offset: 0x00011260
		public override void Rewind()
		{
			this.Transmit("rewind");
		}

		// Token: 0x060006CF RID: 1743 RVA: 0x00013070 File Offset: 0x00011270
		public override void BeginBacktrack(int level)
		{
			this.Transmit("beginBacktrack\t" + level);
		}

		// Token: 0x060006D0 RID: 1744 RVA: 0x00013088 File Offset: 0x00011288
		public override void EndBacktrack(int level, bool successful)
		{
			this.Transmit(string.Concat(new object[]
			{
				"endBacktrack\t",
				level,
				"\t",
				(!successful) ? false.ToString() : true.ToString()
			}));
		}

		// Token: 0x060006D1 RID: 1745 RVA: 0x000130E0 File Offset: 0x000112E0
		public override void Location(int line, int pos)
		{
			this.Transmit(string.Concat(new object[]
			{
				"location\t",
				line,
				"\t",
				pos
			}));
		}

		// Token: 0x060006D2 RID: 1746 RVA: 0x00013118 File Offset: 0x00011318
		public override void RecognitionException(RecognitionException e)
		{
			StringBuilder stringBuilder = new StringBuilder(50);
			stringBuilder.Append("exception\t");
			stringBuilder.Append(e.GetType().FullName);
			stringBuilder.Append("\t");
			stringBuilder.Append(e.Index);
			stringBuilder.Append("\t");
			stringBuilder.Append(e.Line);
			stringBuilder.Append("\t");
			stringBuilder.Append(e.CharPositionInLine);
			this.Transmit(stringBuilder.ToString());
		}

		// Token: 0x060006D3 RID: 1747 RVA: 0x000131A4 File Offset: 0x000113A4
		public override void BeginResync()
		{
			this.Transmit("beginResync");
		}

		// Token: 0x060006D4 RID: 1748 RVA: 0x000131B4 File Offset: 0x000113B4
		public override void EndResync()
		{
			this.Transmit("endResync");
		}

		// Token: 0x060006D5 RID: 1749 RVA: 0x000131C4 File Offset: 0x000113C4
		public override void SemanticPredicate(bool result, string predicate)
		{
			StringBuilder stringBuilder = new StringBuilder(50);
			stringBuilder.Append("semanticPredicate\t");
			stringBuilder.Append(result);
			this.SerializeText(stringBuilder, predicate);
			this.Transmit(stringBuilder.ToString());
		}

		// Token: 0x060006D6 RID: 1750 RVA: 0x00013204 File Offset: 0x00011404
		public override void ConsumeNode(object t)
		{
			StringBuilder stringBuilder = new StringBuilder(50);
			stringBuilder.Append("consumeNode\t");
			this.SerializeNode(stringBuilder, t);
			this.Transmit(stringBuilder.ToString());
		}

		// Token: 0x060006D7 RID: 1751 RVA: 0x0001323C File Offset: 0x0001143C
		public override void LT(int i, object t)
		{
			int uniqueID = this.adaptor.GetUniqueID(t);
			string nodeText = this.adaptor.GetNodeText(t);
			int nodeType = this.adaptor.GetNodeType(t);
			StringBuilder stringBuilder = new StringBuilder(50);
			stringBuilder.Append("LN\t");
			stringBuilder.Append(i);
			this.SerializeNode(stringBuilder, t);
			this.Transmit(stringBuilder.ToString());
		}

		// Token: 0x060006D8 RID: 1752 RVA: 0x000132A0 File Offset: 0x000114A0
		public override void GetNilNode(object t)
		{
			int uniqueID = this.adaptor.GetUniqueID(t);
			this.Transmit("nilNode\t" + uniqueID);
		}

		// Token: 0x060006D9 RID: 1753 RVA: 0x000132D0 File Offset: 0x000114D0
		public override void ErrorNode(object t)
		{
			int uniqueID = this.adaptor.GetUniqueID(t);
			string text = t.ToString();
			StringBuilder stringBuilder = new StringBuilder(50);
			stringBuilder.Append("errorNode\t");
			stringBuilder.Append(uniqueID);
			stringBuilder.Append("\t");
			stringBuilder.Append(0);
			this.SerializeText(stringBuilder, text);
			this.Transmit(stringBuilder.ToString());
		}

		// Token: 0x060006DA RID: 1754 RVA: 0x00013338 File Offset: 0x00011538
		public override void CreateNode(object t)
		{
			int uniqueID = this.adaptor.GetUniqueID(t);
			string nodeText = this.adaptor.GetNodeText(t);
			int nodeType = this.adaptor.GetNodeType(t);
			StringBuilder stringBuilder = new StringBuilder(50);
			stringBuilder.Append("createNodeFromTokenElements\t");
			stringBuilder.Append(uniqueID);
			stringBuilder.Append("\t");
			stringBuilder.Append(nodeType);
			this.SerializeText(stringBuilder, nodeText);
			this.Transmit(stringBuilder.ToString());
		}

		// Token: 0x060006DB RID: 1755 RVA: 0x000133B0 File Offset: 0x000115B0
		public override void CreateNode(object node, IToken token)
		{
			int uniqueID = this.adaptor.GetUniqueID(node);
			int tokenIndex = token.TokenIndex;
			this.Transmit(string.Concat(new object[]
			{
				"createNode\t",
				uniqueID,
				"\t",
				tokenIndex
			}));
		}

		// Token: 0x060006DC RID: 1756 RVA: 0x00013404 File Offset: 0x00011604
		public override void BecomeRoot(object newRoot, object oldRoot)
		{
			int uniqueID = this.adaptor.GetUniqueID(newRoot);
			int uniqueID2 = this.adaptor.GetUniqueID(oldRoot);
			this.Transmit(string.Concat(new object[]
			{
				"becomeRoot\t",
				uniqueID,
				"\t",
				uniqueID2
			}));
		}

		// Token: 0x060006DD RID: 1757 RVA: 0x00013460 File Offset: 0x00011660
		public override void AddChild(object root, object child)
		{
			int uniqueID = this.adaptor.GetUniqueID(root);
			int uniqueID2 = this.adaptor.GetUniqueID(child);
			this.Transmit(string.Concat(new object[]
			{
				"addChild\t",
				uniqueID,
				"\t",
				uniqueID2
			}));
		}

		// Token: 0x060006DE RID: 1758 RVA: 0x000134BC File Offset: 0x000116BC
		public override void SetTokenBoundaries(object t, int tokenStartIndex, int tokenStopIndex)
		{
			int uniqueID = this.adaptor.GetUniqueID(t);
			this.Transmit(string.Concat(new object[]
			{
				"setTokenBoundaries\t",
				uniqueID,
				"\t",
				tokenStartIndex,
				"\t",
				tokenStopIndex
			}));
		}

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x060006E0 RID: 1760 RVA: 0x00013528 File Offset: 0x00011728
		// (set) Token: 0x060006DF RID: 1759 RVA: 0x0001351C File Offset: 0x0001171C
		public ITreeAdaptor TreeAdaptor
		{
			get
			{
				return this.adaptor;
			}
			set
			{
				this.adaptor = value;
			}
		}

		// Token: 0x060006E1 RID: 1761 RVA: 0x00013530 File Offset: 0x00011730
		protected internal virtual string SerializeToken(IToken t)
		{
			StringBuilder stringBuilder = new StringBuilder(50);
			stringBuilder.Append(t.TokenIndex);
			stringBuilder.Append('\t');
			stringBuilder.Append(t.Type);
			stringBuilder.Append('\t');
			stringBuilder.Append(t.Channel);
			stringBuilder.Append('\t');
			stringBuilder.Append(t.Line);
			stringBuilder.Append('\t');
			stringBuilder.Append(t.CharPositionInLine);
			this.SerializeText(stringBuilder, t.Text);
			return stringBuilder.ToString();
		}

		// Token: 0x060006E2 RID: 1762 RVA: 0x000135C0 File Offset: 0x000117C0
		protected internal virtual string EscapeNewlines(string txt)
		{
			txt = txt.Replace("%", "%25");
			txt = txt.Replace("\n", "%0A");
			txt = txt.Replace("\r", "%0D");
			return txt;
		}

		// Token: 0x060006E3 RID: 1763 RVA: 0x000135FC File Offset: 0x000117FC
		protected internal void SerializeNode(StringBuilder buf, object t)
		{
			int uniqueID = this.adaptor.GetUniqueID(t);
			string nodeText = this.adaptor.GetNodeText(t);
			int nodeType = this.adaptor.GetNodeType(t);
			buf.Append("\t");
			buf.Append(uniqueID);
			buf.Append("\t");
			buf.Append(nodeType);
			IToken token = this.adaptor.GetToken(t);
			int value = -1;
			int value2 = -1;
			if (token != null)
			{
				value = token.Line;
				value2 = token.CharPositionInLine;
			}
			buf.Append("\t");
			buf.Append(value);
			buf.Append("\t");
			buf.Append(value2);
			int tokenStartIndex = this.adaptor.GetTokenStartIndex(t);
			buf.Append("\t");
			buf.Append(tokenStartIndex);
			this.SerializeText(buf, nodeText);
		}

		// Token: 0x060006E4 RID: 1764 RVA: 0x000136D8 File Offset: 0x000118D8
		protected void SerializeText(StringBuilder buf, string text)
		{
			buf.Append("\t\"");
			if (text == null)
			{
				text = string.Empty;
			}
			text = this.EscapeNewlines(text);
			buf.Append(text);
		}

		// Token: 0x040001C3 RID: 451
		public const int DEFAULT_DEBUGGER_PORT = 49100;

		// Token: 0x040001C4 RID: 452
		protected int port = 49100;

		// Token: 0x040001C5 RID: 453
		protected TcpListener serverSocket;

		// Token: 0x040001C6 RID: 454
		protected TcpClient socket;

		// Token: 0x040001C7 RID: 455
		protected string grammarFileName;

		// Token: 0x040001C8 RID: 456
		protected StreamWriter writer;

		// Token: 0x040001C9 RID: 457
		protected StreamReader reader;

		// Token: 0x040001CA RID: 458
		protected BaseRecognizer recognizer;

		// Token: 0x040001CB RID: 459
		protected ITreeAdaptor adaptor;
	}
}
