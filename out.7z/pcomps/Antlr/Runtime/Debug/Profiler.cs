﻿using System;
using System.Collections;
using System.IO;
using System.Text;
using Antlr.Runtime.Misc;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000C0 RID: 192
	public class Profiler : BlankDebugEventListener
	{
		// Token: 0x06000812 RID: 2066 RVA: 0x000162CC File Offset: 0x000144CC
		public Profiler()
		{
		}

		// Token: 0x06000813 RID: 2067 RVA: 0x00016318 File Offset: 0x00014518
		public Profiler(DebugParser parser)
		{
			this.parser = parser;
		}

		// Token: 0x06000814 RID: 2068 RVA: 0x00016368 File Offset: 0x00014568
		public override void EnterRule(string grammarFileName, string ruleName)
		{
			this.ruleLevel++;
			this.numRuleInvocations++;
			if (this.ruleLevel > this.maxRuleInvocationDepth)
			{
				this.maxRuleInvocationDepth = this.ruleLevel;
			}
		}

		// Token: 0x06000815 RID: 2069 RVA: 0x000163A4 File Offset: 0x000145A4
		public void ExamineRuleMemoization(IIntStream input, int ruleIndex, string ruleName)
		{
			int ruleMemoization = this.parser.GetRuleMemoization(ruleIndex, input.Index());
			if (ruleMemoization == -1)
			{
				this.numMemoizationCacheMisses++;
				this.numGuessingRuleInvocations++;
			}
			else
			{
				this.numMemoizationCacheHits++;
			}
		}

		// Token: 0x06000816 RID: 2070 RVA: 0x000163FC File Offset: 0x000145FC
		public void Memoize(IIntStream input, int ruleIndex, int ruleStartIndex, string ruleName)
		{
			this.numMemoizationCacheEntries++;
		}

		// Token: 0x06000817 RID: 2071 RVA: 0x0001640C File Offset: 0x0001460C
		public override void ExitRule(string grammarFileName, string ruleName)
		{
			this.ruleLevel--;
		}

		// Token: 0x06000818 RID: 2072 RVA: 0x0001641C File Offset: 0x0001461C
		public override void EnterDecision(int decisionNumber)
		{
			this.decisionLevel++;
			int num = this.parser.TokenStream.Index();
			this.lookaheadStack.Add(num);
		}

		// Token: 0x06000819 RID: 2073 RVA: 0x0001645C File Offset: 0x0001465C
		public override void ExitDecision(int decisionNumber)
		{
			if (this.parser.isCyclicDecision)
			{
				this.numCyclicDecisions++;
			}
			else
			{
				this.numFixedDecisions++;
			}
			this.lookaheadStack.Remove(this.lookaheadStack.Count - 1);
			this.decisionLevel--;
			if (this.parser.isCyclicDecision)
			{
				if (this.numCyclicDecisions >= this.decisionMaxCyclicLookaheads.Length)
				{
					int[] destinationArray = new int[this.decisionMaxCyclicLookaheads.Length * 2];
					Array.Copy(this.decisionMaxCyclicLookaheads, 0, destinationArray, 0, this.decisionMaxCyclicLookaheads.Length);
					this.decisionMaxCyclicLookaheads = destinationArray;
				}
				this.decisionMaxCyclicLookaheads[this.numCyclicDecisions - 1] = this.maxLookaheadInCurrentDecision;
			}
			else
			{
				if (this.numFixedDecisions >= this.decisionMaxFixedLookaheads.Length)
				{
					int[] destinationArray2 = new int[this.decisionMaxFixedLookaheads.Length * 2];
					Array.Copy(this.decisionMaxFixedLookaheads, 0, destinationArray2, 0, this.decisionMaxFixedLookaheads.Length);
					this.decisionMaxFixedLookaheads = destinationArray2;
				}
				this.decisionMaxFixedLookaheads[this.numFixedDecisions - 1] = this.maxLookaheadInCurrentDecision;
			}
			this.parser.isCyclicDecision = false;
			this.maxLookaheadInCurrentDecision = 0;
		}

		// Token: 0x0600081A RID: 2074 RVA: 0x00016598 File Offset: 0x00014798
		public override void ConsumeToken(IToken token)
		{
			this.lastTokenConsumed = (CommonToken)token;
		}

		// Token: 0x0600081B RID: 2075 RVA: 0x000165A8 File Offset: 0x000147A8
		public bool InDecision()
		{
			return this.decisionLevel > 0;
		}

		// Token: 0x0600081C RID: 2076 RVA: 0x000165B4 File Offset: 0x000147B4
		public override void ConsumeHiddenToken(IToken token)
		{
			this.lastTokenConsumed = (CommonToken)token;
		}

		// Token: 0x0600081D RID: 2077 RVA: 0x000165C4 File Offset: 0x000147C4
		public override void LT(int i, IToken t)
		{
			if (this.InDecision())
			{
				int index = this.lookaheadStack.Count - 1;
				int num = (int)this.lookaheadStack[index];
				int num2 = this.parser.TokenStream.Index();
				int numberOfHiddenTokens = this.GetNumberOfHiddenTokens(num, num2);
				int num3 = i + num2 - num - numberOfHiddenTokens;
				if (num3 > this.maxLookaheadInCurrentDecision)
				{
					this.maxLookaheadInCurrentDecision = num3;
				}
			}
		}

		// Token: 0x0600081E RID: 2078 RVA: 0x00016638 File Offset: 0x00014838
		public override void BeginBacktrack(int level)
		{
			this.numBacktrackDecisions++;
		}

		// Token: 0x0600081F RID: 2079 RVA: 0x00016648 File Offset: 0x00014848
		public override void EndBacktrack(int level, bool successful)
		{
			this.decisionMaxSynPredLookaheads.Add(this.maxLookaheadInCurrentDecision);
		}

		// Token: 0x06000820 RID: 2080 RVA: 0x00016664 File Offset: 0x00014864
		public override void RecognitionException(RecognitionException e)
		{
			this.numberReportedErrors++;
		}

		// Token: 0x06000821 RID: 2081 RVA: 0x00016674 File Offset: 0x00014874
		public override void SemanticPredicate(bool result, string predicate)
		{
			if (this.InDecision())
			{
				this.numSemanticPredicates++;
			}
		}

		// Token: 0x06000822 RID: 2082 RVA: 0x00016690 File Offset: 0x00014890
		public override void Terminate()
		{
			string text = this.ToNotifyString();
			try
			{
				Stats.WriteReport("runtime.stats", text);
			}
			catch (IOException ex)
			{
				Console.Error.WriteLine(ex);
				Console.Error.WriteLine(ex.StackTrace);
			}
			Console.Out.WriteLine(Profiler.ToString(text));
		}

		// Token: 0x170000CF RID: 207
		// (set) Token: 0x06000823 RID: 2083 RVA: 0x000166F8 File Offset: 0x000148F8
		public virtual DebugParser Parser
		{
			set
			{
				this.parser = value;
			}
		}

		// Token: 0x06000824 RID: 2084 RVA: 0x00016704 File Offset: 0x00014904
		public virtual string ToNotifyString()
		{
			ITokenStream tokenStream = this.parser.TokenStream;
			int num = 0;
			while (num < tokenStream.Count && this.lastTokenConsumed != null && num <= this.lastTokenConsumed.TokenIndex)
			{
				IToken token = tokenStream.Get(num);
				if (token.Channel != 0)
				{
					this.numHiddenTokens++;
					this.numHiddenCharsMatched += token.Text.Length;
				}
				num++;
			}
			this.numCharsMatched = this.lastTokenConsumed.StopIndex + 1;
			this.decisionMaxFixedLookaheads = this.Trim(this.decisionMaxFixedLookaheads, this.numFixedDecisions);
			this.decisionMaxCyclicLookaheads = this.Trim(this.decisionMaxCyclicLookaheads, this.numCyclicDecisions);
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("2");
			stringBuilder.Append('\t');
			stringBuilder.Append(this.parser.GetType().FullName);
			stringBuilder.Append('\t');
			stringBuilder.Append(this.numRuleInvocations);
			stringBuilder.Append('\t');
			stringBuilder.Append(this.maxRuleInvocationDepth);
			stringBuilder.Append('\t');
			stringBuilder.Append(this.numFixedDecisions);
			stringBuilder.Append('\t');
			stringBuilder.Append(Stats.Min(this.decisionMaxFixedLookaheads));
			stringBuilder.Append('\t');
			stringBuilder.Append(Stats.Max(this.decisionMaxFixedLookaheads));
			stringBuilder.Append('\t');
			stringBuilder.Append(Stats.Avg(this.decisionMaxFixedLookaheads));
			stringBuilder.Append('\t');
			stringBuilder.Append(Stats.Stddev(this.decisionMaxFixedLookaheads));
			stringBuilder.Append('\t');
			stringBuilder.Append(this.numCyclicDecisions);
			stringBuilder.Append('\t');
			stringBuilder.Append(Stats.Min(this.decisionMaxCyclicLookaheads));
			stringBuilder.Append('\t');
			stringBuilder.Append(Stats.Max(this.decisionMaxCyclicLookaheads));
			stringBuilder.Append('\t');
			stringBuilder.Append(Stats.Avg(this.decisionMaxCyclicLookaheads));
			stringBuilder.Append('\t');
			stringBuilder.Append(Stats.Stddev(this.decisionMaxCyclicLookaheads));
			stringBuilder.Append('\t');
			stringBuilder.Append(this.numBacktrackDecisions);
			stringBuilder.Append('\t');
			stringBuilder.Append(Stats.Min(this.ToArray(this.decisionMaxSynPredLookaheads)));
			stringBuilder.Append('\t');
			stringBuilder.Append(Stats.Max(this.ToArray(this.decisionMaxSynPredLookaheads)));
			stringBuilder.Append('\t');
			stringBuilder.Append(Stats.Avg(this.ToArray(this.decisionMaxSynPredLookaheads)));
			stringBuilder.Append('\t');
			stringBuilder.Append(Stats.Stddev(this.ToArray(this.decisionMaxSynPredLookaheads)));
			stringBuilder.Append('\t');
			stringBuilder.Append(this.numSemanticPredicates);
			stringBuilder.Append('\t');
			stringBuilder.Append(this.parser.TokenStream.Count);
			stringBuilder.Append('\t');
			stringBuilder.Append(this.numHiddenTokens);
			stringBuilder.Append('\t');
			stringBuilder.Append(this.numCharsMatched);
			stringBuilder.Append('\t');
			stringBuilder.Append(this.numHiddenCharsMatched);
			stringBuilder.Append('\t');
			stringBuilder.Append(this.numberReportedErrors);
			stringBuilder.Append('\t');
			stringBuilder.Append(this.numMemoizationCacheHits);
			stringBuilder.Append('\t');
			stringBuilder.Append(this.numMemoizationCacheMisses);
			stringBuilder.Append('\t');
			stringBuilder.Append(this.numGuessingRuleInvocations);
			stringBuilder.Append('\t');
			stringBuilder.Append(this.numMemoizationCacheEntries);
			return stringBuilder.ToString();
		}

		// Token: 0x06000825 RID: 2085 RVA: 0x00016AB4 File Offset: 0x00014CB4
		public override string ToString()
		{
			return Profiler.ToString(this.ToNotifyString());
		}

		// Token: 0x06000826 RID: 2086 RVA: 0x00016AC4 File Offset: 0x00014CC4
		protected static string[] DecodeReportData(string data)
		{
			string[] array = data.Split(new char[]
			{
				'\t'
			});
			if (array.Length != 29)
			{
				return null;
			}
			return array;
		}

		// Token: 0x06000827 RID: 2087 RVA: 0x00016AF0 File Offset: 0x00014CF0
		public static string ToString(string notifyDataLine)
		{
			string[] array = Profiler.DecodeReportData(notifyDataLine);
			if (array == null)
			{
				return null;
			}
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("ANTLR Runtime Report; Profile Version ");
			stringBuilder.Append(array[0]);
			stringBuilder.Append('\n');
			stringBuilder.Append("parser name ");
			stringBuilder.Append(array[1]);
			stringBuilder.Append('\n');
			stringBuilder.Append("Number of rule invocations ");
			stringBuilder.Append(array[2]);
			stringBuilder.Append('\n');
			stringBuilder.Append("Number of rule invocations in \"guessing\" mode ");
			stringBuilder.Append(array[27]);
			stringBuilder.Append('\n');
			stringBuilder.Append("max rule invocation nesting depth ");
			stringBuilder.Append(array[3]);
			stringBuilder.Append('\n');
			stringBuilder.Append("number of fixed lookahead decisions ");
			stringBuilder.Append(array[4]);
			stringBuilder.Append('\n');
			stringBuilder.Append("min lookahead used in a fixed lookahead decision ");
			stringBuilder.Append(array[5]);
			stringBuilder.Append('\n');
			stringBuilder.Append("max lookahead used in a fixed lookahead decision ");
			stringBuilder.Append(array[6]);
			stringBuilder.Append('\n');
			stringBuilder.Append("average lookahead depth used in fixed lookahead decisions ");
			stringBuilder.Append(array[7]);
			stringBuilder.Append('\n');
			stringBuilder.Append("standard deviation of depth used in fixed lookahead decisions ");
			stringBuilder.Append(array[8]);
			stringBuilder.Append('\n');
			stringBuilder.Append("number of arbitrary lookahead decisions ");
			stringBuilder.Append(array[9]);
			stringBuilder.Append('\n');
			stringBuilder.Append("min lookahead used in an arbitrary lookahead decision ");
			stringBuilder.Append(array[10]);
			stringBuilder.Append('\n');
			stringBuilder.Append("max lookahead used in an arbitrary lookahead decision ");
			stringBuilder.Append(array[11]);
			stringBuilder.Append('\n');
			stringBuilder.Append("average lookahead depth used in arbitrary lookahead decisions ");
			stringBuilder.Append(array[12]);
			stringBuilder.Append('\n');
			stringBuilder.Append("standard deviation of depth used in arbitrary lookahead decisions ");
			stringBuilder.Append(array[13]);
			stringBuilder.Append('\n');
			stringBuilder.Append("number of evaluated syntactic predicates ");
			stringBuilder.Append(array[14]);
			stringBuilder.Append('\n');
			stringBuilder.Append("min lookahead used in a syntactic predicate ");
			stringBuilder.Append(array[15]);
			stringBuilder.Append('\n');
			stringBuilder.Append("max lookahead used in a syntactic predicate ");
			stringBuilder.Append(array[16]);
			stringBuilder.Append('\n');
			stringBuilder.Append("average lookahead depth used in syntactic predicates ");
			stringBuilder.Append(array[17]);
			stringBuilder.Append('\n');
			stringBuilder.Append("standard deviation of depth used in syntactic predicates ");
			stringBuilder.Append(array[18]);
			stringBuilder.Append('\n');
			stringBuilder.Append("rule memoization cache size ");
			stringBuilder.Append(array[28]);
			stringBuilder.Append('\n');
			stringBuilder.Append("number of rule memoization cache hits ");
			stringBuilder.Append(array[25]);
			stringBuilder.Append('\n');
			stringBuilder.Append("number of rule memoization cache misses ");
			stringBuilder.Append(array[26]);
			stringBuilder.Append('\n');
			stringBuilder.Append("number of evaluated semantic predicates ");
			stringBuilder.Append(array[19]);
			stringBuilder.Append('\n');
			stringBuilder.Append("number of tokens ");
			stringBuilder.Append(array[20]);
			stringBuilder.Append('\n');
			stringBuilder.Append("number of hidden tokens ");
			stringBuilder.Append(array[21]);
			stringBuilder.Append('\n');
			stringBuilder.Append("number of char ");
			stringBuilder.Append(array[22]);
			stringBuilder.Append('\n');
			stringBuilder.Append("number of hidden char ");
			stringBuilder.Append(array[23]);
			stringBuilder.Append('\n');
			stringBuilder.Append("number of syntax errors ");
			stringBuilder.Append(array[24]);
			stringBuilder.Append('\n');
			return stringBuilder.ToString();
		}

		// Token: 0x06000828 RID: 2088 RVA: 0x00016EB0 File Offset: 0x000150B0
		protected int[] Trim(int[] X, int n)
		{
			if (n < X.Length)
			{
				int[] array = new int[n];
				Array.Copy(X, 0, array, 0, n);
				X = array;
			}
			return X;
		}

		// Token: 0x06000829 RID: 2089 RVA: 0x00016EDC File Offset: 0x000150DC
		protected int[] ToArray(IList a)
		{
			int[] array = new int[a.Count];
			a.CopyTo(array, 0);
			return array;
		}

		// Token: 0x0600082A RID: 2090 RVA: 0x00016F00 File Offset: 0x00015100
		public int GetNumberOfHiddenTokens(int i, int j)
		{
			int num = 0;
			ITokenStream tokenStream = this.parser.TokenStream;
			int num2 = i;
			while (num2 < tokenStream.Count && num2 <= j)
			{
				IToken token = tokenStream.Get(num2);
				if (token.Channel != 0)
				{
					num++;
				}
				num2++;
			}
			return num;
		}

		// Token: 0x040001FF RID: 511
		public const string Version = "2";

		// Token: 0x04000200 RID: 512
		public const string RUNTIME_STATS_FILENAME = "runtime.stats";

		// Token: 0x04000201 RID: 513
		public const int NUM_RUNTIME_STATS = 29;

		// Token: 0x04000202 RID: 514
		public DebugParser parser;

		// Token: 0x04000203 RID: 515
		protected internal int ruleLevel;

		// Token: 0x04000204 RID: 516
		protected internal int decisionLevel;

		// Token: 0x04000205 RID: 517
		protected internal int maxLookaheadInCurrentDecision;

		// Token: 0x04000206 RID: 518
		protected internal CommonToken lastTokenConsumed;

		// Token: 0x04000207 RID: 519
		protected IList lookaheadStack = new ArrayList();

		// Token: 0x04000208 RID: 520
		public int numRuleInvocations;

		// Token: 0x04000209 RID: 521
		public int numGuessingRuleInvocations;

		// Token: 0x0400020A RID: 522
		public int maxRuleInvocationDepth;

		// Token: 0x0400020B RID: 523
		public int numFixedDecisions;

		// Token: 0x0400020C RID: 524
		public int numCyclicDecisions;

		// Token: 0x0400020D RID: 525
		public int numBacktrackDecisions;

		// Token: 0x0400020E RID: 526
		public int[] decisionMaxFixedLookaheads = new int[200];

		// Token: 0x0400020F RID: 527
		public int[] decisionMaxCyclicLookaheads = new int[200];

		// Token: 0x04000210 RID: 528
		public IList decisionMaxSynPredLookaheads = new ArrayList();

		// Token: 0x04000211 RID: 529
		public int numHiddenTokens;

		// Token: 0x04000212 RID: 530
		public int numCharsMatched;

		// Token: 0x04000213 RID: 531
		public int numHiddenCharsMatched;

		// Token: 0x04000214 RID: 532
		public int numSemanticPredicates;

		// Token: 0x04000215 RID: 533
		public int numSyntacticPredicates;

		// Token: 0x04000216 RID: 534
		protected int numberReportedErrors;

		// Token: 0x04000217 RID: 535
		public int numMemoizationCacheMisses;

		// Token: 0x04000218 RID: 536
		public int numMemoizationCacheHits;

		// Token: 0x04000219 RID: 537
		public int numMemoizationCacheEntries;
	}
}
