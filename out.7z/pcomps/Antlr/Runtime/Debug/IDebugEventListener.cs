﻿using System;

namespace Antlr.Runtime.Debug
{
	// Token: 0x020000B2 RID: 178
	public interface IDebugEventListener
	{
		// Token: 0x06000702 RID: 1794
		void EnterRule(string grammarFileName, string ruleName);

		// Token: 0x06000703 RID: 1795
		void EnterAlt(int alt);

		// Token: 0x06000704 RID: 1796
		void ExitRule(string grammarFileName, string ruleName);

		// Token: 0x06000705 RID: 1797
		void EnterSubRule(int decisionNumber);

		// Token: 0x06000706 RID: 1798
		void ExitSubRule(int decisionNumber);

		// Token: 0x06000707 RID: 1799
		void EnterDecision(int decisionNumber);

		// Token: 0x06000708 RID: 1800
		void ExitDecision(int decisionNumber);

		// Token: 0x06000709 RID: 1801
		void ConsumeToken(IToken t);

		// Token: 0x0600070A RID: 1802
		void ConsumeHiddenToken(IToken t);

		// Token: 0x0600070B RID: 1803
		void LT(int i, IToken t);

		// Token: 0x0600070C RID: 1804
		void Mark(int marker);

		// Token: 0x0600070D RID: 1805
		void Rewind(int marker);

		// Token: 0x0600070E RID: 1806
		void Rewind();

		// Token: 0x0600070F RID: 1807
		void BeginBacktrack(int level);

		// Token: 0x06000710 RID: 1808
		void EndBacktrack(int level, bool successful);

		// Token: 0x06000711 RID: 1809
		void Location(int line, int pos);

		// Token: 0x06000712 RID: 1810
		void RecognitionException(RecognitionException e);

		// Token: 0x06000713 RID: 1811
		void BeginResync();

		// Token: 0x06000714 RID: 1812
		void EndResync();

		// Token: 0x06000715 RID: 1813
		void SemanticPredicate(bool result, string predicate);

		// Token: 0x06000716 RID: 1814
		void Commence();

		// Token: 0x06000717 RID: 1815
		void Terminate();

		// Token: 0x06000718 RID: 1816
		void ConsumeNode(object t);

		// Token: 0x06000719 RID: 1817
		void LT(int i, object t);

		// Token: 0x0600071A RID: 1818
		void GetNilNode(object t);

		// Token: 0x0600071B RID: 1819
		void ErrorNode(object t);

		// Token: 0x0600071C RID: 1820
		void CreateNode(object t);

		// Token: 0x0600071D RID: 1821
		void CreateNode(object node, IToken token);

		// Token: 0x0600071E RID: 1822
		void BecomeRoot(object newRoot, object oldRoot);

		// Token: 0x0600071F RID: 1823
		void AddChild(object root, object child);

		// Token: 0x06000720 RID: 1824
		void SetTokenBoundaries(object t, int tokenStartIndex, int tokenStopIndex);
	}
}
